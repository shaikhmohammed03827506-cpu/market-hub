(() => {
  'use strict';
  if (window.__marketHubAppDownloadInitialized) return;
  window.__marketHubAppDownloadInitialized = true;
  const downloadUrl = 'https://github.com/shaikhmohammed03827506-cpu/market-hub/releases/latest/download/MARKET-HUB-latest.apk';
  const versionUrl = '/app-version.json';
  const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);
  let deferredInstallPrompt = null;

  function installed() {
    return matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  }
  function showMessage(text) {
    document.querySelector('#mhInstallMessage')?.remove();
    const message = document.createElement('aside');
    message.id = 'mhInstallMessage';
    message.className = 'mh-install-help';
    message.innerHTML = `<p>${text}</p><button type="button">Close</button>`;
    message.querySelector('button').onclick = () => message.remove();
    document.body.append(message);
  }
  function startDownload() {
    if (isIos) {
      if (installed()) return showMessage('MARKET HUB is already installed.');
      if (deferredInstallPrompt) {
        deferredInstallPrompt.prompt();
        deferredInstallPrompt.userChoice.finally(() => { deferredInstallPrompt = null; });
        return;
      }
      showMessage('On iPhone or iPad, tap Share, then Add to Home Screen. Android APK files cannot be installed on iPhone.');
      return;
    }
    const anchor = document.createElement('a');
    anchor.href = downloadUrl;
    anchor.rel = 'noopener';
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
  }
  async function mountDownloadButton() {
    const host = document.querySelector('footer .footer-main') || document.querySelector('footer') || document.querySelector('main');
    if (!host) return;
    document.querySelectorAll('[data-mh-install]').forEach(button => button.remove());
    let version = 'Latest';
    try {
      const response = await fetch(versionUrl, { cache: 'no-store' });
      if (response.ok) version = String((await response.json()).version || version);
    } catch { /* The stable download remains available without metadata. */ }
    const button = document.createElement('button');
    button.id = 'marketHubAppDownloadButton';
    button.type = 'button';
    button.dataset.mhInstall = '1';
    button.className = 'mh-install-btn mh-install-footer';
    button.innerHTML = isIos
      ? '<span>Install MARKET HUB</span><small>iPhone & iPad</small>'
      : `<span>Download latest MARKET HUB App</span><small>Android APK · Version ${version}</small>`;
    button.addEventListener('click', startDownload);
    host.append(button);
  }
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    deferredInstallPrompt = event;
  });
  window.addEventListener('appinstalled', () => { deferredInstallPrompt = null; });
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mountDownloadButton, { once: true });
  } else {
    mountDownloadButton();
  }
})();
