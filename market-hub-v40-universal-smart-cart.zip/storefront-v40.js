(() => {
  'use strict';
  if (window.MarketHubStorefront) return;

  const CART_KEY = 'mh-cart';
  const PAGE_SIZE = 24;
  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));
  const money = value => `₹${Number(value || 0).toLocaleString('en-IN')}`;
  const productKey = item => String(item.sku || item.id);
  const normalizeProduct = item => ({
    id: item.id,
    sku: String(item.sku || item.id || ''),
    name: String(item.name || 'Product'),
    category: String(item.category || item.cat || 'General'),
    price: Number(item.price_inr ?? item.price ?? 0),
    image: String(item.image_url || item.img || 'assets/market-hub-logo.png'),
    stock: Math.max(0, Number(item.stock_quantity ?? item.stock ?? 99))
  });

  function readCart() {
    try {
      const rows = JSON.parse(localStorage.getItem(CART_KEY) || '[]');
      return Array.isArray(rows) ? rows : [];
    } catch {
      return [];
    }
  }

  let cart = readCart();
  let productIndex = new Map();
  let initialized = false;

  function saveCart() {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
    renderCart();
    window.dispatchEvent(new CustomEvent('mh:cart-changed', { detail: { cart: [...cart] } }));
  }

  function ensureCartUi() {
    if (!document.getElementById('cartDrawer')) {
      document.body.insertAdjacentHTML('beforeend', `
        <aside class="cart-drawer mh-universal-cart" id="cartDrawer" aria-label="Shopping cart" aria-hidden="true">
          <div class="drawer-head"><h2>Your cart</h2><button class="close-drawer" type="button" aria-label="Close cart">×</button></div>
          <div id="cartItems" class="cart-items"></div>
          <div class="cart-footer">
            <div><span>Subtotal</span><b id="cartSubtotal">₹0</b></div>
            <small>Shipping, discounts and payment options are confirmed in secure checkout.</small>
            <button id="checkoutButton" class="button button-primary full" type="button">Checkout securely →</button>
          </div>
        </aside><div class="drawer-backdrop" id="drawerBackdrop"></div>
      `);
    }
  }

  function renderCart() {
    ensureCartUi();
    const count = cart.reduce((sum, item) => sum + Math.max(1, Number(item.qty || 1)), 0);
    const subtotal = cart.reduce((sum, item) => sum + Number(item.price || 0) * Math.max(1, Number(item.qty || 1)), 0);
    document.querySelectorAll('#cartCount,.cart-count,[data-cart-count]').forEach(node => { node.textContent = count; });
    const subtotalNode = document.getElementById('cartSubtotal');
    if (subtotalNode) subtotalNode.textContent = money(subtotal);
    const list = document.getElementById('cartItems');
    if (!list) return;
    list.innerHTML = cart.length ? cart.map(item => {
      const key = escapeHtml(productKey(item));
      const qty = Math.max(1, Number(item.qty || 1));
      return `<article class="cart-row mh-cart-item">
        <img loading="lazy" src="${escapeHtml(item.img || 'assets/market-hub-logo.png')}" alt="${escapeHtml(item.name)}">
        <div><h4>${escapeHtml(item.name)}</h4><p>${money(item.price)} × ${qty}</p>
          <div class="mh-cart-quantity">
            <button type="button" data-cart-qty="-1" data-cart-key="${key}" aria-label="Decrease quantity">−</button>
            <b>${qty}</b>
            <button type="button" data-cart-qty="1" data-cart-key="${key}" aria-label="Increase quantity">+</button>
          </div>
        </div>
        <button type="button" data-cart-remove="${key}">Remove</button>
      </article>`;
    }).join('') : '<p class="empty-state">Your cart is waiting for something good.</p>';
  }

  function openCart() {
    ensureCartUi();
    document.getElementById('cartDrawer').classList.add('open');
    document.getElementById('drawerBackdrop').classList.add('show');
    document.getElementById('cartDrawer').setAttribute('aria-hidden', 'false');
    document.body.classList.add('mh-cart-lock');
  }

  function closeCart() {
    document.getElementById('cartDrawer')?.classList.remove('open');
    document.getElementById('drawerBackdrop')?.classList.remove('show');
    document.getElementById('cartDrawer')?.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('mh-cart-lock');
  }

  function registerProducts(items) {
    for (const raw of items || []) {
      const item = normalizeProduct(raw);
      if (item.sku) productIndex.set(productKey(item), item);
    }
  }

  function add(item, quantity = 1, show = true) {
    const product = normalizeProduct(item);
    registerProducts([product]);
    const key = productKey(product);
    const found = cart.find(row => productKey(row) === key);
    const amount = Math.max(1, Math.min(99, Number(quantity) || 1));
    if (found) found.qty = Math.min(99, Number(found.qty || 1) + amount);
    else cart.push({ id: product.id, sku: product.sku, name: product.name, price: product.price, img: product.image, qty: amount });
    saveCart();
    if (show) openCart();
  }

  function changeQuantity(key, delta) {
    const item = cart.find(row => productKey(row) === String(key));
    if (!item) return;
    item.qty = Math.max(1, Math.min(99, Number(item.qty || 1) + Number(delta || 0)));
    saveCart();
  }

  function remove(key) {
    cart = cart.filter(row => productKey(row) !== String(key));
    saveCart();
  }

  async function checkout(button) {
    if (!cart.length) return openCart();
    const original = button.textContent;
    button.disabled = true;
    button.textContent = 'Opening secure checkout…';
    try {
      const configResponse = await fetch('/api/config/shiprocket-checkout', { cache: 'no-store' });
      const config = await configResponse.json();
      if (!config.ready) throw new Error('Shiprocket Checkout is not connected yet.');
      if (!window.HeadlessCheckout || typeof window.HeadlessCheckout.addToCart !== 'function') {
        throw new Error('Secure checkout could not load. Please refresh and try again.');
      }
      const response = await fetch('/api/checkout/shiprocket/access-token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cart: cart.map(item => ({ sku: item.sku, qty: item.qty })) })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Checkout could not start.');
      window.HeadlessCheckout.addToCart(new Event('click'), data.token);
    } catch (error) {
      const toast = document.getElementById('toast');
      if (toast) {
        toast.textContent = error.message;
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 3000);
      } else {
        alert(error.message);
      }
    } finally {
      button.disabled = false;
      button.textContent = original;
    }
  }

  function card(raw, options = {}) {
    const item = normalizeProduct(raw);
    registerProducts([item]);
    const key = escapeHtml(productKey(item));
    const url = `product.html?sku=${encodeURIComponent(item.sku)}`;
    return `<article class="shop-card mh-product-card" data-product-key="${key}">
      <a class="shop-image" href="${url}"><img loading="lazy" decoding="async" src="${escapeHtml(item.image)}" alt="${escapeHtml(item.name)}"></a>
      <div class="shop-card-copy">
        <span>${escapeHtml(item.category)}</span>
        <h3><a href="${url}">${escapeHtml(item.name)}</a></h3>
        <div class="mh-card-price"><b>${money(item.price)}</b>${item.stock ? `<small>${item.stock} in stock</small>` : ''}</div>
        <button type="button" data-cart-add="${key}">${options.buttonText || 'Add to cart'}</button>
      </div>
    </article>`;
  }

  async function fetchProducts({ page = 1, limit = PAGE_SIZE, q = '', category = '', sort = 'latest', signal } = {}) {
    const params = new URLSearchParams({ page: String(page), limit: String(Math.min(PAGE_SIZE, limit)), sort });
    if (q) params.set('q', q);
    if (category) params.set('category', category);
    const response = await fetch(`/api/products?${params}`, { cache: 'no-store', signal });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Products could not be loaded.');
    registerProducts(data.products);
    return data;
  }

  function handleClick(event) {
    const cartOpen = event.target.closest('#cartButton,.cart-link,[data-cart-open]');
    const close = event.target.closest('.close-drawer,#drawerBackdrop');
    const addButton = event.target.closest('[data-cart-add]');
    const qty = event.target.closest('[data-cart-qty]');
    const removeButton = event.target.closest('[data-cart-remove]');
    const checkoutButton = event.target.closest('#checkoutButton');
    if (cartOpen) { event.preventDefault(); openCart(); }
    if (close) closeCart();
    if (addButton) {
      event.preventDefault();
      const item = productIndex.get(String(addButton.dataset.cartAdd));
      if (item) add(item, Number(addButton.dataset.quantity || 1));
    }
    if (qty) changeQuantity(qty.dataset.cartKey, qty.dataset.cartQty);
    if (removeButton) remove(removeButton.dataset.cartRemove);
    if (checkoutButton) checkout(checkoutButton);
  }

  function init() {
    if (initialized) return;
    initialized = true;
    ensureCartUi();
    document.addEventListener('click', handleClick);
    document.addEventListener('keydown', event => { if (event.key === 'Escape') closeCart(); });
    window.addEventListener('storage', event => { if (event.key === CART_KEY) { cart = readCart(); renderCart(); } });
    renderCart();
    if (new URLSearchParams(location.search).get('cart') === 'open') openCart();
  }

  window.MarketHubStorefront = {
    PAGE_SIZE, init, card, add, remove, changeQuantity, openCart, closeCart,
    registerProducts, fetchProducts, getCart: () => [...cart], money, escapeHtml
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
