(() => {
  'use strict';
  const store = window.MarketHubStorefront;
  const categories = [['📱','Mobiles'],['🎧','Electronics'],['👕','Fashion'],['💄','Beauty'],['🪑','Home & Living'],['🍳','Kitchen'],['🏋️','Sports & Fitness'],['🎮','Gaming'],['🧸','Toys & Baby'],['🛒','Groceries'],['⌚','Watches'],['🎁','Gift items']];
  const seen = new Set();
  let allPage = 1;
  let allLoading = false;
  let allEnded = false;

  const section = (id, eyebrow, title) => `<section class="section shell mh-home-products" id="${id}">
    <div class="section-heading"><div><p class="eyebrow">${eyebrow}</p><h2>${title}</h2></div></div>
    <div class="product-grid" id="${id}Grid"></div>
  </section>`;

  function skeletons(count = 8) {
    return Array.from({ length: count }, () => '<article class="shop-card mh-skeleton"><div></div><p></p><p></p><button disabled></button></article>').join('');
  }

  function renderUnique(target, items, append = false) {
    const unique = [];
    for (const item of items || []) {
      const key = String(item.sku || item.id);
      if (!key || (append && seen.has(key))) continue;
      if (append) seen.add(key);
      unique.push(item);
    }
    target.insertAdjacentHTML(append ? 'beforeend' : 'afterbegin', unique.map(item => store.card(item)).join(''));
    return unique.length;
  }

  async function loadAllProducts() {
    if (allLoading || allEnded) return;
    allLoading = true;
    const spinner = document.getElementById('allProductsStatus');
    spinner.innerHTML = '<span class="mh-spinner"></span> Loading products…';
    try {
      const data = await store.fetchProducts({ page: allPage, limit: store.PAGE_SIZE });
      const added = renderUnique(document.getElementById('allProductsGrid'), data.products, true);
      allPage += 1;
      allEnded = data.hasMore === false || !added || data.products.length < store.PAGE_SIZE;
      spinner.innerHTML = allEnded ? 'You’ve reached the end of all products.' : '';
    } catch {
      spinner.innerHTML = '<button type="button" id="retryAllProducts">Retry loading products</button>';
    } finally {
      allLoading = false;
    }
  }

  async function init() {
    const categoryGrid = document.getElementById('categoryGrid');
    if (categoryGrid) categoryGrid.innerHTML = categories.map(([icon, label]) => `<a class="category" href="shop.html?category=${encodeURIComponent(label)}"><span class="cat-img">${icon}</span><b>${label}</b></a>`).join('');
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton');
    const openSearch = () => {
      const query = searchInput?.value.trim();
      location.href = query ? `shop.html?q=${encodeURIComponent(query)}` : 'shop.html';
    };
    searchButton?.addEventListener('click', openSearch);
    searchInput?.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); openSearch(); } });

    document.querySelectorAll('#deals,#trending,#new,.mh-reco-holder,[data-rec-section]').forEach(node => node.remove());
    const anchor = document.getElementById('categories');
    anchor.insertAdjacentHTML('afterend',
      section('suggested','PICKED FOR YOU','Suggested For You') +
      section('newArrivals','JUST LANDED','New Arrivals') +
      section('bestSellers','CUSTOMER FAVOURITES','Best Sellers') +
      section('allProducts','EXPLORE THE CATALOGUE','All Products')
    );
    document.getElementById('allProducts').insertAdjacentHTML('beforeend','<div id="allProductsStatus" class="mh-load-status" aria-live="polite"></div><div id="allProductsSentinel" aria-hidden="true"></div>');
    ['suggestedGrid','newArrivalsGrid','bestSellersGrid'].forEach(id => { document.getElementById(id).innerHTML = skeletons(4); });
    document.getElementById('allProductsGrid').innerHTML = skeletons();

    try {
      const [recommendations, firstPage] = await Promise.all([
        fetch('/api/recommendations/home?limit=8', { cache: 'no-store' }).then(response => response.ok ? response.json() : {}),
        store.fetchProducts({ page: 1, limit: store.PAGE_SIZE })
      ]);
      const fallback = firstPage.products || [];
      document.getElementById('suggestedGrid').innerHTML = (recommendations.recommended?.length ? recommendations.recommended : fallback.slice(0, 8)).map(item => store.card(item)).join('');
      document.getElementById('newArrivalsGrid').innerHTML = (recommendations.newArrivals?.length ? recommendations.newArrivals : fallback.slice(8, 16)).map(item => store.card(item)).join('');
      document.getElementById('bestSellersGrid').innerHTML = (recommendations.bestSellers?.length ? recommendations.bestSellers : fallback.slice(16, 24)).map(item => store.card(item)).join('');
      document.getElementById('allProductsGrid').innerHTML = '';
      renderUnique(document.getElementById('allProductsGrid'), firstPage.products, true);
      allPage = 2;
      allEnded = firstPage.hasMore === false;
    } catch {
      document.getElementById('allProductsGrid').innerHTML = '';
      document.getElementById('allProductsStatus').innerHTML = '<button type="button" id="retryAllProducts">Retry loading products</button>';
    }

    const observer = 'IntersectionObserver' in window ? new IntersectionObserver(entries => {
      if (entries.some(entry => entry.isIntersecting)) loadAllProducts();
    }, { rootMargin: '600px' }) : null;
    if (observer) observer.observe(document.getElementById('allProductsSentinel'));
    document.addEventListener('click', event => { if (event.target.closest('#retryAllProducts')) loadAllProducts(); });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
