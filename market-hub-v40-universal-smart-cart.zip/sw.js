const CACHE_NAME = 'mh-v40-global-cart-wishlist-hotfix-1';
const CORE = [
  '/',
  '/index.html',
  '/shop.html',
  '/product.html',
  '/wishlist.html',
  '/offline.html',
  '/manifest.webmanifest',
  '/storefront-v40.js?v=40-global-cart-wishlist-hotfix-1',
  '/storefront-v40.css?v=40-global-cart-wishlist-hotfix-1'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(CORE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/api/')) return;
  event.respondWith((async () => {
    try {
      const networkResponse = await fetch(request);
      const cacheCopy = networkResponse.clone();
      if (networkResponse.ok) {
        const cache = await caches.open(CACHE_NAME);
        await cache.put(request, cacheCopy);
      }
      return networkResponse;
    } catch {
      return (await caches.match(request)) || (await caches.match('/offline.html'));
    }
  })());
});
