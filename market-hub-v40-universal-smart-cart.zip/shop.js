(() => {
  'use strict';
  const store = window.MarketHubStorefront;
  const params = new URLSearchParams(location.search);
  const state = {
    page: 1, loading: false, ended: false, seen: new Set(),
    query: params.get('q') || '', category: params.get('category') || '', sort: params.get('sort') || 'latest'
  };
  const $ = id => document.getElementById(id);

  function skeletons() {
    return Array.from({ length: 8 }, () => '<article class="shop-card mh-skeleton"><div></div><p></p><p></p><button disabled></button></article>').join('');
  }
  function syncUrl() {
    const next = new URLSearchParams();
    if (state.query) next.set('q', state.query);
    if (state.category) next.set('category', state.category);
    if (state.sort !== 'latest') next.set('sort', state.sort);
    history.replaceState({}, '', `shop.html${next.size ? `?${next}` : ''}`);
  }
  function reset() {
    state.page = 1; state.ended = false; state.seen.clear();
    $('shopGrid').innerHTML = skeletons();
    load(true);
  }
  async function load(resetGrid = false) {
    if (state.loading || state.ended) return;
    state.loading = true;
    $('scrollStatus').innerHTML = '<span class="mh-spinner"></span> Loading products…';
    try {
      const data = await store.fetchProducts({
        page: state.page, limit: store.PAGE_SIZE, q: state.query, category: state.category, sort: state.sort
      });
      const unique = (data.products || []).filter(item => {
        const key = String(item.sku || item.id);
        if (state.seen.has(key)) return false;
        state.seen.add(key);
        return true;
      });
      if (resetGrid) $('shopGrid').innerHTML = '';
      $('shopGrid').insertAdjacentHTML('beforeend', unique.map(item => store.card(item)).join(''));
      $('productCount').textContent = `${data.total || 0} product${data.total === 1 ? '' : 's'}`;
      state.page += 1;
      state.ended = data.hasMore === false || data.products.length < store.PAGE_SIZE;
      $('scrollStatus').textContent = state.ended ? (state.seen.size ? 'You’ve reached the end.' : 'No products match your search.') : '';
      $('loadMore').hidden = state.ended;
    } catch {
      if (resetGrid) $('shopGrid').innerHTML = '';
      $('scrollStatus').innerHTML = '<button type="button" id="retryProducts">Retry loading products</button>';
    } finally {
      state.loading = false;
    }
  }
  async function loadCategories() {
    try {
      const response = await fetch('assets/catalogue/products.json', { cache: 'force-cache' });
      const items = await response.json();
      const categories = [...new Set(items.map(item => item.category).filter(Boolean))].sort();
      $('categoryFilter').innerHTML = '<option value="">All categories</option>' + categories.map(value => `<option>${store.escapeHtml(value)}</option>`).join('');
      $('categoryFilter').value = state.category;
    } catch {
      $('categoryFilter').innerHTML = '<option value="">All categories</option>';
    }
  }
  $('shopSearch').value = state.query;
  $('sortFilter').value = state.sort;
  $('shopSearch').addEventListener('input', event => { state.query = event.target.value.trim(); syncUrl(); reset(); });
  $('categoryFilter').addEventListener('change', event => { state.category = event.target.value; syncUrl(); reset(); });
  $('sortFilter').addEventListener('change', event => { state.sort = event.target.value; syncUrl(); reset(); });
  $('loadMore').addEventListener('click', () => load(false));
  document.addEventListener('click', event => { if (event.target.closest('#retryProducts')) load(state.page === 1); });
  const observer = 'IntersectionObserver' in window ? new IntersectionObserver(entries => {
    if (scrollY > 100 && entries.some(entry => entry.isIntersecting)) load(false);
  }, { rootMargin: '600px' }) : null;
  if (observer) observer.observe($('scrollSentinel'));
  loadCategories();
  reset();
})();
