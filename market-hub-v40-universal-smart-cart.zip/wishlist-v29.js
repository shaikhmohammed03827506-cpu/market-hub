(() => {
  'use strict';
  const store = window.MarketHubStorefront;
  const grid = document.getElementById('wishlistGrid');
  let items = [];
  async function load() {
    let skus = [];
    try {
      const response = await fetch('/api/customer/wishlist', { credentials: 'same-origin' });
      if (response.ok) skus = (await response.json()).skus || [];
    } catch {}
    if (!skus.length) skus = JSON.parse(localStorage.getItem('mh-wishes') || '[]').map(String);
    const pages = await Promise.all(Array.from({ length: Math.max(1, Math.ceil(skus.length / store.PAGE_SIZE)) }, (_, index) =>
      store.fetchProducts({ page: index + 1, limit: store.PAGE_SIZE }).catch(() => ({ products: [] }))
    ));
    items = pages.flatMap(page => page.products).filter(item => skus.includes(String(item.sku)));
    store.registerProducts(items);
    grid.innerHTML = items.length ? items.map(item => store.card(item, { buttonText: 'Move to cart' }).replace('</div></article>', `<button class="review-helpful" type="button" data-wishlist-remove="${store.escapeHtml(item.sku)}">Remove</button></div></article>`)).join('') : '<p class="empty">Your wishlist is empty.</p>';
  }
  document.addEventListener('click', async event => {
    const remove = event.target.closest('[data-wishlist-remove]');
    if (!remove) return;
    const sku = remove.dataset.wishlistRemove;
    await fetch('/api/customer/wishlist', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sku, saved: false }) }).catch(() => {});
    localStorage.setItem('mh-wishes', JSON.stringify(JSON.parse(localStorage.getItem('mh-wishes') || '[]').filter(value => String(value) !== sku)));
    load();
  });
  load();
})();
