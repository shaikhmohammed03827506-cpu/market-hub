// Server-only PostgreSQL access. DATABASE_URL must exist only in .env or hosting secrets.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
let pool;
let orderSchemaReady;

function database() {
  if (!process.env.DATABASE_URL) throw new Error('Database is not configured. Add DATABASE_URL to the private .env file.');
  if (!pool) {
    const { Pool } = require('pg');
    pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: { rejectUnauthorized: false },
      max: 8,
      idleTimeoutMillis: 20_000
    });
  }
  return pool;
}

async function databaseHealth() {
  const result = await database().query('select now() as connected_at');
  return Boolean(result.rows[0]);
}

const productFields = `
  select p.id, p.sku, p.name, p.slug, p.description, p.specifications, p.price_inr,
         p.compare_at_price_inr, p.stock_quantity, p.weight_kg, p.is_active,
         coalesce(c.name, 'Uncategorized') as category,
         coalesce(jsonb_agg(jsonb_build_object('url', pi.url, 'alt_text', pi.alt_text, 'sort_order', pi.sort_order)
           order by pi.sort_order) filter (where pi.id is not null), '[]'::jsonb) as images
  from products p
  left join categories c on c.id = p.category_id
  left join product_images pi on pi.product_id = p.id
`;

const productGroup = ' group by p.id, c.name';
const serializeProduct = row => {
  const images = Array.isArray(row.images) ? row.images.map(image => image.url).filter(Boolean) : [];
  return {
    id: row.id, sku: row.sku, name: row.name, slug: row.slug, category: row.category,
    description: row.description || '', price_inr: Number(row.price_inr),
    compare_at_price_inr: row.compare_at_price_inr == null ? null : Number(row.compare_at_price_inr),
    stock_quantity: Number(row.stock_quantity), weight_grams: Math.round(Number(row.weight_kg) * 1000),
    is_active: row.is_active, image_url: images[0] || '', gallery: images,
    video_url: row.specifications?.video_url || ''
  };
};

async function listActiveProducts() {
  const result = await database().query(`${productFields} where p.is_active = true${productGroup} order by p.created_at desc limit 5000`);
  return result.rows.map(serializeProduct);
}

async function listAdminProducts() {
  const result = await database().query(`${productFields}${productGroup} order by p.updated_at desc limit 5000`);
  return result.rows.map(serializeProduct);
}

const toSlug = value => String(value).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

const isWebUrl = value => /^https?:\/\/\S+$/i.test(String(value || '').trim());
function productInput(input) {
  const name = String(input.name || '').trim();
  const category = String(input.category || '').trim();
  const sku = String(input.sku || '').trim();
  const description = String(input.description || '').trim();
  const price = Number(input.price);
  const stock = Number(input.stock);
  const weightGrams = Number(input.weight_grams);
  const images = Array.isArray(input.images) ? input.images.map(value => String(value).trim()).filter(Boolean) : [];
  const videoUrl = String(input.video_url || '').trim();
  if (!name || name.length > 180 || !category || category.length > 80 || !sku || sku.length > 80) throw new Error('Enter a product name, category and SKU.');
  if (!Number.isFinite(price) || price <= 0 || price > 10000000) throw new Error('Enter a valid product price.');
  if (!Number.isInteger(stock) || stock < 0 || stock > 1000000) throw new Error('Enter a valid stock quantity.');
  if (!Number.isFinite(weightGrams) || weightGrams < 1 || weightGrams > 100000) throw new Error('Enter a valid weight in grams.');
  if (!images.length || images.length > 12 || images.some(url => !isWebUrl(url))) throw new Error('Add 1 to 12 valid photo links starting with https://.');
  if (videoUrl && !isWebUrl(videoUrl)) throw new Error('The video link must start with https://.');
  return { name, category, sku, description, price, stock, weightGrams, images, videoUrl };
}

async function saveProduct(input, productId = null) {
  const value = productInput(input);
  const client = await database().connect();
  try {
    await client.query('begin');
    const category = await client.query(
      'insert into categories (name, slug) values ($1, $2) on conflict (slug) do update set name = excluded.name, is_active = true returning id',
      [value.category, toSlug(value.category)]
    );
    const specification = JSON.stringify(value.videoUrl ? { video_url: value.videoUrl } : {});
    let result;
    if (productId) {
      result = await client.query(
        `update products set category_id=$1, sku=$2, name=$3, description=$4, specifications=$5::jsonb,
         price_inr=$6, stock_quantity=$7, weight_kg=$8, is_active=true, updated_at=now() where id=$9 returning id`,
        [category.rows[0].id, value.sku, value.name, value.description, specification, value.price, value.stock, value.weightGrams / 1000, productId]
      );
      if (!result.rowCount) throw new Error('This product no longer exists.');
      await client.query('delete from product_images where product_id=$1', [productId]);
    } else {
      const slugBase = toSlug(value.name) || 'product';
      result = await client.query(
        `insert into products (category_id, sku, name, slug, description, specifications, price_inr, stock_quantity, weight_kg)
         values ($1,$2,$3,$4,$5,$6::jsonb,$7,$8,$9) returning id`,
        [category.rows[0].id, value.sku, value.name, `${slugBase}-${toSlug(value.sku)}`, value.description, specification, value.price, value.stock, value.weightGrams / 1000]
      );
    }
    const id = result.rows[0].id;
    for (const [sortOrder, url] of value.images.entries()) {
      await client.query('insert into product_images (product_id, url, alt_text, sort_order) values ($1,$2,$3,$4)', [id, url, value.name, sortOrder]);
    }
    await client.query('commit');
    const saved = await database().query(`${productFields} where p.id=$1${productGroup}`, [id]);
    return serializeProduct(saved.rows[0]);
  } catch (error) {
    await client.query('rollback');
    if (error.code === '23505') throw new Error('This SKU is already being used. Choose a different SKU.');
    throw error;
  } finally {
    client.release();
  }
}

async function deactivateProduct(productId) {
  const result = await database().query('update products set is_active=false, updated_at=now() where id=$1 returning id', [productId]);
  if (!result.rowCount) throw new Error('This product no longer exists.');
}

// The original starter schema used whole numbers for order totals. Supplier
// prices can include paise, so this small migration keeps every order amount
// accurate and can safely run on an existing store database.
async function ensureOrderSchema() {
  if (orderSchemaReady) return orderSchemaReady;
  orderSchemaReady = (async () => {
    const client = await database().connect();
    try {
      await client.query('begin');
      await client.query('alter table orders alter column subtotal_inr type numeric(10,2) using subtotal_inr::numeric(10,2)');
      await client.query('alter table orders alter column discount_inr type numeric(10,2) using discount_inr::numeric(10,2)');
      await client.query('alter table orders alter column wallet_used_inr type numeric(10,2) using wallet_used_inr::numeric(10,2)');
      await client.query('alter table orders alter column shipping_inr type numeric(10,2) using shipping_inr::numeric(10,2)');
      await client.query('alter table orders alter column total_inr type numeric(10,2) using total_inr::numeric(10,2)');
      await client.query('alter table order_items alter column unit_price_inr type numeric(10,2) using unit_price_inr::numeric(10,2)');
      await client.query('alter table orders drop constraint if exists orders_payment_method_check');
      await client.query("alter table orders add constraint orders_payment_method_check check (payment_method in ('shiprocket','cod','wallet','razorpay'))");
      await client.query('create unique index if not exists orders_shiprocket_order_unique on orders(shiprocket_order_id) where shiprocket_order_id is not null');
      await client.query('commit');
    } catch (error) {
      await client.query('rollback');
      orderSchemaReady = undefined;
      throw error;
    } finally { client.release(); }
  })();
  return orderSchemaReady;
}

const moneyValue = value => Math.max(0, Number(value || 0)).toFixed(2);
const statusForShiprocket = value => ({ SUCCESS: 'confirmed', FAILED: 'cancelled' }[String(value || '').toUpperCase()] || 'pending');
const paymentForShiprocket = value => ({ SUCCESS: 'paid', FAILED: 'failed', PENDING: 'cod_pending' }[String(value || '').toUpperCase()] || 'pending');
const newReferralCode = () => `MH${crypto.randomBytes(5).toString('hex').toUpperCase()}`;

async function findOrCreateCustomer(client, order) {
  const phone = String(order.phone || order.shipping_address?.phone || '').replace(/\D/g, '').slice(-10);
  const email = String(order.email || order.shipping_address?.email || '').trim().toLowerCase() || null;
  const name = [order.shipping_address?.first_name, order.shipping_address?.last_name].filter(Boolean).join(' ').trim() || 'MARKET HUB customer';
  if (!phone && !email) throw new Error('The checkout order is missing customer contact information.');
  const existing = phone ? await client.query('select id from users where phone=$1', [phone]) : await client.query('select id from users where email=$1', [email]);
  if (existing.rowCount) return existing.rows[0].id;
  const created = await client.query(
    'insert into users (full_name,email,phone,referral_code) values ($1,$2,$3,$4) returning id',
    [name, email, phone || null, newReferralCode()]
  );
  return created.rows[0].id;
}

async function saveOrderAddress(client, userId, order) {
  const address = order.shipping_address || {};
  const pincode = String(address.pincode || '').replace(/\D/g, '').slice(0, 6);
  if (!pincode || !address.line1 || !address.city || !address.state) return null;
  const name = [address.first_name, address.last_name].filter(Boolean).join(' ').trim() || 'MARKET HUB customer';
  const phone = String(address.phone || order.phone || '').replace(/\D/g, '').slice(-10) || '0000000000';
  const saved = await client.query(
    `insert into addresses (user_id,label,full_name,phone,line1,line2,city,state,pincode,is_default)
     values ($1,'Checkout',$2,$3,$4,$5,$6,$7,$8,false) returning id`,
    [userId, name, phone, String(address.line1), address.line2 || null, String(address.city), String(address.state), pincode]
  );
  return saved.rows[0].id;
}

function supplierCatalogueById() {
  const cataloguePath = path.join(__dirname, 'assets', 'catalogue', 'products.json');
  const products = JSON.parse(fs.readFileSync(cataloguePath, 'utf8'));
  return new Map(products.map(product => [String(product.id), product]));
}

async function recordShiprocketOrder(order) {
  if (!order?.order_id) throw new Error('The checkout order id is missing.');
  await ensureOrderSchema();
  const client = await database().connect();
  try {
    await client.query('begin');
    const userId = await findOrCreateCustomer(client, order);
    const addressId = await saveOrderAddress(client, userId, order);
    const paymentType = String(order.payment_type || '').toUpperCase();
    const orderResult = await client.query(
      `insert into orders (user_id,address_id,status,payment_status,payment_method,subtotal_inr,discount_inr,wallet_used_inr,coins_used,shipping_inr,total_inr,shiprocket_order_id)
       values ($1,$2,$3,$4,$5,$6,$7,0,0,$8,$9,$10)
       on conflict (shiprocket_order_id) where shiprocket_order_id is not null do update set
         status=excluded.status,payment_status=excluded.payment_status,payment_method=excluded.payment_method,
         subtotal_inr=excluded.subtotal_inr,discount_inr=excluded.discount_inr,shipping_inr=excluded.shipping_inr,total_inr=excluded.total_inr
       returning id,order_number`,
      [userId, addressId, statusForShiprocket(order.status), paymentForShiprocket(order.payment_status), paymentType === 'CASH_ON_DELIVERY' ? 'cod' : 'shiprocket', moneyValue(order.subtotal_price), moneyValue(order.total_discount), moneyValue(order.cod_charges), moneyValue(order.total_amount_payable), String(order.order_id)]
    );
    const savedOrder = orderResult.rows[0];
    await client.query('delete from order_items where order_id=$1', [savedOrder.id]);
    const supplierProducts = supplierCatalogueById();
    const itemIds = (order.cart_data?.items || []).map(item => String(item.variant_id));
    const products = itemIds.length ? await client.query('select id,sku,name,price_inr from products where sku = any($1::text[])', [Array.from(supplierProducts.values()).filter(product => itemIds.includes(String(product.id))).map(product => product.sku)]) : { rows: [] };
    const databaseProducts = new Map(products.rows.map(product => [product.sku, product]));
    for (const item of order.cart_data?.items || []) {
      const supplierProduct = supplierProducts.get(String(item.variant_id));
      if (!supplierProduct) continue;
      const product = databaseProducts.get(supplierProduct.sku);
      await client.query(
        'insert into order_items (order_id,product_id,product_name,sku,unit_price_inr,quantity,coin_reward) values ($1,$2,$3,$4,$5,$6,0)',
        [savedOrder.id, product?.id || null, product?.name || supplierProduct.name, supplierProduct.sku, moneyValue(product?.price_inr || supplierProduct.price_inr), Math.max(1, Number(item.quantity || 1))]
      );
    }
    await client.query('commit');
    return { id: savedOrder.id, orderNumber: savedOrder.order_number };
  } catch (error) {
    await client.query('rollback');
    throw error;
  } finally { client.release(); }
}

async function listAdminOrders() {
  await ensureOrderSchema();
  const result = await database().query(
    `select o.id,o.order_number,o.status,o.payment_status,o.payment_method,o.total_inr,o.created_at,
            u.full_name,u.email,u.phone,coalesce(count(oi.id),0)::integer as item_count
       from orders o join users u on u.id=o.user_id left join order_items oi on oi.order_id=o.id
      group by o.id,u.full_name,u.email,u.phone order by o.created_at desc limit 500`
  );
  return result.rows.map(order => ({ id: order.id, order_number: Number(order.order_number), status: order.status, payment_status: order.payment_status, payment_method: order.payment_method, total_inr: Number(order.total_inr), created_at: order.created_at, customer: order.full_name, email: order.email, phone: order.phone, item_count: order.item_count }));
}

// Imports the catalogue extracted from the owner's PDF. This is deliberately an
// admin-only server function: no browser can write product data directly.
async function importPdfCatalogue() {
  const cataloguePath = path.join(__dirname, 'assets', 'catalogue', 'products.json');
  if (!fs.existsSync(cataloguePath)) throw new Error('The PDF catalogue file is not available on this server.');
  const items = JSON.parse(fs.readFileSync(cataloguePath, 'utf8'));
  if (!Array.isArray(items) || !items.length) throw new Error('The PDF catalogue is empty.');

  const client = await database().connect();
  try {
    await client.query('begin');
    // Some supplier prices include paise (for example ₹1.50), so retain the
    // exact PDF price instead of rounding it up.
    await client.query('alter table products alter column price_inr type numeric(10,2) using price_inr::numeric(10,2)');
    await client.query('alter table products alter column compare_at_price_inr type numeric(10,2) using compare_at_price_inr::numeric(10,2)');

    const categories = [...new Set(items.map(item => item.category))];
    for (const category of categories) {
      await client.query(
        'insert into categories (name, slug) values ($1, $2) on conflict (slug) do update set name = excluded.name, is_active = true',
        [category, toSlug(category)]
      );
    }
    const categoryRows = await client.query('select id, slug from categories where slug = any($1::text[])', [categories.map(toSlug)]);
    const categoryIds = new Map(categoryRows.rows.map(row => [row.slug, row.id]));

    const imported = [];
    for (let start = 0; start < items.length; start += 100) {
      const batch = items.slice(start, start + 100);
      const values = [];
      const params = [];
      batch.forEach((item, index) => {
        const at = index * 9;
        values.push(`($${at + 1}::uuid, $${at + 2}::text, $${at + 3}::text, $${at + 4}::text, $${at + 5}::text, $${at + 6}::jsonb, $${at + 7}::numeric, $${at + 8}::integer, $${at + 9}::numeric, 10, 10, 10, true)`);
        params.push(
          categoryIds.get(toSlug(item.category)) || null,
          item.sku,
          item.name,
          `${toSlug(item.name)}-${toSlug(item.sku)}`,
          `Imported from supplier PDF. Source code: ${item.source_code}.`,
          JSON.stringify({ source_code: item.source_code, source_page: item.source_page, weight_grams: item.weight_grams }),
          item.price_inr,
          item.stock_quantity,
          Number(item.weight_grams) / 1000
        );
      });
      const result = await client.query(
        `insert into products (category_id, sku, name, slug, description, specifications, price_inr, stock_quantity, weight_kg, length_cm, breadth_cm, height_cm, is_active)
         values ${values.join(',')}
         on conflict (sku) do update set category_id = excluded.category_id, name = excluded.name, slug = excluded.slug, description = excluded.description, specifications = excluded.specifications, price_inr = excluded.price_inr, stock_quantity = excluded.stock_quantity, weight_kg = excluded.weight_kg, is_active = true, updated_at = now()
         returning id, sku`,
        params
      );
      imported.push(...result.rows);
    }

    const productIds = imported.map(row => row.id);
    await client.query('delete from product_images where product_id = any($1::uuid[])', [productIds]);
    for (let start = 0; start < items.length; start += 200) {
      const batch = items.slice(start, start + 200);
      const values = [];
      const params = [];
      batch.forEach((item, index) => {
        const at = index * 4;
        const product = imported.find(row => row.sku === item.sku);
        values.push(`($${at + 1}, $${at + 2}, $${at + 3}, 0)`);
        params.push(product.id, item.image_url, item.name);
      });
      await client.query(`insert into product_images (product_id, url, alt_text, sort_order) values ${values.join(',')}`, params);
    }
    await client.query('commit');
    return { products: items.length, categories: categories.length };
  } catch (error) {
    await client.query('rollback');
    throw error;
  } finally {
    client.release();
  }
}

module.exports = { database, databaseHealth, listActiveProducts, listAdminProducts, listAdminOrders, saveProduct, deactivateProduct, importPdfCatalogue, recordShiprocketOrder };
