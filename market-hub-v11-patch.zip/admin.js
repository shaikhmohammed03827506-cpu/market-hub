const fallbackProducts=[
  {name:'NovaPods Pro Wireless Earbuds',category:'Electronics',price_inr:899,stock_quantity:42,sku:'MH-ELE-001',image_url:'https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=140&q=80',weight_grams:500},
  {name:'Stainless Steel Insulated Bottle',category:'Home & Kitchen',price_inr:349,stock_quantity:8,sku:'MH-HOM-021',image_url:'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=140&q=80',weight_grams:500}
];
let orders=[
  {id:'#MH-1048',customer:'Riya Sharma',initials:'RS',items:'2 items',total:'₹1,248',payment:'Prepaid',status:'New'},
  {id:'#MH-1047',customer:'Arjun Mehta',initials:'AM',items:'4 items',total:'₹2,699',payment:'COD',status:'New'},
  {id:'#MH-1046',customer:'Sana Fatima',initials:'SF',items:'1 item',total:'₹899',payment:'Prepaid',status:'Packed'},
  {id:'#MH-1045',customer:'Karan Patel',initials:'KP',items:'3 items',total:'₹1,549',payment:'UPI',status:'Shipped'}
];
let catalogue=[],pdfCatalogue=[];
const $=id=>document.getElementById(id);
const safe=value=>String(value||'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const money=value=>'₹'+Number(value||0).toLocaleString('en-IN',{minimumFractionDigits:Number(value)%1?2:0,maximumFractionDigits:2});
const statusClass=value=>String(value).toLowerCase();
const toast=message=>{const node=$('toast');node.textContent=message;node.classList.add('show');setTimeout(()=>node.classList.remove('show'),3500)};
const orderRow=(order,compact=false)=>compact?`<tr><td><b>${order.id}</b></td><td><div class="customer"><span class="avatar">${order.initials}</span>${order.customer}</div></td><td><b>${order.total}</b></td><td>${order.payment}</td><td><span class="pill ${statusClass(order.status)}">${order.status}</span></td><td><button class="row-button" data-toast="Order details will open here when connected to the live store.">View</button></td></tr>`:`<tr><td><input type="checkbox"></td><td><b>${order.id}</b></td><td><div class="customer"><span class="avatar">${order.initials}</span>${order.customer}</div></td><td>${order.items}</td><td><b>${order.total}</b></td><td>${order.payment}</td><td><span class="pill ${statusClass(order.status)}">${order.status}</span></td><td><button class="row-button" data-toast="Order details will open here when connected to the live store.">View</button></td></tr>`;
function normaliseProduct(product){return {...product,price_inr:Number(product.price_inr??product.price??0),stock_quantity:Number(product.stock_quantity??product.stock??0),weight_grams:Number(product.weight_grams||500),gallery:Array.isArray(product.gallery)?product.gallery:(product.image_url?[product.image_url]:[]),image_url:product.image_url||product.img||''}}
function renderProducts(query=''){
  const text=query.trim().toLowerCase(),filtered=text?catalogue.filter(product=>`${product.name} ${product.category} ${product.sku}`.toLowerCase().includes(text)):catalogue,visible=filtered.slice(0,100);
  $('productsTable').innerHTML=visible.map(product=>`<tr><td><div class="product-cell"><img src="${safe(product.image_url)}" alt=""><span><strong>${safe(product.name)}</strong><small>${safe(product.sku)}</small></span></div></td><td>${safe(product.category)}</td><td><b>${money(product.price_inr)}</b></td><td class="${product.stock_quantity<10?'stock-low':''}">${product.stock_quantity} units${product.stock_quantity<10?' · Low':''}</td><td><span class="pill ${product.is_active===false?'warning':'shipped'}">${product.is_active===false?'Hidden':'Active'}</span></td><td>${product.id?`<button class="row-button" data-edit-product="${product.id}">Edit</button>`:'<button class="row-button" data-toast="Import the PDF catalogue or save a new product to edit it.">Edit</button>'}</td></tr>`).join('')||'<tr><td colspan="6">No matching products.</td></tr>';
  $('catalogueSummary').textContent=`${filtered.length.toLocaleString('en-IN')} product${filtered.length===1?'':'s'} ready. Showing the first ${Math.min(visible.length,100)}.`;
}
async function loadPdfPreview(){if(pdfCatalogue.length)return pdfCatalogue;const response=await fetch('assets/catalogue/products.json',{cache:'no-store'});if(!response.ok)throw new Error('The PDF catalogue file was not found.');pdfCatalogue=await response.json();return pdfCatalogue}
async function loadProducts(){
  try{const response=await fetch('/api/admin/products',{cache:'no-store'});const data=await response.json();if(!response.ok)throw new Error(data.error||'The database is not ready.');catalogue=data.products.map(normaliseProduct);}
  catch(error){try{catalogue=(await loadPdfPreview()).map(normaliseProduct);toast('Showing your PDF preview. Import it to make products editable.')}catch{catalogue=fallbackProducts.map(normaliseProduct);toast(error.message||'Product database is not ready.')}}
  renderProducts($('productSearch')?.value||'');
}
function buildModal(product=null){
  const form=$('productForm'),isEdit=Boolean(product),images=(product?.gallery||[]).join('\n');
  form.innerHTML=`<button type="button" class="modal-close">×</button><p class="mini-label">CATALOGUE</p><h2>${isEdit?'Edit product':'Add a product'}</h2><input type="hidden" name="product_id" value="${safe(product?.id||'')}"><label>Product name<input required name="name" maxlength="180" value="${safe(product?.name||'')}" placeholder="e.g. NovaPods Pro Wireless Earbuds"></label><div class="form-two"><label>Category<input required name="category" maxlength="80" value="${safe(product?.category||'')}" placeholder="e.g. Electronics"></label><label>Price (₹)<input required name="price" type="number" min="0.01" step="0.01" value="${product?.price_inr??''}" placeholder="899"></label></div><div class="form-two"><label>Stock quantity<input required name="stock" type="number" min="0" step="1" value="${product?.stock_quantity??99}" placeholder="99"></label><label>Weight (grams)<input required name="weight_grams" type="number" min="1" step="1" value="${product?.weight_grams??500}"></label></div><label>SKU<input required name="sku" maxlength="80" value="${safe(product?.sku||'')}" placeholder="MH-NEW-001"></label><label>Description<textarea name="description" maxlength="1500" placeholder="Product details customers will see">${safe(product?.description||'')}</textarea></label><label>Photo links <small>One secure image link per line (up to 12)</small><textarea name="images" placeholder="https://example.com/photo-1.jpg&#10;https://example.com/photo-2.jpg">${safe(images)}</textarea></label><label>Product video link <small>Optional secure video link</small><input name="video_url" type="url" value="${safe(product?.video_url||'')}" placeholder="https://example.com/product-video.mp4"></label><div class="modal-actions">${isEdit?'<button type="button" class="danger-text" id="deleteProduct">Remove product</button>':''}<button class="primary">Save product</button></div>`;
  form.onsubmit=saveProduct;
  $('deleteProduct')?.addEventListener('click',()=>removeProduct(product));
}
function showModal(product=null){buildModal(product);$('modalBackdrop').classList.add('show')}
function hideModal(){$('modalBackdrop').classList.remove('show')}
async function saveProduct(event){
  event.preventDefault();const form=new FormData(event.currentTarget),id=String(form.get('product_id')||''),payload={name:form.get('name'),category:form.get('category'),price:Number(form.get('price')),stock:Number(form.get('stock')),weight_grams:Number(form.get('weight_grams')),sku:form.get('sku'),description:form.get('description'),images:String(form.get('images')||'').split(/\r?\n/).map(value=>value.trim()).filter(Boolean),video_url:form.get('video_url')};
  const button=event.currentTarget.querySelector('.primary');button.disabled=true;button.textContent='Saving…';
  try{const response=await fetch(id?`/api/admin/products/${encodeURIComponent(id)}`:'/api/admin/products',{method:id?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),data=await response.json();if(!response.ok)throw new Error(data.error||'Product could not be saved.');const index=catalogue.findIndex(product=>product.id===data.product.id);if(index>=0)catalogue[index]=normaliseProduct(data.product);else catalogue.unshift(normaliseProduct(data.product));renderProducts($('productSearch').value);hideModal();toast(id?'Product updated successfully.':'Product added successfully.');}
  catch(error){toast(error.message||'Product could not be saved.')}finally{button.disabled=false;button.textContent='Save product';}
}
async function removeProduct(product){
  if(!confirm(`Remove “${product.name}” from your storefront?`))return;
  try{const response=await fetch(`/api/admin/products/${encodeURIComponent(product.id)}`,{method:'DELETE'}),data=await response.json();if(!response.ok)throw new Error(data.error||'Product could not be removed.');catalogue=catalogue.filter(item=>item.id!==product.id);renderProducts($('productSearch').value);hideModal();toast('Product removed from the storefront.');}catch(error){toast(error.message||'Product could not be removed.');}
}
function activate(section){document.querySelectorAll('.view').forEach(view=>view.classList.toggle('active',view.id===section));document.querySelectorAll('.nav-link').forEach(button=>button.classList.toggle('active',button.dataset.section===section));const names={dashboard:'Good morning, Mohammed',orders:'Order management',returns:'Returns & wallet refunds',products:'Product catalogue',categories:'Category manager',shipping:'Delhivery shipping',customers:'Customer management',offers:'Offers & coupons',settings:'Store settings'};$('pageTitle').textContent=names[section]||'MARKET HUB';if(section==='products')loadProducts();if(section==='returns')loadRefunds();window.scrollTo({top:0,behavior:'smooth'})}
function renderOrders(){
  $('recentOrders').innerHTML=orders.slice(0,3).map(order=>orderRow(order,true)).join('');
  $('ordersTable').innerHTML=orders.map(order=>orderRow(order)).join('');
}
async function loadOrders(){
  try{
    const response=await fetch('/api/admin/orders',{cache:'no-store'}),data=await response.json();
    if(!response.ok)throw new Error(data.error||'Orders are not ready yet.');
    if(data.orders.length)orders=data.orders.map(order=>({id:`#MH-${order.order_number}`,customer:order.customer,initials:order.customer.split(/\s+/).map(name=>name[0]).join('').slice(0,2).toUpperCase(),items:`${order.item_count} item${order.item_count===1?'':'s'}`,total:money(order.total_inr),payment:order.payment_method==='cod'?'COD':order.payment_status==='paid'?'Prepaid':'Pending',status:order.status==='confirmed'?'New':order.status[0].toUpperCase()+order.status.slice(1)}));
    renderOrders();
  }catch(error){renderOrders();}
}
let refunds=[];
function renderRefunds(){
  const body=$('refundsTable');if(!body)return;
  body.innerHTML=refunds.map(refund=>`<tr><td><b>#MH-${refund.orderNumber}</b></td><td>${safe(refund.customer)}</td><td><b>${money(refund.totalInr)}</b></td><td>${money(refund.refundedInr)}</td><td><b>${money(refund.remainingInr)}</b></td><td><span class="pill ${refund.status==='refunded'?'shipped':'warning'}">${safe(refund.status.replace('_',' '))}</span></td><td>${refund.remainingInr>0?`<button class="small-primary" data-refund-order="${refund.id}">Refund to wallet</button>`:'<span class="muted-cell">Complete</span>'}</td></tr>`).join('')||'<tr><td colspan="7">No delivered or returned orders are ready for a refund yet.</td></tr>';
}
async function loadRefunds(){
  try{const response=await fetch('/api/admin/refunds',{cache:'no-store'}),data=await response.json();if(!response.ok)throw new Error(data.error||'Refunds are not ready yet.');refunds=data.refunds;renderRefunds();}catch(error){refunds=[];renderRefunds();toast(error.message||'Refunds are not ready yet.');}
}
async function refundToWallet(refund){
  const amount=prompt(`Approve a wallet refund for order #MH-${refund.orderNumber}.\nAvailable amount: ${money(refund.remainingInr)}`,String(refund.remainingInr));
  if(amount===null)return;const value=Number(amount);if(!Number.isInteger(value)||value<1)return toast('Enter a whole rupee amount.');
  if(!confirm(`Add ${money(value)} to ${refund.customer}'s MARKET HUB Wallet? It will expire after 12 months.`))return;
  try{const response=await fetch(`/api/admin/orders/${encodeURIComponent(refund.id)}/refund`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({amount:value,note:'Approved return refund'})}),data=await response.json();if(!response.ok)throw new Error(data.error||'Wallet refund could not be approved.');toast(`${money(data.amount)} added to the customer wallet. Valid for 12 months.`);await loadRefunds();}catch(error){toast(error.message||'Wallet refund could not be approved.');}
}
renderOrders();
buildModal();renderProducts();loadProducts();loadOrders();
$('productSearch').addEventListener('input',event=>renderProducts(event.target.value));
$('importPdfCatalogue').onclick=async()=>{try{await loadPdfPreview();if(!confirm(`Import ${pdfCatalogue.length.toLocaleString('en-IN')} PDF products into your live database? Existing PDF products will be updated.`))return;const button=$('importPdfCatalogue');button.disabled=true;button.textContent='Importing catalogue…';const response=await fetch('/api/admin/catalogue/import',{method:'POST'}),result=await response.json();if(!response.ok||!result.imported)throw new Error(result.error||'Import could not be completed.');toast(`${result.products.toLocaleString('en-IN')} products imported successfully.`);await loadProducts();}catch(error){toast(error.message||'Import could not be completed.')}finally{$('importPdfCatalogue').textContent='Import PDF catalogue';$('importPdfCatalogue').disabled=false;}};
document.addEventListener('click',event=>{const nav=event.target.closest('[data-section]'),jump=event.target.closest('[data-section-jump]'),edit=event.target.closest('[data-edit-product]'),refund=event.target.closest('[data-refund-order]');if(nav)activate(nav.dataset.section);if(jump)activate(jump.dataset.sectionJump);if(event.target.closest('[data-open-product]'))showModal();if(edit)showModal(catalogue.find(product=>product.id===edit.dataset.editProduct));if(refund)refundToWallet(refunds.find(item=>item.id===refund.dataset.refundOrder));if(event.target.closest('.modal-close')||event.target===$('modalBackdrop'))hideModal();const note=event.target.closest('[data-toast]');if(note)toast(note.dataset.toast);});
