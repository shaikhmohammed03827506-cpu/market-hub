/* MARKET HUB local server and secure payment foundation.
   Keep .env private. It must never be uploaded with the public website files. */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = __dirname;
const envPath = path.join(root, '.env');
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
  }
}

const config = {
  port: Number(process.env.PORT || 4173),
  databaseUrl: process.env.DATABASE_URL || '',
  razorpayKeyId: process.env.RAZORPAY_KEY_ID || '',
  razorpayKeySecret: process.env.RAZORPAY_KEY_SECRET || '',
  razorpayWebhookSecret: process.env.RAZORPAY_WEBHOOK_SECRET || '',
  shiprocketCheckoutApiKey: process.env.SHIPROCKET_CHECKOUT_API_KEY || '',
  shiprocketCheckoutSecret: process.env.SHIPROCKET_CHECKOUT_SECRET_KEY || '',
  shiprocketCheckoutBaseUrl: (process.env.SHIPROCKET_CHECKOUT_BASE_URL || 'https://checkout-api.shiprocket.com').replace(/\/$/, ''),
  shiprocketApiEmail: (process.env.SHIPROCKET_API_EMAIL || '').trim().toLowerCase(),
  shiprocketApiPassword: process.env.SHIPROCKET_API_PASSWORD || '',
  shiprocketChannelId: Number(process.env.SHIPROCKET_CHANNEL_ID || 0),
  shiprocketApiBaseUrl: (process.env.SHIPROCKET_API_BASE_URL || 'https://apiv2.shiprocket.in').replace(/\/$/, ''),
  shiprocketPickupLocation: (process.env.SHIPROCKET_PICKUP_LOCATION || '').trim(),
  shiprocketPickupPincode: String(process.env.SHIPROCKET_PICKUP_PINCODE || '').replace(/\D/g, '').slice(0, 6),
  shiprocketCheckoutWebhookSecret: process.env.SHIPROCKET_CHECKOUT_WEBHOOK_SECRET || '',
  delhiveryToken: process.env.DELHIVERY_API_TOKEN || '',
  delhiveryPickupLocation: process.env.DELHIVERY_PICKUP_LOCATION || '',
  delhiveryCodEnabled: process.env.DELHIVERY_COD_ENABLED === 'true',
  adminEmail: (process.env.ADMIN_EMAIL || '').trim().toLowerCase(),
  adminPassword: process.env.ADMIN_PASSWORD || '',
  logo: process.env.STORE_LOGO_URL || ''
};

// Small demo-price fallback. The catalogue price is calculated on the server below.
const priceCatalog = new Map([
  [1, 899], [2, 349], [3, 399], [4, 649], [5, 1799], [6, 299], [7, 999], [8, 799]
]);
const contentTypes = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.json':'application/json; charset=utf-8'};
const sendJson = (res, status, body) => { res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}); res.end(JSON.stringify(body)); };
const readBody = req => new Promise((resolve, reject) => { let body=''; req.on('data', chunk => { body += chunk; if (body.length > 6_000_000) { reject(new Error('Request too large')); req.destroy(); } }); req.on('end', () => resolve(body)); req.on('error', reject); });
const secureEqual = (first, second) => { const a=Buffer.from(first||''), b=Buffer.from(second||''); return a.length===b.length && crypto.timingSafeEqual(a,b); };
const adminSessions = new Map();
const customerSessions = new Map();
const parseCookies = request => Object.fromEntries((request.headers.cookie||'').split(';').map(item=>item.trim()).filter(Boolean).map(item=>{const point=item.indexOf('=');return point<0?[item,'']:[item.slice(0,point),decodeURIComponent(item.slice(point+1))]}));
const validAdminSession = request => { const token=parseCookies(request).mh_admin_session; const session=token&&adminSessions.get(token); if(!session||session.expiresAt<Date.now()){if(token)adminSessions.delete(token);return false}return true; };
const makeAdminSession = () => { const token=crypto.randomBytes(32).toString('base64url'); adminSessions.set(token,{expiresAt:Date.now()+8*60*60*1000}); return token; };
const adminCookie = (request,token) => `mh_admin_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800${request.headers['x-forwarded-proto']==='https'||request.socket.encrypted?'; Secure':''}`;
const customerCookie = (request,token) => `mh_customer_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=2592000${request.headers['x-forwarded-proto']==='https'||request.socket.encrypted?'; Secure':''}`;
const validCustomerSession = request => {
  const token = parseCookies(request).mh_customer_session;
  const session = token && customerSessions.get(token);
  if (!session || session.expiresAt < Date.now()) { if (token) customerSessions.delete(token); return null; }
  return session.userId;
};
const makeCustomerSession = userId => {
  const token = crypto.randomBytes(32).toString('base64url');
  customerSessions.set(token, { userId, expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000 });
  return token;
};

async function razorpay(endpoint, body) {
  const authorization = Buffer.from(`${config.razorpayKeyId}:${config.razorpayKeySecret}`).toString('base64');
  const response = await fetch(`https://api.razorpay.com/v1${endpoint}`, {method:'POST',headers:{'Authorization':`Basic ${authorization}`,'Content-Type':'application/json'},body:JSON.stringify(body)});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.description || 'Razorpay could not create the payment order.');
  return data;
}

// Shiprocket Checkout (Fastrr) signs the exact JSON body using the private
// API secret. The secret stays on this server and is never sent to a browser.
function shiprocketCheckoutError(data, status) {
  const error = data && (data.error || data.errors || data.message || data.detail);
  const message = typeof error === 'string' ? error
    : Array.isArray(error) ? error.map(item => typeof item === 'string' ? item : item?.message).filter(Boolean).join(' ')
    : error && typeof error === 'object' ? (error.message || error.detail || Object.values(error).find(value => typeof value === 'string'))
    : '';
  if (message) return String(message).replace(/[<>]/g, '').slice(0, 300);
  return status ? `Shiprocket Checkout could not start (service response ${status}).` : 'Shiprocket Checkout could not start.';
}

async function shiprocketCheckout(endpoint, body) {
  if (!config.shiprocketCheckoutApiKey || !config.shiprocketCheckoutSecret) {
    throw new Error('Shiprocket Checkout is not configured yet.');
  }
  const serialized = JSON.stringify(body);
  const hmac = crypto.createHmac('sha256', config.shiprocketCheckoutSecret).update(serialized).digest('base64');
  let response;
  try {
    response = await fetch(`${config.shiprocketCheckoutBaseUrl}${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Api-Key': config.shiprocketCheckoutApiKey,
        'X-Api-HMAC-SHA256': hmac
      },
      body: serialized
    });
  } catch {
    throw new Error('Shiprocket Checkout is temporarily unavailable. Please keep your cart and try again shortly.');
  }
  let data;
  try { data = await response.json(); } catch { data = {}; }
  if (!response.ok || data.ok === false) throw new Error(shiprocketCheckoutError(data, response.status));
  return data;
}

// Regular Shiprocket shipping API. This is separate from Shiprocket Checkout:
// Checkout collects the order, while this connection creates the shipment order
// in the seller's Shiprocket panel using a short-lived server-side token.
let shiprocketToken = { value: '', expiresAt: 0 };
async function shiprocketShippingToken(force = false) {
  if (!config.shiprocketApiEmail || !config.shiprocketApiPassword) throw new Error('Shiprocket shipping API is not configured yet.');
  if (!force && shiprocketToken.value && shiprocketToken.expiresAt > Date.now() + 60_000) return shiprocketToken.value;
  const response = await fetch(`${config.shiprocketApiBaseUrl}/v1/external/auth/login`, {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({email: config.shiprocketApiEmail, password: config.shiprocketApiPassword})
  });
  let data; try { data = await response.json(); } catch { data = {}; }
  if (!response.ok || !data.token) throw new Error(data.message || data.error || 'Shiprocket could not sign in with the API user.');
  // Shiprocket tokens normally last 10 days. Refreshing sooner is safe and
  // avoids exposing token handling to the browser.
  shiprocketToken = { value: data.token, expiresAt: Date.now() + 9 * 24 * 60 * 60 * 1000 };
  return shiprocketToken.value;
}
async function shiprocketShipping(endpoint, body, retried = false) {
  const token = await shiprocketShippingToken(retried);
  const response = await fetch(`${config.shiprocketApiBaseUrl}${endpoint}`, {
    method: 'POST', headers: {'Content-Type':'application/json','Authorization':`Bearer ${token}`}, body: JSON.stringify(body)
  });
  let data; try { data = await response.json(); } catch { data = {}; }
  if (response.status === 401 && !retried) { shiprocketToken = { value: '', expiresAt: 0 }; return shiprocketShipping(endpoint, body, true); }
  if (!response.ok || data.status_code >= 400) throw new Error(data.message || data.error || 'Shiprocket could not create the shipping order.');
  return data;
}
async function shiprocketShippingGet(endpoint, retried = false) {
  const token = await shiprocketShippingToken(retried);
  const response = await fetch(`${config.shiprocketApiBaseUrl}${endpoint}`, {headers:{'Authorization':`Bearer ${token}`}});
  let data; try { data = await response.json(); } catch { data = {}; }
  if (response.status === 401 && !retried) { shiprocketToken = { value: '', expiresAt: 0 }; return shiprocketShippingGet(endpoint, true); }
  if (!response.ok || data.status_code >= 400) throw new Error(data.message || data.error || 'Shiprocket could not check this pincode.');
  return data;
}

const deliveryEstimateCache = new Map();
function estimateDateFromShiprocket(value) {
  if (!value) return null;
  if (/^\d+(\.\d+)?$/.test(String(value).trim())) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date.toISOString().slice(0, 10);
}
async function shiprocketDeliveryEstimate(pincode, weightGrams = 500) {
  const deliveryPincode = String(pincode || '').replace(/\D/g, '').slice(0, 6);
  if (!/^\d{6}$/.test(deliveryPincode)) return {serviceable:false,message:'Enter a valid 6-digit pincode.'};
  if (!config.shiprocketPickupPincode) return {serviceable:null,message:'Delivery estimate will be confirmed in Shiprocket Checkout.'};
  const key = `${deliveryPincode}:${Math.max(1,Number(weightGrams)||500)}`;
  const cached=deliveryEstimateCache.get(key); if(cached && cached.expiresAt>Date.now()) return cached.value;
  const query = new URLSearchParams({pickup_postcode:config.shiprocketPickupPincode,delivery_postcode:deliveryPincode,cod:'1',weight:String(Math.max(.1,(Number(weightGrams)||500)/1000))});
  const response = await shiprocketShippingGet(`/v1/external/courier/serviceability/?${query.toString()}`);
  const options=response.data?.available_courier_companies || response.available_courier_companies || [];
  if(!options.length){const value={serviceable:false,message:'Delivery is not available for this pincode yet.'};deliveryEstimateCache.set(key,{value,expiresAt:Date.now()+300000});return value;}
  const best=options[0]||{}; const rawEta=best.etd || best.estimated_delivery_date || best.estimated_delivery_days; let eta=estimateDateFromShiprocket(rawEta); const days=Number(best.estimated_delivery_days || best.etd);
  if(!eta && Number.isFinite(days) && days>0 && days<90) eta=new Date(Date.now()+days*86400000).toISOString().slice(0,10);
  const value={serviceable:true,estimatedDeliveryDate:eta,estimatedDeliveryDays:Number.isFinite(days)?days:null,courier:String(best.courier_name||''),message:eta?'Estimated delivery based on Shiprocket serviceability.':'Delivery is serviceable; exact options are shown in checkout.'};
  deliveryEstimateCache.set(key,{value,expiresAt:Date.now()+300000}); return value;
}

function checkoutPaymentDiagnostic(checkout) {
  const modes=[]; const scan=value=>{ if(Array.isArray(value)) return value.forEach(scan); if(value&&typeof value==='object') return Object.entries(value).forEach(([key,val])=>{if(/payment|method|mode/i.test(key)&&typeof val==='string')modes.push(val);scan(val);}); };
  scan(checkout?.result || checkout); const normalized=[...new Set(modes.map(value=>String(value).toLowerCase()))];
  if(normalized.length && normalized.every(value=>/cod|cash/.test(value))) console.warn('Shiprocket payment diagnostics: checkout response lists COD only; enable prepaid methods in Shiprocket Checkout Payment settings.',{event:'shiprocket_payment_modes',modeCount:normalized.length});
}

function shiprocketWebhookTrusted(req, raw) {
  // Shiprocket Checkout dashboard supports a custom header.  We intentionally
  // verify only a merchant-configured secret instead of guessing an SDK scheme.
  if (!config.shiprocketCheckoutWebhookSecret) return false;
  const supplied=req.headers['x-market-hub-webhook-secret'] || req.headers['x-shiprocket-webhook-secret'];
  return secureEqual(String(config.shiprocketCheckoutWebhookSecret), String(supplied || ''));
}
function shiprocketEventDetails(payload, raw) {
  const event=String(payload.event || payload.event_type || payload.type || payload.status || 'unknown').toLowerCase().replace(/\s+/g,'_');
  const externalOrderId=payload.order_id || payload.data?.order_id || payload.order?.id || '';
  const eventId=payload.event_id || payload.id || payload.data?.event_id || crypto.createHash('sha256').update(raw).digest('hex');
  return {type:event,externalOrderId:String(externalOrderId),eventKey:`shiprocket:${eventId}`,payloadHash:crypto.createHash('sha256').update(raw).digest('hex')};
}

// Never trust a product price submitted by the customer's browser.
let cataloguePriceBySku;
let catalogueProductBySku;
function catalogueProducts() {
  if (catalogueProductBySku) return catalogueProductBySku;
  const cataloguePath = path.join(root, 'assets', 'catalogue', 'products.json');
  const items = JSON.parse(fs.readFileSync(cataloguePath, 'utf8'));
  catalogueProductBySku = new Map(items.map(item => [String(item.sku), item]));
  return catalogueProductBySku;
}
function cataloguePrices() {
  if (cataloguePriceBySku) return cataloguePriceBySku;
  const cataloguePath = path.join(root, 'assets', 'catalogue', 'products.json');
  const items = JSON.parse(fs.readFileSync(cataloguePath, 'utf8'));
  cataloguePriceBySku = new Map(items.map(item => [String(item.sku), {
    price: Number(item.price_inr), stock: Number(item.stock_quantity)
  }]));
  return cataloguePriceBySku;
}

function publicOrigin(request) {
  const host = String(request.headers.host || '').trim();
  if (!/^[a-z0-9.-]+(?::\d+)?$/i.test(host)) throw new Error('The public website address is not available.');
  const protocol = request.headers['x-forwarded-proto'] === 'http' ? 'http' : 'https';
  return `${protocol}://${host}`;
}

function shiprocketProductPayload(product, origin) {
  const image = product.image_url ? `${origin}${product.image_url.startsWith('/') ? product.image_url : `/${product.image_url}`}` : '';
  const now = new Date().toISOString();
  return {
    id: Number(product.id), title: String(product.name),
    body_html: `<p>${String(product.name).replace(/[<>&]/g, '')}</p>`, vendor: 'MARKET HUB',
    product_type: String(product.category || 'General'), handle: String(product.sku).toLowerCase().replace(/[^a-z0-9]+/g, '-'),
    created_at: now, updated_at: now, tags: String(product.category || ''), status: 'active',
    variants: [{ id: Number(product.id), title: 'Default', price: Number(product.price_inr).toFixed(2), sku: String(product.sku), created_at: now, updated_at: now, taxable: true, quantity: Number(product.stock_quantity || 0), grams: Number(product.weight_grams || 500), image: { src: image }, weight: Number(product.weight_grams || 500) / 1000, weight_unit: 'kg' }],
    image: { src: image }
  };
}

function shiprocketCategoryFeed() {
  const categories = [...new Set([...catalogueProducts().values()].map(product => String(product.category || 'General')))].sort();
  return categories.map((title, index) => ({
    id: index + 1,
    title,
    handle: title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
    body_html: `<p>${title.replace(/[<>&]/g, '')}</p>`,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }));
}

function shiprocketProductFeed(origin, categoryName = '') {
  const categoryIds = new Map(shiprocketCategoryFeed().map(category => [category.title, category.id]));
  return [...catalogueProducts().values()]
    .filter(product => !categoryName || String(product.category || 'General') === categoryName)
    .map(product => ({ ...shiprocketProductPayload(product, origin), collection_id: categoryIds.get(String(product.category || 'General')) || 1 }));
}

function shiprocketPage(url) {
  const page = Math.max(1, Number.parseInt(url.searchParams.get('page') || '1', 10) || 1);
  const limit = Math.min(100, Math.max(1, Number.parseInt(url.searchParams.get('limit') || '100', 10) || 100));
  return { page, limit, from: (page - 1) * limit };
}

async function prepareShiprocketCart(request, cart) {
  if (!Array.isArray(cart) || !cart.length || cart.length > 50) throw new Error('Your cart is invalid.');
  const catalogue = catalogueProducts();
  const seen = new Set();
  const items = [];
  for (const item of cart) {
    const quantity = Number(item.qty);
    const sku = String(item.sku || '').trim();
    const product = catalogue.get(sku);
    if (!product || !Number.isInteger(quantity) || quantity < 1 || quantity > 99) throw new Error('Please refresh your cart and try again.');
    if (quantity > Number(product.stock_quantity)) throw new Error(`${product.name} does not have enough stock.`);
    if (!seen.has(sku)) {
      // Fastrr Checkout validates variants against its catalogue before it
      // creates a checkout token, so send the product to its catalogue first.
      await shiprocketCheckout('/wh/v1/custom/product', shiprocketProductPayload(product, publicOrigin(request)));
      seen.add(sku);
    }
    items.push({ variant_id: String(product.id), quantity });
  }
  return items;
}

const cleanShippingText = value => String(value || '').trim().replace(/[<>]/g, '').slice(0, 200);
const shippingPhone = value => String(value || '').replace(/\D/g, '').slice(-10);
function shiprocketShippingPayload(checkoutOrder, savedOrder) {
  const address = checkoutOrder.shipping_address || {};
  const firstName = cleanShippingText(address.first_name || checkoutOrder.customer_name || 'MARKET HUB customer') || 'MARKET HUB customer';
  const lastName = cleanShippingText(address.last_name);
  const phone = shippingPhone(address.phone || checkoutOrder.phone);
  const pincode = String(address.pincode || '').replace(/\D/g, '').slice(0, 6);
  const line1 = cleanShippingText(address.line1 || address.address);
  const city = cleanShippingText(address.city);
  const state = cleanShippingText(address.state);
  if (!phone || !pincode || !line1 || !city || !state) throw new Error('The checkout order needs a complete delivery address before it can be sent to Shiprocket.');
  const supplierProducts = catalogueProducts();
  let weightGrams = 0;
  const orderItems = [];
  for (const cartItem of checkoutOrder.cart_data?.items || []) {
    const product = Array.from(supplierProducts.values()).find(item => String(item.id) === String(cartItem.variant_id));
    if (!product) continue;
    const units = Math.max(1, Number(cartItem.quantity || 1));
    weightGrams += Math.max(100, Number(product.weight_grams || 500)) * units;
    orderItems.push({
      sku: String(product.sku), name: cleanShippingText(product.name), units,
      selling_price: Number(product.price_inr || 0).toFixed(2), discount: 0
    });
  }
  if (!orderItems.length) throw new Error('The checkout order has no valid products to send to Shiprocket.');
  const paymentType = String(checkoutOrder.payment_type || '').toUpperCase();
  const total = Math.max(0, Number(checkoutOrder.total_amount_payable || checkoutOrder.subtotal_price || 0));
  const payload = {
    order_id: `MH${savedOrder.orderNumber}`,
    order_date: new Date().toISOString().slice(0, 16).replace('T', ' '),
    channel_id: config.shiprocketChannelId,
    billing_customer_name: firstName, billing_last_name: lastName,
    billing_address: line1, billing_address_2: cleanShippingText(address.line2),
    billing_city: city, billing_pincode: pincode, billing_state: state, billing_country: 'India',
    billing_email: cleanShippingText(address.email || checkoutOrder.email), billing_phone: phone,
    shipping_is_billing: true,
    order_items: orderItems,
    payment_method: paymentType === 'CASH_ON_DELIVERY' || paymentType === 'COD' ? 'COD' : 'Prepaid',
    sub_total: total.toFixed(2), length: 15, breadth: 15, height: 10,
    weight: Math.max(0.5, weightGrams / 1000)
  };
  if (config.shiprocketPickupLocation) payload.pickup_location = config.shiprocketPickupLocation;
  return payload;
}

function shouldCreateShippingOrder(order) {
  return !['FAILED', 'CANCELLED', 'CANCELLED_BY_USER'].includes(String(order?.status || '').toUpperCase());
}

function calculateCartTotal(cart) {
  let totalPaise = 0;
  const catalogue = cataloguePrices();
  for (const item of cart) {
    const qty = Number(item.qty);
    if (!Number.isInteger(qty) || qty < 1 || qty > 99) throw new Error('A cart quantity is invalid.');
    const sku = String(item.sku || '').trim();
    const catalogueItem = sku && catalogue.get(sku);
    if (catalogueItem) {
      if (qty > catalogueItem.stock) throw new Error('One of these products no longer has enough stock.');
      totalPaise += Math.round(catalogueItem.price * 100) * qty;
      continue;
    }
    const legacyId = Number(item.id);
    if (!Number.isInteger(legacyId) || !priceCatalog.has(legacyId)) throw new Error('A cart item is no longer available.');
    totalPaise += priceCatalog.get(legacyId) * 100 * qty;
  }
  return totalPaise;
}

async function handleApi(req, res, url) {
  if (req.method==='POST' && url.pathname==='/api/auth/admin/login') {
    const {email='',password=''}=JSON.parse(await readBody(req));
    if(!config.adminEmail||!config.adminPassword) return sendJson(res,503,{authenticated:false,error:'Admin login is not configured.'});
    if(!secureEqual(String(email).trim().toLowerCase(),config.adminEmail)||!secureEqual(String(password),config.adminPassword)) return sendJson(res,401,{authenticated:false,error:'Email or password is incorrect.'});
    res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Set-Cookie':adminCookie(req,makeAdminSession()),'Cache-Control':'no-store'});return res.end(JSON.stringify({authenticated:true}));
  }
  if (req.method==='GET' && url.pathname==='/api/auth/admin/session') return sendJson(res,200,{authenticated:validAdminSession(req)});
  if (req.method==='POST' && url.pathname==='/api/auth/admin/logout') { const token=parseCookies(req).mh_admin_session;if(token)adminSessions.delete(token);res.writeHead(204,{'Set-Cookie':'mh_admin_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});return res.end(); }
  if (req.method === 'POST' && url.pathname === '/api/auth/customer/register') {
    try {
      const { registerCustomer } = require('./db');
      const customer = await registerCustomer(JSON.parse(await readBody(req)));
      res.writeHead(201, {'Content-Type':'application/json; charset=utf-8','Set-Cookie':customerCookie(req, makeCustomerSession(customer.id)),'Cache-Control':'no-store'});
      return res.end(JSON.stringify({authenticated:true, customer:{fullName:customer.full_name,email:customer.email,referralCode:customer.referral_code}}));
    } catch (error) { return sendJson(res,400,{authenticated:false,error:error.message || 'Your account could not be created.'}); }
  }
  if (req.method === 'POST' && url.pathname === '/api/auth/customer/login') {
    try {
      const { email='', password='' } = JSON.parse(await readBody(req));
      const { authenticateCustomer } = require('./db');
      const customer = await authenticateCustomer(email, password);
      if (!customer) return sendJson(res,401,{authenticated:false,error:'Email or password is incorrect.'});
      res.writeHead(200, {'Content-Type':'application/json; charset=utf-8','Set-Cookie':customerCookie(req, makeCustomerSession(customer.id)),'Cache-Control':'no-store'});
      return res.end(JSON.stringify({authenticated:true,customer:{fullName:customer.fullName,email:customer.email,referralCode:customer.referralCode}}));
    } catch { return sendJson(res,503,{authenticated:false,error:'Customer sign-in is not ready yet.'}); }
  }
  if (req.method === 'POST' && url.pathname === '/api/auth/customer/logout') {
    const token = parseCookies(req).mh_customer_session; if (token) customerSessions.delete(token);
    res.writeHead(204, {'Set-Cookie':'mh_customer_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'}); return res.end();
  }
  if (req.method === 'GET' && url.pathname === '/api/customer/account') {
    const userId = validCustomerSession(req); if (!userId) return sendJson(res,401,{authenticated:false});
    try {
      const { customerAccount } = require('./db'); const account = await customerAccount(userId);
      if (!account) return sendJson(res,401,{authenticated:false});
      return sendJson(res,200,{authenticated:true,account});
    } catch (error) { console.error('Customer account query failed:', error.message); return sendJson(res,503,{authenticated:false,error:'Your account is not ready yet.'}); }
  }
  if (req.method === 'POST' && url.pathname === '/api/loyalty/quote') {
    const userId = validCustomerSession(req); if (!userId) return sendJson(res,401,{authenticated:false,error:'Sign in to use MARKET HUB Coins.'});
    try {
      const body=JSON.parse(await readBody(req)); const totalPaise=calculateCartTotal(body.cart || []);
      const { loyaltyQuote } = require('./db'); return sendJson(res,200,await loyaltyQuote(userId,totalPaise/100,body.coins));
    } catch(error) { return sendJson(res,400,{error:error.message || 'Coin value could not be checked.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/customer/wishlist') { const userId=validCustomerSession(req);if(!userId)return sendJson(res,401,{authenticated:false});try{const {customerWishlist}=require('./db');return sendJson(res,200,{skus:await customerWishlist(userId)});}catch{return sendJson(res,503,{error:'Wishlist is not ready yet.'});} }
  if (req.method==='POST' && url.pathname==='/api/customer/wishlist') { const userId=validCustomerSession(req);if(!userId)return sendJson(res,401,{authenticated:false,error:'Sign in to save your wishlist.'});try{const body=JSON.parse(await readBody(req));const {saveCustomerWishlist}=require('./db');return sendJson(res,200,{skus:await saveCustomerWishlist(userId,body.sku,body.saved!==false)});}catch(error){return sendJson(res,400,{error:error.message||'Wishlist could not be updated.'});} }
  if (req.method === 'PUT' && url.pathname === '/api/customer/profile') {
    const userId = validCustomerSession(req); if (!userId) return sendJson(res,401,{authenticated:false});
    try { const { updateCustomerProfile } = require('./db'); return sendJson(res,200,{saved:true,profile:await updateCustomerProfile(userId,JSON.parse(await readBody(req)))}); }
    catch (error) { return sendJson(res,400,{saved:false,error:error.message || 'Your profile could not be saved.'}); }
  }
  if (req.method === 'GET' && url.pathname === '/api/customer/addresses') {
    const userId = validCustomerSession(req); if (!userId) return sendJson(res,401,{authenticated:false});
    try { const { customerAddresses } = require('./db'); return sendJson(res,200,{addresses:await customerAddresses(userId)}); }
    catch (error) { return sendJson(res,503,{error:'Saved addresses are not ready yet.'}); }
  }
  if (req.method === 'POST' && url.pathname === '/api/customer/addresses') {
    const userId = validCustomerSession(req); if (!userId) return sendJson(res,401,{authenticated:false});
    try { const { saveCustomerAddress } = require('./db'); return sendJson(res,201,{saved:true,...await saveCustomerAddress(userId,JSON.parse(await readBody(req)))}); }
    catch (error) { return sendJson(res,400,{saved:false,error:error.message || 'The address could not be saved.'}); }
  }
  const customerAddressRoute = url.pathname.match(/^\/api\/customer\/addresses\/([0-9a-f-]{36})$/i);
  if (customerAddressRoute && req.method === 'DELETE') {
    const userId = validCustomerSession(req); if (!userId) return sendJson(res,401,{authenticated:false});
    try { const { deleteCustomerAddress } = require('./db'); await deleteCustomerAddress(userId,customerAddressRoute[1]); return sendJson(res,200,{removed:true}); }
    catch (error) { return sendJson(res,400,{removed:false,error:error.message || 'The address could not be removed.'}); }
  }
  if (req.method === 'GET' && url.pathname === '/api/customer/returns') {
    const userId = validCustomerSession(req); if (!userId) return sendJson(res,401,{authenticated:false});
    try { const { customerReturnItems } = require('./db'); return sendJson(res,200,{items:await customerReturnItems(userId)}); }
    catch (error) { console.error('Customer returns query failed:', error.message); return sendJson(res,503,{error:'Returns are not ready yet.'}); }
  }
  if (req.method === 'GET' && url.pathname === '/api/customer/orders') {
    const userId = validCustomerSession(req); if (!userId) return sendJson(res,401,{authenticated:false});
    try { const { customerOrders } = require('./db'); return sendJson(res,200,{orders:await customerOrders(userId)}); }
    catch (error) { console.error('Customer orders query failed:', error.message); return sendJson(res,503,{error:'Orders are not ready yet.'}); }
  }
  if (req.method === 'GET' && url.pathname === '/api/customer/reviews') {
    const userId = validCustomerSession(req); if (!userId) return sendJson(res,401,{authenticated:false});
    try { const { customerReviewItems } = require('./db'); return sendJson(res,200,{items:await customerReviewItems(userId)}); }
    catch (error) { console.error('Customer review query failed:', error.message); return sendJson(res,503,{error:'Reviews are not ready yet.'}); }
  }
  if (req.method === 'POST' && url.pathname === '/api/customer/reviews') {
    const userId = validCustomerSession(req); if (!userId) return sendJson(res,401,{authenticated:false});
    try { const { submitCustomerReview } = require('./db'); return sendJson(res,201,await submitCustomerReview(userId, JSON.parse(await readBody(req)))); }
    catch (error) { return sendJson(res,400,{submitted:false,error:error.message || 'Your review could not be submitted.'}); }
  }
  if (req.method === 'POST' && url.pathname === '/api/customer/returns') {
    const userId = validCustomerSession(req); if (!userId) return sendJson(res,401,{authenticated:false});
    try { const { requestCustomerReturn } = require('./db'); return sendJson(res,201,await requestCustomerReturn(userId, JSON.parse(await readBody(req)))); }
    catch (error) { return sendJson(res,400,{requested:false,error:error.message || 'The return request could not be submitted.'}); }
  }
  if (req.method==='POST' && url.pathname==='/api/admin/catalogue/import') {
    if (!validAdminSession(req)) return sendJson(res,401,{imported:false,error:'Please sign in to the admin panel first.'});
    try {
      const { importPdfCatalogue } = require('./db');
      const result = await importPdfCatalogue();
      return sendJson(res,200,{imported:true,...result});
    } catch (error) {
      console.error('Catalogue import failed:', error.message);
      return sendJson(res,503,{imported:false,error:'The catalogue could not be imported. Confirm the live database connection and try again.'});
    }
  }
  if (req.method==='GET' && url.pathname==='/api/admin/products') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { listAdminProducts } = require('./db'); return sendJson(res,200,{products:await listAdminProducts()}); }
    catch (error) { console.error('Admin product query failed:', error.message); return sendJson(res,503,{error:'The product database is not ready yet.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/admin/orders') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { listAdminOrders } = require('./db'); return sendJson(res,200,{orders:await listAdminOrders()}); }
    catch (error) { console.error('Admin order query failed:', error.message); return sendJson(res,503,{error:'Orders are not ready yet.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/admin/loyalty') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { listAdminLoyalty } = require('./db'); return sendJson(res,200,await listAdminLoyalty()); }
    catch (error) { return sendJson(res,503,{error:'Loyalty data is not ready yet.'}); }
  }
  if (req.method==='PUT' && url.pathname==='/api/admin/loyalty/rules') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { setLoyaltyRules } = require('./db'); const body=JSON.parse(await readBody(req)); return sendJson(res,200,{saved:true,rules:await setLoyaltyRules(body,body.reason)}); }
    catch (error) { return sendJson(res,400,{saved:false,error:error.message || 'Loyalty rules could not be saved.'}); }
  }
  const loyaltyAdjustmentRoute=url.pathname.match(/^\/api\/admin\/loyalty\/customers\/([0-9a-f-]{36})\/adjustment$/i);
  if (loyaltyAdjustmentRoute && req.method==='POST') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { adminCoinAdjustment } = require('./db'); return sendJson(res,200,{saved:true,summary:await adminCoinAdjustment(loyaltyAdjustmentRoute[1],JSON.parse(await readBody(req)))}); }
    catch (error) { return sendJson(res,400,{saved:false,error:error.message || 'Coin adjustment could not be saved.'}); }
  }
  const packingVideoRoute = url.pathname.match(/^\/api\/admin\/orders\/([0-9a-f-]{36})\/packing-video$/i);
  if (packingVideoRoute && req.method==='POST') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { savePackingVideo } = require('./db'); return sendJson(res,200,{saved:true,...await savePackingVideo(packingVideoRoute[1], JSON.parse(await readBody(req)))}); }
    catch (error) { return sendJson(res,400,{saved:false,error:error.message || 'The packing video could not be saved.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/admin/refunds') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { listAdminRefunds } = require('./db'); return sendJson(res,200,{refunds:await listAdminRefunds()}); }
    catch (error) { console.error('Admin refunds query failed:', error.message); return sendJson(res,503,{error:'Refunds are not ready yet.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/admin/reviews') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { listAdminReviews } = require('./db'); return sendJson(res,200,{reviews:await listAdminReviews()}); }
    catch (error) { console.error('Admin review query failed:', error.message); return sendJson(res,503,{error:'Reviews are not ready yet.'}); }
  }
  const reviewApprovalRoute = url.pathname.match(/^\/api\/admin\/reviews\/([0-9a-f-]{36})\/approval$/i);
  if (reviewApprovalRoute && req.method==='POST') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { approved } = JSON.parse(await readBody(req)); const { approveReview } = require('./db'); await approveReview(reviewApprovalRoute[1], approved === true); return sendJson(res,200,{updated:true}); }
    catch (error) { return sendJson(res,400,{updated:false,error:error.message || 'The review could not be updated.'}); }
  }
  const reviewDeleteRoute = url.pathname.match(/^\/api\/admin\/reviews\/([0-9a-f-]{36})$/i);
  if (reviewDeleteRoute && req.method==='DELETE') { if(!validAdminSession(req))return sendJson(res,401,{error:'Please sign in to the admin panel first.'});try{const {deleteReview}=require('./db');await deleteReview(reviewDeleteRoute[1]);return sendJson(res,200,{deleted:true});}catch(error){return sendJson(res,400,{error:error.message||'Review could not be deleted.'});} }
  const refundRoute = url.pathname.match(/^\/api\/admin\/orders\/([0-9a-f-]{36})\/refund$/i);
  if (refundRoute && req.method==='POST') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { refundOrderToWallet } = require('./db'); return sendJson(res,200,{refunded:true,...await refundOrderToWallet(refundRoute[1], JSON.parse(await readBody(req)))}); }
    catch (error) { console.error('Wallet refund failed:', error.message); return sendJson(res,400,{refunded:false,error:error.message || 'The wallet refund could not be approved.'}); }
  }
  const productRoute = url.pathname.match(/^\/api\/admin\/products\/([0-9a-f-]{36})$/i);
  if (req.method==='POST' && url.pathname==='/api/admin/products') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { saveProduct } = require('./db'); return sendJson(res,201,{product:await saveProduct(JSON.parse(await readBody(req)))}); }
    catch (error) { console.error('Product create failed:', error.message); return sendJson(res,400,{error:error.message||'The product could not be saved.'}); }
  }
  if (productRoute && req.method==='PUT') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { saveProduct } = require('./db'); return sendJson(res,200,{product:await saveProduct(JSON.parse(await readBody(req)),productRoute[1])}); }
    catch (error) { console.error('Product update failed:', error.message); return sendJson(res,400,{error:error.message||'The product could not be updated.'}); }
  }
  if (productRoute && req.method==='DELETE') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { deactivateProduct } = require('./db'); await deactivateProduct(productRoute[1]); return sendJson(res,200,{removed:true}); }
    catch (error) { console.error('Product removal failed:', error.message); return sendJson(res,400,{error:error.message||'The product could not be removed.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/health/database') {
    try { const { databaseHealth } = require('./db'); return sendJson(res,200,{connected:await databaseHealth()}); }
    catch (error) { console.error('Database connection failed:', error.message); return sendJson(res,503,{connected:false,error:'Database connection is not ready.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/products') {
    try { const { listActiveProducts } = require('./db'); return sendJson(res,200,{products:await listActiveProducts()}); }
    catch (error) { console.error('Product query failed:', error.message); return sendJson(res,503,{error:'Product catalogue database is not ready.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/reviews') {
    try { const { publicReviewsBySku } = require('./db'); const reviews=await publicReviewsBySku(url.searchParams.get('sku'),url.searchParams.get('sort'));const averageRating=reviews.length?Number((reviews.reduce((sum,item)=>sum+item.rating,0)/reviews.length).toFixed(1)):0; return sendJson(res,200,{reviews,averageRating,reviewCount:reviews.length}); }
    catch (error) { console.error('Public review query failed:', error.message); return sendJson(res,503,{error:'Reviews are not available yet.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/reviews/summary') { try{const {reviewSummary}=require('./db');return sendJson(res,200,{summary:await reviewSummary((url.searchParams.get('skus')||'').split(','))});}catch{return sendJson(res,503,{summary:{}});} }
  const helpfulRoute=url.pathname.match(/^\/api\/reviews\/([0-9a-f-]{36})\/helpful$/i);
  if(helpfulRoute && req.method==='POST'){const userId=validCustomerSession(req);if(!userId)return sendJson(res,401,{error:'Sign in to mark a review helpful.'});try{const {voteReviewHelpful}=require('./db');return sendJson(res,200,{helpfulCount:await voteReviewHelpful(userId,helpfulRoute[1])});}catch(error){return sendJson(res,400,{error:error.message||'Helpful vote could not be saved.'});}}
  // Smart recommendations are first-party and non-critical: failures never affect shopping.
  if(req.method==='POST'&&url.pathname==='/api/activity/events'){try{const body=JSON.parse(await readBody(req));const {track}=require('./recommendations');const userId=validCustomerSession(req);return sendJson(res,202,await track({...body,userId:userId||null}));}catch(error){return sendJson(res,400,{recorded:false,error:error.message||'Activity event was not accepted.'});}}
  if(req.method==='GET'&&url.pathname==='/api/recommendations/home'){try{const {home}=require('./recommendations');return sendJson(res,200,await home({userId:validCustomerSession(req),sessionId:req.headers['x-mh-session']},url.searchParams.get('limit')));}catch(error){return sendJson(res,200,{continueShopping:[],recommended:[],trending:[],bestSellers:[],newArrivals:[],recentlyViewed:[]});}}
  if(req.method==='GET'&&url.pathname==='/api/recommendations/recently-viewed'){try{const {recent}=require('./recommendations');return sendJson(res,200,{products:await recent({userId:validCustomerSession(req),sessionId:req.headers['x-mh-session']},url.searchParams.get('limit'))});}catch{return sendJson(res,200,{products:[]});}}
  const recommendationProductRoute=url.pathname.match(/^\/api\/recommendations\/product\/([^/]+)$/);
  if(req.method==='GET'&&recommendationProductRoute){try{const {product}=require('./recommendations');const value=await product(decodeURIComponent(recommendationProductRoute[1]),{userId:validCustomerSession(req),sessionId:req.headers['x-mh-session']},url.searchParams.get('limit'));return value?sendJson(res,200,value):sendJson(res,404,{error:'Product not found.'});}catch{return sendJson(res,200,{similar:[],frequentlyBoughtTogether:[],recentlyViewed:[],alternatives:[]});}}
  if(req.method==='GET'&&url.pathname==='/api/admin/recommendations'){if(!validAdminSession(req))return sendJson(res,401,{error:'Please sign in to the admin panel first.'});try{const {admin}=require('./recommendations');return sendJson(res,200,await admin());}catch{return sendJson(res,200,{mostViewed:[],mostWishlisted:[],mostAddedToCart:[],recommendationClicks:[],trending:[],bestSellers:[]});}}
  if(req.method==='GET'&&url.pathname==='/api/discovery/search'){try{const {search}=require('./discovery');return sendJson(res,200,await search(url.searchParams.get('q'),url.searchParams.get('limit')));}catch{return sendJson(res,200,{products:[],categories:[],brands:[],suggestion:null});}}
  if(req.method==='POST'&&url.pathname==='/api/discovery/search-events'){try{const body=JSON.parse(await readBody(req));const {recordSearch}=require('./discovery');return sendJson(res,202,await recordSearch({...body,userId:validCustomerSession(req)||null}));}catch{return sendJson(res,202,{recorded:false});}}
  if(req.method==='GET'&&url.pathname==='/api/discovery/compare'){try{const {compare}=require('./discovery');return sendJson(res,200,await compare((url.searchParams.get('skus')||'').split(',')));}catch(error){return sendJson(res,400,{error:error.message||'Products could not be compared.'});}}
  if(req.method==='GET'&&url.pathname==='/api/admin/discovery'){if(!validAdminSession(req))return sendJson(res,401,{error:'Please sign in to the admin panel first.'});try{const {analytics}=require('./discovery');return sendJson(res,200,await analytics());}catch{return sendJson(res,200,{topSearches:[],zeroResults:[],searchCtr:[{clicks:0,searches:0}]});}}
  if(req.method==='GET'&&url.pathname==='/api/admin/bi/overview'){if(!validAdminSession(req))return sendJson(res,401,{error:'Please sign in to the admin panel first.'});try{const {value}=require('./business-intelligence');return sendJson(res,200,await value());}catch{return sendJson(res,200,{todayRevenue:0,todayOrders:0,weeklyRevenue:0,monthlyRevenue:0,averageOrderValue:0,newCustomers:0,returningCustomers:0,activeCustomers:0,repeatCustomerPercent:0,topCategory:'—',topProduct:'—',trendingProduct:'—',inventory:{outOfStock:0,lowStock:0,total:0},wishlistGrowth:0,searches:[],zeroSearches:[],searchCtr:0,trending:[],bestSellers:[],suggestions:[]});}}
  if(req.method==='GET'&&url.pathname==='/api/admin/bi/report'){if(!validAdminSession(req))return sendJson(res,401,{error:'Please sign in to the admin panel first.'});try{const {report}=require('./business-intelligence');return sendJson(res,200,await report(url.searchParams.get('period')));}catch{return sendJson(res,503,{error:'Report data is temporarily unavailable.'});}}
  if(req.method==='POST'&&url.pathname==='/api/admin/bi/assistant'){if(!validAdminSession(req))return sendJson(res,401,{error:'Please sign in to the admin panel first.'});try{const body=JSON.parse(await readBody(req));const {answer}=require('./business-intelligence');return sendJson(res,200,await answer(String(body.question||'').slice(0,140)));}catch{return sendJson(res,400,{error:'The business assistant could not answer that question.'});}}
  // Optional Custom Platform endpoints. They can be added in Shiprocket's
  // Custom Endpoints settings to allow a full catalogue refresh at any time.
  if (req.method==='GET' && url.pathname==='/api/shiprocket/catalog/products') {
    const { page, limit, from } = shiprocketPage(url);
    const categoryId = Number.parseInt(url.searchParams.get('collection_id') || '', 10);
    const categories = shiprocketCategoryFeed();
    const selectedCategory = Number.isInteger(categoryId) ? categories.find(category => category.id === categoryId)?.title : '';
    const products = shiprocketProductFeed(publicOrigin(req), selectedCategory || '');
    return sendJson(res,200,{data:{total:products.length,products:products.slice(from,from + limit),page,limit}});
  }
  if (req.method==='GET' && url.pathname==='/api/shiprocket/catalog/collections') {
    const { page, limit, from } = shiprocketPage(url);
    const collections = shiprocketCategoryFeed();
    return sendJson(res,200,{data:{total:collections.length,collections:collections.slice(from,from + limit),page,limit}});
  }
  if (req.method==='GET' && url.pathname==='/api/config/payment') return sendJson(res, 200, {ready:Boolean(config.razorpayKeyId && config.razorpayKeySecret),keyId:config.razorpayKeyId,logo:config.logo});
  if (req.method==='GET' && url.pathname==='/api/config/shipping') return sendJson(res, 200, {provider:'Delhivery',ready:Boolean(config.delhiveryToken),pickupLocation:config.delhiveryPickupLocation,cashOnDelivery:config.delhiveryCodEnabled});
  if (req.method==='GET' && url.pathname==='/api/config/shiprocket-checkout') return sendJson(res, 200, {ready:Boolean(config.shiprocketCheckoutApiKey && config.shiprocketCheckoutSecret)});
  if (req.method==='GET' && url.pathname==='/api/config/shiprocket-shipping') return sendJson(res, 200, {ready:Boolean(config.shiprocketApiEmail && config.shiprocketApiPassword && config.shiprocketChannelId),channelId:config.shiprocketChannelId || null});
  if (req.method==='GET' && url.pathname==='/api/shipping/estimate') {
    try { return sendJson(res,200,await shiprocketDeliveryEstimate(url.searchParams.get('pincode'),url.searchParams.get('weightGrams'))); }
    catch (error) { console.warn('Shiprocket delivery estimate failed:',error.message); return sendJson(res,200,{serviceable:null,message:'Delivery estimate is temporarily unavailable. Shiprocket Checkout will confirm delivery options.'}); }
  }
  if (req.method==='POST' && url.pathname==='/api/checkout/shiprocket/access-token') {
    try {
      const { cart=[] } = JSON.parse(await readBody(req));
      const items = await prepareShiprocketCart(req, cart);
      const checkout = await shiprocketCheckout('/api/v1/access-token/checkout', {
        cart_data: { items }, redirect_url: `${publicOrigin(req)}/checkout-success.html`, timestamp: new Date().toISOString()
      });
      checkoutPaymentDiagnostic(checkout);
      const token = checkout.result?.token;
      if (!token) throw new Error('Shiprocket Checkout did not return a checkout token.');
      return sendJson(res,200,{token,expiresAt:checkout.result?.expires_at || null});
    } catch (error) {
      console.error('Shiprocket Checkout start failed:', error.message);
      return sendJson(res,502,{error:error.message || 'Shiprocket Checkout could not start. Your cart is still saved.'});
    }
  }
  if (req.method==='POST' && url.pathname==='/api/webhooks/shiprocket-checkout/order') {
    try {
      const order = JSON.parse(await readBody(req));
      const { recordShiprocketOrder, reserveShiprocketShipment, completeShiprocketShipment, releaseShiprocketShipment } = require('./db');
      const saved = await recordShiprocketOrder(order);
      let shipmentCreated = false;
      if (shouldCreateShippingOrder(order) && config.shiprocketApiEmail && config.shiprocketApiPassword && config.shiprocketChannelId) {
        const reservation = await reserveShiprocketShipment(saved.id, config.shiprocketPickupLocation);
        if (reservation.reserved) {
          try {
            const shippingOrder = await shiprocketShipping('/v1/external/orders/create', shiprocketShippingPayload(order, saved));
            await completeShiprocketShipment(saved.id, shippingOrder);
            shipmentCreated = true;
          } catch (shippingError) {
            await releaseShiprocketShipment(saved.id);
            throw shippingError;
          }
        }
      }
      console.log('Shiprocket Checkout order saved:', saved.orderNumber, order.status || 'unknown');
      return sendJson(res,200,{received:true,orderNumber:saved.orderNumber,shipmentCreated});
    } catch (error) { console.error('Shiprocket checkout webhook failed:', error.message); return sendJson(res,502,{error:error.message || 'The checkout order could not be sent to Shiprocket shipping.'}); }
  }
  if (req.method==='POST' && url.pathname==='/api/webhooks/shiprocket-checkout') {
    const raw=await readBody(req);
    let payload; try { payload=JSON.parse(raw); } catch { return sendJson(res,400,{error:'Invalid webhook body.'}); }
    const trusted=shiprocketWebhookTrusted(req,raw); const details=shiprocketEventDetails(payload,raw);
    try {
      const { recordShiprocketEvent } = require('./db');
      const result=await recordShiprocketEvent({...details,trusted,status:payload.status || payload.data?.status || ''});
      console.log('Shiprocket Checkout event recorded',{event:details.type,trusted,duplicate:result.duplicate});
      return sendJson(res,200,{received:true,duplicate:Boolean(result.duplicate)});
    } catch(error) { console.error('Shiprocket Checkout event failed:',error.message); return sendJson(res,502,{error:'Webhook event could not be recorded.'}); }
  }
  if (req.method==='POST' && url.pathname==='/api/payments/razorpay/order') {
    if (!config.razorpayKeyId || !config.razorpayKeySecret) return sendJson(res, 503, {error:'Razorpay keys are not configured on the server.'});
    const {cart=[]} = JSON.parse(await readBody(req));
    if (!Array.isArray(cart) || !cart.length || cart.length>50) return sendJson(res, 400, {error:'Your cart is invalid.'});
    let totalPaise;
    try { totalPaise = calculateCartTotal(cart); }
    catch (error) { return sendJson(res,400,{error:error.message||'A cart item is no longer available.'}); }
    const receipt=`mh_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
    const order=await razorpay('/orders',{amount:totalPaise,currency:'INR',receipt,notes:{store:'MARKET HUB'}});
    return sendJson(res,200,{orderId:order.id,amount:order.amount,receipt});
  }
  if (req.method==='POST' && url.pathname==='/api/payments/razorpay/verify') {
    if (!config.razorpayKeySecret) return sendJson(res,503,{verified:false,error:'Payment verification is not configured.'});
    const {razorpay_order_id,razorpay_payment_id,razorpay_signature}=JSON.parse(await readBody(req));
    if (!razorpay_order_id||!razorpay_payment_id||!razorpay_signature) return sendJson(res,400,{verified:false,error:'Missing payment details.'});
    const expected=crypto.createHmac('sha256',config.razorpayKeySecret).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
    if (!secureEqual(expected,razorpay_signature)) return sendJson(res,400,{verified:false,error:'Payment signature did not match.'});
    // TODO: Persist the verified payment and create the customer order in PostgreSQL.
    return sendJson(res,200,{verified:true});
  }
  if (req.method==='POST' && url.pathname==='/api/webhooks/razorpay') {
    const raw=await readBody(req); const signature=req.headers['x-razorpay-signature'];
    if (!config.razorpayWebhookSecret) return sendJson(res,503,{error:'Webhook secret is not configured.'});
    const expected=crypto.createHmac('sha256',config.razorpayWebhookSecret).update(raw).digest('hex');
    if (!secureEqual(expected,signature)) return sendJson(res,400,{error:'Invalid webhook signature.'});
    // TODO: Store payment/order updates and make this handler idempotent once the database is connected.
    return sendJson(res,200,{received:true});
  }
  return false;
}

function premiumHtml(data) {
  const html=data.toString('utf8');
  if (html.includes('premium-renovation-v32.css')) return html;
  return html.replace('</head>','<link rel="stylesheet" href="/premium-renovation-v32.css"></head>').replace('</body>','<script src="/premium-renovation-v32.js" defer></script></body>');
}

http.createServer(async (req,res) => {
  try {
    const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
    if (url.pathname.startsWith('/api/')) { const handled=await handleApi(req,res,url); if (handled!==false) return; return sendJson(res,404,{error:'API route not found.'}); }
    let pathname=decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname);
    if(pathname==='/admin.html'&&!validAdminSession(req)) pathname='/admin-login.html';
    if (pathname.includes('..') || pathname.split('/').some(part=>part.startsWith('.'))) { res.writeHead(403); return res.end('Forbidden'); }
    const file=path.join(root,pathname);
    fs.readFile(file,(error,data)=>{ if(error){res.writeHead(404);return res.end('Not found');}const html=path.extname(file)==='.html'?premiumHtml(data):data;res.writeHead(200,{'Content-Type':contentTypes[path.extname(file)]||'application/octet-stream','Cache-Control':path.extname(file)==='.html'?'no-cache':'public, max-age=86400'});res.end(html); });
  } catch (error) { console.error(error); sendJson(res,500,{error:'Unexpected server error.'}); }
}).listen(config.port,()=>console.log(`MARKET HUB server: http://localhost:${config.port}`));
