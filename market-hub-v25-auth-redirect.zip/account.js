const $ = id => document.getElementById(id);
const money = value => Number(value || 0).toLocaleString('en-IN');
const message = text => $('authMessage').textContent = text || '';
const api = async (url, options = {}) => {
  const response = await fetch(url, {credentials:'same-origin', headers:{'Content-Type':'application/json', ...(options.headers || {})}, ...options});
  const body = response.status === 204 ? {} : await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || 'Please try again.');
  return body;
};
function safe(value) { const node = document.createElement('span'); node.textContent = value || ''; return node.innerHTML; }
function showDashboard(account) {
  $('accountGate').hidden = true; $('accountDashboard').hidden = false; $('logout').hidden = false;
  $('customerName').textContent = account.fullName.split(' ')[0] || 'there';
  $('walletBalance').textContent = money(account.walletBalance); $('coinBalance').textContent = money(account.coinBalance);
  $('referralCode').textContent = account.referralCode;
  $('copyCode').dataset.code = account.referralCode; $('copyCode2').dataset.code = account.referralCode;
  const activity = Array.isArray(account.walletActivity) ? account.walletActivity : [];
  $('walletEmpty').hidden = activity.length > 0;
  $('walletActivity').innerHTML = activity.map(item => `<div class="activity-row"><span><b>${safe(String(item.type).replace('_',' '))}</b><small>${safe(item.note || 'MARKET HUB wallet')}</small></span><strong>${item.type === 'debit' ? '−' : '+'}₹${money(item.amount)}</strong></div>`).join('');
  loadOrders();
  loadReturns();
  loadReviews();
}
function installAccountTools(){
  if($('profilePanel'))return;
  $('accountDashboard').insertAdjacentHTML('afterbegin',`<section class="account-tools"><article class="panel" id="profilePanel"><h2>Profile & language</h2><form id="profileForm" class="tool-form"><label>Full name<input name="fullName" required></label><label>Mobile number<input name="phone" required inputmode="numeric" pattern="[0-9]{10}"></label><label>Language<select id="languageSelect"><option value="en">English</option><option value="hi">Hindi</option><option value="gu">Gujarati</option></select></label><button>Save profile</button></form><p class="tool-message" id="profileMessage"></p></article><article class="panel" id="addressPanel"><div class="panel-title"><h2>Saved addresses</h2><button type="button" id="newAddress">Add address</button></div><div id="savedAddresses"><p class="muted">Checking saved addresses…</p></div><form id="addressForm" class="tool-form" hidden><input type="hidden" name="id"><label>Address label<input name="label" value="Home" maxlength="30"></label><label>Full name<input name="fullName" required></label><label>Mobile number<input name="phone" required inputmode="numeric"></label><label>Address<input name="line1" required placeholder="Flat, building, street"></label><label>Area (optional)<input name="line2"></label><div class="tool-pair"><label>City<input name="city" required></label><label>State<input name="state" required></label></div><label>PIN code<input name="pincode" required inputmode="numeric" maxlength="6"></label><label class="check-label"><input name="isDefault" type="checkbox"> Make this my default address</label><div class="form-actions"><button type="button" class="cancel-address">Cancel</button><button>Save address</button></div></form><p class="tool-message" id="addressMessage"></p></article></section>`);
  $('profileForm').addEventListener('submit',saveProfile); $('languageSelect').addEventListener('change',event=>{localStorage.setItem('mh_language',event.target.value); $('profileMessage').textContent='Language preference saved.';}); $('newAddress').addEventListener('click',()=>showAddressForm()); $('addressForm').addEventListener('submit',saveAddress); document.querySelector('.cancel-address').addEventListener('click',hideAddressForm);
}
async function loadAccountTools(account){const profile=$('profileForm');profile.fullName.value=account.fullName||'';profile.phone.value=account.phone||'';$('languageSelect').value=localStorage.getItem('mh_language')||'en';await loadAddresses();}
async function saveProfile(event){event.preventDefault();const button=event.currentTarget.querySelector('button');button.disabled=true;try{const data=await api('/api/customer/profile',{method:'PUT',body:JSON.stringify(Object.fromEntries(new FormData(event.currentTarget)))});$('customerName').textContent=data.profile.fullName.split(' ')[0]||'there';$('profileMessage').textContent='Profile saved successfully.';}catch(error){$('profileMessage').textContent=error.message;}finally{button.disabled=false;}}
async function loadAddresses(){try{const data=await api('/api/customer/addresses');$('savedAddresses').innerHTML=data.addresses.map(address=>`<div class="saved-address"><span><b>${safe(address.label)}${address.isDefault?' · Default':''}</b><small>${safe(address.fullName)} · ${safe(address.phone)}<br>${safe(address.line1)}${address.line2?`, ${safe(address.line2)}`:''}, ${safe(address.city)}, ${safe(address.state)} – ${safe(address.pincode)}</small></span><span><button data-edit-address="${address.id}">Edit</button><button data-delete-address="${address.id}">Remove</button></span></div>`).join('')||'<p class="muted">No saved addresses yet.</p>';$('savedAddresses')._addresses=data.addresses;}catch{$('savedAddresses').innerHTML='<p class="muted">Saved addresses will be available shortly.</p>';}}
function showAddressForm(address=null){const form=$('addressForm');form.hidden=false;form.reset();form.id.value=address?.id||'';form.label.value=address?.label||'Home';form.fullName.value=address?.fullName||$('profileForm').fullName.value;form.phone.value=address?.phone||$('profileForm').phone.value;form.line1.value=address?.line1||'';form.line2.value=address?.line2||'';form.city.value=address?.city||'';form.state.value=address?.state||'';form.pincode.value=address?.pincode||'';form.isDefault.checked=Boolean(address?.isDefault);}
function hideAddressForm(){$('addressForm').hidden=true;$('addressMessage').textContent='';}
async function saveAddress(event){event.preventDefault();const button=event.currentTarget.querySelector('.form-actions button:last-child');button.disabled=true;try{const fields=Object.fromEntries(new FormData(event.currentTarget));fields.isDefault=event.currentTarget.isDefault.checked;await api('/api/customer/addresses',{method:'POST',body:JSON.stringify(fields)});hideAddressForm();$('addressMessage').textContent='Address saved successfully.';await loadAddresses();}catch(error){$('addressMessage').textContent=error.message;}finally{button.disabled=false;}}
async function manageAddress(button){const addresses=$('savedAddresses')._addresses||[],address=addresses.find(item=>item.id===button.dataset.editAddress);if(button.dataset.editAddress)return showAddressForm(address);if(button.dataset.deleteAddress&&!confirm('Remove this saved address?'))return;try{await api(`/api/customer/addresses/${button.dataset.deleteAddress}`,{method:'DELETE'});await loadAddresses();}catch(error){$('addressMessage').textContent=error.message;}}
const dateText = value => value ? new Date(value).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'}) : 'Will be confirmed after shipping';
async function loadOrders() {
  const holder = $('customerOrders');
  try {
    const data = await api('/api/customer/orders');
    holder.innerHTML = data.orders.map(order => `<div class="order-item"><span><b>Order #MH-${order.orderNumber}</b><small>${order.itemCount} item${order.itemCount===1?'':'s'} · ₹${money(order.totalInr)} · ${safe(order.status.replace('_',' '))}</small></span><span class="delivery-date"><b>${order.status==='delivered'?'Delivered':`Expected ${dateText(order.estimatedDeliveryDate)}`}</b><small>${order.awb?`Delhivery tracking: ${safe(order.awb)}`:'Tracking will appear after shipping'}</small></span></div>`).join('') || '<p class="muted">You have no orders yet. Start shopping to see delivery details here.</p>';
    [...holder.querySelectorAll('.order-item')].forEach((node,index)=>{const order=data.orders[index];if(order.awb)node.querySelector('.delivery-date').insertAdjacentHTML('beforeend',`<a class="track-link" target="_blank" rel="noopener" href="https://www.delhivery.com/track/package/${encodeURIComponent(order.awb)}">Track this order →</a>`);if(order.packingVideoUrl)node.querySelector('span').insertAdjacentHTML('beforeend',`<details class="packing-video"><summary>View packing video</summary><video controls preload="metadata" src="${safe(order.packingVideoUrl)}"></video>${order.packingVideoNote?`<small>${safe(order.packingVideoNote)}</small>`:''}</details>`);});
  } catch { holder.innerHTML = '<p class="muted">Orders will appear here after checkout.</p>'; }
}
async function loadReturns() {
  const holder = $('returnItems');
  try {
    const data = await api('/api/customer/returns');
    holder.innerHTML = data.items.map(item => `<div class="return-item"><span><b>${safe(item.productName)}</b><small>Order #MH-${item.orderNumber} · ${item.quantity} item${item.quantity===1?'':'s'}</small></span>${item.returnStatus?`<em>${safe(item.returnStatus.replace('_',' '))}</em>`:`<button data-return-item="${item.orderItemId}" data-product="${safe(item.productName)}">Request return</button>`}</div>`).join('') || '<p class="muted">You have no delivered products eligible for return right now.</p>';
  } catch { holder.innerHTML = '<p class="muted">Returns will appear here after a delivered order.</p>'; }
}
async function requestReturn(button) {
  const reason = prompt(`Why do you want to return ${button.dataset.product}?`); if (reason === null) return;
  const details = prompt('Add any extra details (optional):') || '';
  button.disabled = true;
  try { await api('/api/customer/returns', {method:'POST',body:JSON.stringify({orderItemId:button.dataset.returnItem,reason,details})}); alert('Your return request has been sent for review.'); await loadReturns(); }
  catch (error) { alert(error.message); } finally { button.disabled = false; }
}
let reviewableItems = [];
async function loadReviews() {
  const holder = $('reviewItems'), form = $('reviewForm'), select = $('reviewOrderItem');
  if (!holder || !form || !select) return;
  try {
    const data = await api('/api/customer/reviews');
    reviewableItems = (data.items || []).filter(item => !item.reviewed);
    if (!reviewableItems.length) {
      form.hidden = true;
      holder.innerHTML = '<p class="muted">You have no delivered products ready for review right now.</p>';
      return;
    }
    holder.innerHTML = `<p class="muted">${reviewableItems.length} delivered product${reviewableItems.length === 1 ? '' : 's'} ready for your review.</p>`;
    select.innerHTML = reviewableItems.map(item => `<option value="${item.orderItemId}">${safe(item.productName)} — Order #MH-${item.orderNumber}</option>`).join('');
    form.hidden = false;
  } catch { form.hidden = true; holder.innerHTML = '<p class="muted">Reviews will appear here after a delivered order.</p>'; }
}
function photoData(file) {
  return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(file); });
}
async function submitReview(event) {
  event.preventDefault();
  const form = event.currentTarget, button = form.querySelector('button'), photos = [...$('reviewPhotos').files];
  $('reviewMessage').textContent = '';
  if (photos.length > 3 || photos.some(photo => photo.size > 500 * 1024 || !['image/jpeg','image/png','image/webp'].includes(photo.type))) { $('reviewMessage').textContent = 'Use up to 3 JPG, PNG or WebP photos under 500 KB each.'; return; }
  button.disabled = true; button.textContent = 'Sending review…';
  try {
    await api('/api/customer/reviews', {method:'POST',body:JSON.stringify({orderItemId:$('reviewOrderItem').value,rating:Number($('reviewRating').value),body:$('reviewBody').value,images:await Promise.all(photos.map(photoData))})});
    form.reset(); $('reviewMessage').textContent = 'Thank you. Your review was sent for approval.'; await loadReviews();
  } catch (error) { $('reviewMessage').textContent = error.message; } finally { button.disabled = false; button.textContent = 'Send review'; }
}
async function loadAccount() {
  try { const data = await api('/api/customer/account'); if (data.authenticated) { showDashboard(data.account); installAccountTools(); loadAccountTools(data.account); } }
  catch { $('accountGate').hidden = false; }
}
function prepareAuthForms() {
  document.head.insertAdjacentHTML('beforeend', '<style>.auth-card form[hidden]{display:none!important}</style>');
  const title = document.querySelector('.auth-card-head h2'), subtitle = document.querySelector('.auth-card-head p');
  if (title) title.id = 'authTitle'; if (subtitle) subtitle.id = 'authSubtitle';
  document.querySelector('#loginForm .auth-help')?.remove();
  const registerForm = $('registerForm');
  if (registerForm && !registerForm.querySelector('[name="phone"]')) {
    const emailLabel = registerForm.querySelector('[name="email"]')?.closest('label');
    emailLabel?.insertAdjacentHTML('beforebegin', '<label>Phone number<input name="phone" type="tel" required autocomplete="tel" inputmode="numeric" pattern="[0-9]{10}" placeholder="Enter 10-digit mobile number"></label>');
  }
}
prepareAuthForms();
document.querySelectorAll('[data-mode]').forEach(button => button.addEventListener('click', () => {
  document.querySelectorAll('[data-mode]').forEach(tab => tab.classList.toggle('active', tab === button));
  $('loginForm').hidden = button.dataset.mode !== 'login'; $('registerForm').hidden = button.dataset.mode !== 'register'; message('');
  const signingIn = button.dataset.mode === 'login';
  $('authTitle').textContent = signingIn ? 'Welcome back' : 'Create your account';
  $('authSubtitle').textContent = signingIn ? 'Sign in to continue shopping and see your rewards.' : 'Create an account to track orders, refunds and MARKET HUB Coins.';
}));
async function submitForm(form, endpoint) {
  const button = form.querySelector('button'); button.disabled = true; message('');
  try {
    const fields = Object.fromEntries(new FormData(form));
    await api(endpoint, {method:'POST', body:JSON.stringify(fields)});
    // A successful sign-in should take customers back to shopping.  Checkout
    // keeps the cart open so they can continue the purchase they started.
    location.href = new URLSearchParams(location.search).get('return') === 'checkout'
      ? 'index.html?cart=open'
      : 'index.html?welcome=1';
  } catch (error) { message(error.message); } finally { button.disabled = false; }
}
$('loginForm').addEventListener('submit', event => { event.preventDefault(); submitForm(event.currentTarget, '/api/auth/customer/login'); });
$('registerForm').addEventListener('submit', event => { event.preventDefault(); submitForm(event.currentTarget, '/api/auth/customer/register'); });
async function shareCode(event) {
  const code = event.currentTarget.dataset.code; if (!code) return;
  const text = `Join MARKET HUB with my referral code ${code} and earn 10 coins after your first delivered order!`;
  try { if (navigator.share) await navigator.share({title:'MARKET HUB',text,url:location.origin}); else { await navigator.clipboard.writeText(text); alert('Referral message copied.'); } } catch {}
}
$('copyCode').addEventListener('click', shareCode); $('copyCode2').addEventListener('click', shareCode);
$('logout').addEventListener('click', async () => { await api('/api/auth/customer/logout', {method:'POST'}); location.reload(); });
$('reviewForm')?.addEventListener('submit', submitReview);
document.addEventListener('click', event => { const button = event.target.closest('[data-return-item]'); if (button) requestReturn(button); const addressButton=event.target.closest('[data-edit-address],[data-delete-address]');if(addressButton)manageAddress(addressButton); });
if(new URLSearchParams(location.search).get('mode')==='register')document.querySelector('[data-mode="register"]')?.click();
loadAccount();
