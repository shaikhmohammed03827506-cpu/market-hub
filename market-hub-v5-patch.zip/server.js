/* MARKET HUB local server and secure payment foundation.
   Keep .env private. It must never be uploaded with the public website files. */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = __dirname;
const envPath = path.join(root, '.env');
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
  }
}

const config = {
  port: Number(process.env.PORT || 4173),
  databaseUrl: process.env.DATABASE_URL || '',
  razorpayKeyId: process.env.RAZORPAY_KEY_ID || '',
  razorpayKeySecret: process.env.RAZORPAY_KEY_SECRET || '',
  razorpayWebhookSecret: process.env.RAZORPAY_WEBHOOK_SECRET || '',
  delhiveryToken: process.env.DELHIVERY_API_TOKEN || '',
  delhiveryPickupLocation: process.env.DELHIVERY_PICKUP_LOCATION || '',
  delhiveryCodEnabled: process.env.DELHIVERY_COD_ENABLED === 'true',
  adminEmail: (process.env.ADMIN_EMAIL || '').trim().toLowerCase(),
  adminPassword: process.env.ADMIN_PASSWORD || '',
  logo: process.env.STORE_LOGO_URL || ''
};

// Small demo-price fallback. The catalogue price is calculated on the server below.
const priceCatalog = new Map([
  [1, 899], [2, 349], [3, 399], [4, 649], [5, 1799], [6, 299], [7, 999], [8, 799]
]);
const contentTypes = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.json':'application/json; charset=utf-8'};
const sendJson = (res, status, body) => { res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}); res.end(JSON.stringify(body)); };
const readBody = req => new Promise((resolve, reject) => { let body=''; req.on('data', chunk => { body += chunk; if (body.length > 1_000_000) { reject(new Error('Request too large')); req.destroy(); } }); req.on('end', () => resolve(body)); req.on('error', reject); });
const secureEqual = (first, second) => { const a=Buffer.from(first||''), b=Buffer.from(second||''); return a.length===b.length && crypto.timingSafeEqual(a,b); };
const adminSessions = new Map();
const parseCookies = request => Object.fromEntries((request.headers.cookie||'').split(';').map(item=>item.trim()).filter(Boolean).map(item=>{const point=item.indexOf('=');return point<0?[item,'']:[item.slice(0,point),decodeURIComponent(item.slice(point+1))]}));
const validAdminSession = request => { const token=parseCookies(request).mh_admin_session; const session=token&&adminSessions.get(token); if(!session||session.expiresAt<Date.now()){if(token)adminSessions.delete(token);return false}return true; };
const makeAdminSession = () => { const token=crypto.randomBytes(32).toString('base64url'); adminSessions.set(token,{expiresAt:Date.now()+8*60*60*1000}); return token; };
const adminCookie = (request,token) => `mh_admin_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800${request.headers['x-forwarded-proto']==='https'||request.socket.encrypted?'; Secure':''}`;

async function razorpay(endpoint, body) {
  const authorization = Buffer.from(`${config.razorpayKeyId}:${config.razorpayKeySecret}`).toString('base64');
  const response = await fetch(`https://api.razorpay.com/v1${endpoint}`, {method:'POST',headers:{'Authorization':`Basic ${authorization}`,'Content-Type':'application/json'},body:JSON.stringify(body)});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.description || 'Razorpay could not create the payment order.');
  return data;
}

// Never trust a product price submitted by the customer's browser.
let cataloguePriceBySku;
function cataloguePrices() {
  if (cataloguePriceBySku) return cataloguePriceBySku;
  const cataloguePath = path.join(root, 'assets', 'catalogue', 'products.json');
  const items = JSON.parse(fs.readFileSync(cataloguePath, 'utf8'));
  cataloguePriceBySku = new Map(items.map(item => [String(item.sku), {
    price: Number(item.price_inr), stock: Number(item.stock_quantity)
  }]));
  return cataloguePriceBySku;
}

function calculateCartTotal(cart) {
  let totalPaise = 0;
  const catalogue = cataloguePrices();
  for (const item of cart) {
    const qty = Number(item.qty);
    if (!Number.isInteger(qty) || qty < 1 || qty > 99) throw new Error('A cart quantity is invalid.');
    const sku = String(item.sku || '').trim();
    const catalogueItem = sku && catalogue.get(sku);
    if (catalogueItem) {
      if (qty > catalogueItem.stock) throw new Error('One of these products no longer has enough stock.');
      totalPaise += Math.round(catalogueItem.price * 100) * qty;
      continue;
    }
    const legacyId = Number(item.id);
    if (!Number.isInteger(legacyId) || !priceCatalog.has(legacyId)) throw new Error('A cart item is no longer available.');
    totalPaise += priceCatalog.get(legacyId) * 100 * qty;
  }
  return totalPaise;
}

async function handleApi(req, res, url) {
  if (req.method==='POST' && url.pathname==='/api/auth/admin/login') {
    const {email='',password=''}=JSON.parse(await readBody(req));
    if(!config.adminEmail||!config.adminPassword) return sendJson(res,503,{authenticated:false,error:'Admin login is not configured.'});
    if(!secureEqual(String(email).trim().toLowerCase(),config.adminEmail)||!secureEqual(String(password),config.adminPassword)) return sendJson(res,401,{authenticated:false,error:'Email or password is incorrect.'});
    res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Set-Cookie':adminCookie(req,makeAdminSession()),'Cache-Control':'no-store'});return res.end(JSON.stringify({authenticated:true}));
  }
  if (req.method==='GET' && url.pathname==='/api/auth/admin/session') return sendJson(res,200,{authenticated:validAdminSession(req)});
  if (req.method==='POST' && url.pathname==='/api/auth/admin/logout') { const token=parseCookies(req).mh_admin_session;if(token)adminSessions.delete(token);res.writeHead(204,{'Set-Cookie':'mh_admin_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});return res.end(); }
  if (req.method==='POST' && url.pathname==='/api/admin/catalogue/import') {
    if (!validAdminSession(req)) return sendJson(res,401,{imported:false,error:'Please sign in to the admin panel first.'});
    try {
      const { importPdfCatalogue } = require('./db');
      const result = await importPdfCatalogue();
      return sendJson(res,200,{imported:true,...result});
    } catch (error) {
      console.error('Catalogue import failed:', error.message);
      return sendJson(res,503,{imported:false,error:'The catalogue could not be imported. Confirm the live database connection and try again.'});
    }
  }
  if (req.method==='GET' && url.pathname==='/api/admin/products') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { listAdminProducts } = require('./db'); return sendJson(res,200,{products:await listAdminProducts()}); }
    catch (error) { console.error('Admin product query failed:', error.message); return sendJson(res,503,{error:'The product database is not ready yet.'}); }
  }
  const productRoute = url.pathname.match(/^\/api\/admin\/products\/([0-9a-f-]{36})$/i);
  if (req.method==='POST' && url.pathname==='/api/admin/products') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { saveProduct } = require('./db'); return sendJson(res,201,{product:await saveProduct(JSON.parse(await readBody(req)))}); }
    catch (error) { console.error('Product create failed:', error.message); return sendJson(res,400,{error:error.message||'The product could not be saved.'}); }
  }
  if (productRoute && req.method==='PUT') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { saveProduct } = require('./db'); return sendJson(res,200,{product:await saveProduct(JSON.parse(await readBody(req)),productRoute[1])}); }
    catch (error) { console.error('Product update failed:', error.message); return sendJson(res,400,{error:error.message||'The product could not be updated.'}); }
  }
  if (productRoute && req.method==='DELETE') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { deactivateProduct } = require('./db'); await deactivateProduct(productRoute[1]); return sendJson(res,200,{removed:true}); }
    catch (error) { console.error('Product removal failed:', error.message); return sendJson(res,400,{error:error.message||'The product could not be removed.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/health/database') {
    try { const { databaseHealth } = require('./db'); return sendJson(res,200,{connected:await databaseHealth()}); }
    catch (error) { console.error('Database connection failed:', error.message); return sendJson(res,503,{connected:false,error:'Database connection is not ready.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/products') {
    try { const { listActiveProducts } = require('./db'); return sendJson(res,200,{products:await listActiveProducts()}); }
    catch (error) { console.error('Product query failed:', error.message); return sendJson(res,503,{error:'Product catalogue database is not ready.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/config/payment') return sendJson(res, 200, {ready:Boolean(config.razorpayKeyId && config.razorpayKeySecret),keyId:config.razorpayKeyId,logo:config.logo});
  if (req.method==='GET' && url.pathname==='/api/config/shipping') return sendJson(res, 200, {provider:'Delhivery',ready:Boolean(config.delhiveryToken),pickupLocation:config.delhiveryPickupLocation,cashOnDelivery:config.delhiveryCodEnabled});
  if (req.method==='POST' && url.pathname==='/api/payments/razorpay/order') {
    if (!config.razorpayKeyId || !config.razorpayKeySecret) return sendJson(res, 503, {error:'Razorpay keys are not configured on the server.'});
    const {cart=[]} = JSON.parse(await readBody(req));
    if (!Array.isArray(cart) || !cart.length || cart.length>50) return sendJson(res, 400, {error:'Your cart is invalid.'});
    let totalPaise;
    try { totalPaise = calculateCartTotal(cart); }
    catch (error) { return sendJson(res,400,{error:error.message||'A cart item is no longer available.'}); }
    const receipt=`mh_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
    const order=await razorpay('/orders',{amount:totalPaise,currency:'INR',receipt,notes:{store:'MARKET HUB'}});
    return sendJson(res,200,{orderId:order.id,amount:order.amount,receipt});
  }
  if (req.method==='POST' && url.pathname==='/api/payments/razorpay/verify') {
    if (!config.razorpayKeySecret) return sendJson(res,503,{verified:false,error:'Payment verification is not configured.'});
    const {razorpay_order_id,razorpay_payment_id,razorpay_signature}=JSON.parse(await readBody(req));
    if (!razorpay_order_id||!razorpay_payment_id||!razorpay_signature) return sendJson(res,400,{verified:false,error:'Missing payment details.'});
    const expected=crypto.createHmac('sha256',config.razorpayKeySecret).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
    if (!secureEqual(expected,razorpay_signature)) return sendJson(res,400,{verified:false,error:'Payment signature did not match.'});
    // TODO: Persist the verified payment and create the customer order in PostgreSQL.
    return sendJson(res,200,{verified:true});
  }
  if (req.method==='POST' && url.pathname==='/api/webhooks/razorpay') {
    const raw=await readBody(req); const signature=req.headers['x-razorpay-signature'];
    if (!config.razorpayWebhookSecret) return sendJson(res,503,{error:'Webhook secret is not configured.'});
    const expected=crypto.createHmac('sha256',config.razorpayWebhookSecret).update(raw).digest('hex');
    if (!secureEqual(expected,signature)) return sendJson(res,400,{error:'Invalid webhook signature.'});
    // TODO: Store payment/order updates and make this handler idempotent once the database is connected.
    return sendJson(res,200,{received:true});
  }
  return false;
}

http.createServer(async (req,res) => {
  try {
    const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
    if (url.pathname.startsWith('/api/')) { const handled=await handleApi(req,res,url); if (handled!==false) return; return sendJson(res,404,{error:'API route not found.'}); }
    let pathname=decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname);
    if(pathname==='/admin.html'&&!validAdminSession(req)) pathname='/admin-login.html';
    if (pathname.includes('..') || pathname.split('/').some(part=>part.startsWith('.'))) { res.writeHead(403); return res.end('Forbidden'); }
    const file=path.join(root,pathname);
    fs.readFile(file,(error,data)=>{ if(error){res.writeHead(404);return res.end('Not found');}res.writeHead(200,{'Content-Type':contentTypes[path.extname(file)]||'application/octet-stream'});res.end(data); });
  } catch (error) { console.error(error); sendJson(res,500,{error:'Unexpected server error.'}); }
}).listen(config.port,()=>console.log(`MARKET HUB server: http://localhost:${config.port}`));
