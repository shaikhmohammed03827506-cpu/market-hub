// Server-only PostgreSQL access. DATABASE_URL must exist only in .env or hosting secrets.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
let pool;
let orderSchemaReady;
let rewardsSchemaReady;
let customerExperienceSchemaReady;

function database() {
  if (!process.env.DATABASE_URL) throw new Error('Database is not configured. Add DATABASE_URL to the private .env file.');
  if (!pool) {
    const { Pool } = require('pg');
    pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: { rejectUnauthorized: false },
      max: 8,
      idleTimeoutMillis: 20_000
    });
  }
  return pool;
}

async function databaseHealth() {
  const result = await database().query('select now() as connected_at');
  return Boolean(result.rows[0]);
}

const productFields = `
  select p.id, p.sku, p.name, p.slug, p.description, p.specifications, p.price_inr,
         p.compare_at_price_inr, p.stock_quantity, p.weight_kg, p.is_active,
         coalesce(c.name, 'Uncategorized') as category,
         coalesce(jsonb_agg(jsonb_build_object('url', pi.url, 'alt_text', pi.alt_text, 'sort_order', pi.sort_order)
           order by pi.sort_order) filter (where pi.id is not null), '[]'::jsonb) as images
  from products p
  left join categories c on c.id = p.category_id
  left join product_images pi on pi.product_id = p.id
`;

const productGroup = ' group by p.id, c.name';
const serializeProduct = row => {
  const images = Array.isArray(row.images) ? row.images.map(image => image.url).filter(Boolean) : [];
  return {
    id: row.id, sku: row.sku, name: row.name, slug: row.slug, category: row.category,
    description: row.description || '', price_inr: Number(row.price_inr),
    compare_at_price_inr: row.compare_at_price_inr == null ? null : Number(row.compare_at_price_inr),
    stock_quantity: Number(row.stock_quantity), weight_grams: Math.round(Number(row.weight_kg) * 1000),
    is_active: row.is_active, image_url: images[0] || '', gallery: images,
    video_url: row.specifications?.video_url || ''
  };
};

async function listActiveProducts() {
  const result = await database().query(`${productFields} where p.is_active = true${productGroup} order by p.created_at desc limit 5000`);
  return result.rows.map(serializeProduct);
}

async function listAdminProducts() {
  const result = await database().query(`${productFields}${productGroup} order by p.updated_at desc limit 5000`);
  return result.rows.map(serializeProduct);
}

const toSlug = value => String(value).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

const isWebUrl = value => /^https?:\/\/\S+$/i.test(String(value || '').trim());
function productInput(input) {
  const name = String(input.name || '').trim();
  const category = String(input.category || '').trim();
  const sku = String(input.sku || '').trim();
  const description = String(input.description || '').trim();
  const price = Number(input.price);
  const stock = Number(input.stock);
  const weightGrams = Number(input.weight_grams);
  const images = Array.isArray(input.images) ? input.images.map(value => String(value).trim()).filter(Boolean) : [];
  const videoUrl = String(input.video_url || '').trim();
  if (!name || name.length > 180 || !category || category.length > 80 || !sku || sku.length > 80) throw new Error('Enter a product name, category and SKU.');
  if (!Number.isFinite(price) || price <= 0 || price > 10000000) throw new Error('Enter a valid product price.');
  if (!Number.isInteger(stock) || stock < 0 || stock > 1000000) throw new Error('Enter a valid stock quantity.');
  if (!Number.isFinite(weightGrams) || weightGrams < 1 || weightGrams > 100000) throw new Error('Enter a valid weight in grams.');
  if (!images.length || images.length > 12 || images.some(url => !isWebUrl(url))) throw new Error('Add 1 to 12 valid photo links starting with https://.');
  if (videoUrl && !isWebUrl(videoUrl)) throw new Error('The video link must start with https://.');
  return { name, category, sku, description, price, stock, weightGrams, images, videoUrl };
}

async function saveProduct(input, productId = null) {
  const value = productInput(input);
  const client = await database().connect();
  try {
    await client.query('begin');
    const category = await client.query(
      'insert into categories (name, slug) values ($1, $2) on conflict (slug) do update set name = excluded.name, is_active = true returning id',
      [value.category, toSlug(value.category)]
    );
    const specification = JSON.stringify(value.videoUrl ? { video_url: value.videoUrl } : {});
    let result;
    if (productId) {
      result = await client.query(
        `update products set category_id=$1, sku=$2, name=$3, description=$4, specifications=$5::jsonb,
         price_inr=$6, stock_quantity=$7, weight_kg=$8, is_active=true, updated_at=now() where id=$9 returning id`,
        [category.rows[0].id, value.sku, value.name, value.description, specification, value.price, value.stock, value.weightGrams / 1000, productId]
      );
      if (!result.rowCount) throw new Error('This product no longer exists.');
      await client.query('delete from product_images where product_id=$1', [productId]);
    } else {
      const slugBase = toSlug(value.name) || 'product';
      result = await client.query(
        `insert into products (category_id, sku, name, slug, description, specifications, price_inr, stock_quantity, weight_kg)
         values ($1,$2,$3,$4,$5,$6::jsonb,$7,$8,$9) returning id`,
        [category.rows[0].id, value.sku, value.name, `${slugBase}-${toSlug(value.sku)}`, value.description, specification, value.price, value.stock, value.weightGrams / 1000]
      );
    }
    const id = result.rows[0].id;
    for (const [sortOrder, url] of value.images.entries()) {
      await client.query('insert into product_images (product_id, url, alt_text, sort_order) values ($1,$2,$3,$4)', [id, url, value.name, sortOrder]);
    }
    await client.query('commit');
    const saved = await database().query(`${productFields} where p.id=$1${productGroup}`, [id]);
    return serializeProduct(saved.rows[0]);
  } catch (error) {
    await client.query('rollback');
    if (error.code === '23505') throw new Error('This SKU is already being used. Choose a different SKU.');
    throw error;
  } finally {
    client.release();
  }
}

async function deactivateProduct(productId) {
  const result = await database().query('update products set is_active=false, updated_at=now() where id=$1 returning id', [productId]);
  if (!result.rowCount) throw new Error('This product no longer exists.');
}

// The original starter schema used whole numbers for order totals. Supplier
// prices can include paise, so this small migration keeps every order amount
// accurate and can safely run on an existing store database.
async function ensureOrderSchema() {
  if (orderSchemaReady) return orderSchemaReady;
  orderSchemaReady = (async () => {
    const client = await database().connect();
    try {
      await client.query('begin');
      await client.query('alter table orders alter column subtotal_inr type numeric(10,2) using subtotal_inr::numeric(10,2)');
      await client.query('alter table orders alter column discount_inr type numeric(10,2) using discount_inr::numeric(10,2)');
      await client.query('alter table orders alter column wallet_used_inr type numeric(10,2) using wallet_used_inr::numeric(10,2)');
      await client.query('alter table orders alter column shipping_inr type numeric(10,2) using shipping_inr::numeric(10,2)');
      await client.query('alter table orders alter column total_inr type numeric(10,2) using total_inr::numeric(10,2)');
      await client.query('alter table order_items alter column unit_price_inr type numeric(10,2) using unit_price_inr::numeric(10,2)');
      await client.query('alter table orders drop constraint if exists orders_payment_method_check');
      await client.query("alter table orders add constraint orders_payment_method_check check (payment_method in ('shiprocket','cod','wallet','razorpay'))");
      await client.query('create unique index if not exists orders_shiprocket_order_unique on orders(shiprocket_order_id) where shiprocket_order_id is not null');
      await client.query('alter table orders add column if not exists packing_video_url text');
      await client.query('alter table orders add column if not exists packing_video_note text');
      await client.query('alter table orders add column if not exists packing_video_uploaded_at timestamptz');
      await client.query('alter table shipments add column if not exists provider_order_id text');
      await client.query('create unique index if not exists shipments_provider_order_unique on shipments(provider, provider_order_id) where provider_order_id is not null');
      await client.query('commit');
    } catch (error) {
      await client.query('rollback');
      orderSchemaReady = undefined;
      throw error;
    } finally { client.release(); }
  })();
  return orderSchemaReady;
}

const moneyValue = value => Math.max(0, Number(value || 0)).toFixed(2);
const statusForShiprocket = value => ({ SUCCESS: 'confirmed', FAILED: 'cancelled' }[String(value || '').toUpperCase()] || 'pending');
const paymentForShiprocket = value => ({ SUCCESS: 'paid', FAILED: 'failed', PENDING: 'cod_pending' }[String(value || '').toUpperCase()] || 'pending');
const newReferralCode = () => `MH${crypto.randomBytes(5).toString('hex').toUpperCase()}`;

async function findOrCreateCustomer(client, order) {
  const phone = String(order.phone || order.shipping_address?.phone || '').replace(/\D/g, '').slice(-10);
  const email = String(order.email || order.shipping_address?.email || '').trim().toLowerCase() || null;
  const name = [order.shipping_address?.first_name, order.shipping_address?.last_name].filter(Boolean).join(' ').trim() || 'MARKET HUB customer';
  if (!phone && !email) throw new Error('The checkout order is missing customer contact information.');
  const existing = phone ? await client.query('select id from users where phone=$1', [phone]) : await client.query('select id from users where email=$1', [email]);
  if (existing.rowCount) return existing.rows[0].id;
  const created = await client.query(
    'insert into users (full_name,email,phone,referral_code) values ($1,$2,$3,$4) returning id',
    [name, email, phone || null, newReferralCode()]
  );
  return created.rows[0].id;
}

async function saveOrderAddress(client, userId, order) {
  const address = order.shipping_address || {};
  const pincode = String(address.pincode || '').replace(/\D/g, '').slice(0, 6);
  if (!pincode || !address.line1 || !address.city || !address.state) return null;
  const name = [address.first_name, address.last_name].filter(Boolean).join(' ').trim() || 'MARKET HUB customer';
  const phone = String(address.phone || order.phone || '').replace(/\D/g, '').slice(-10) || '0000000000';
  const saved = await client.query(
    `insert into addresses (user_id,label,full_name,phone,line1,line2,city,state,pincode,is_default)
     values ($1,'Checkout',$2,$3,$4,$5,$6,$7,$8,false) returning id`,
    [userId, name, phone, String(address.line1), address.line2 || null, String(address.city), String(address.state), pincode]
  );
  return saved.rows[0].id;
}

function supplierCatalogueById() {
  const cataloguePath = path.join(__dirname, 'assets', 'catalogue', 'products.json');
  const products = JSON.parse(fs.readFileSync(cataloguePath, 'utf8'));
  return new Map(products.map(product => [String(product.id), product]));
}

async function recordShiprocketOrder(order) {
  if (!order?.order_id) throw new Error('The checkout order id is missing.');
  await ensureOrderSchema();
  await ensureCustomerExperienceSchema();
  const client = await database().connect();
  try {
    await client.query('begin');
    const userId = await findOrCreateCustomer(client, order);
    const addressId = await saveOrderAddress(client, userId, order);
    const paymentType = String(order.payment_type || '').toUpperCase();
    const orderResult = await client.query(
      `insert into orders (user_id,address_id,status,payment_status,payment_method,subtotal_inr,discount_inr,wallet_used_inr,coins_used,shipping_inr,total_inr,shiprocket_order_id)
       values ($1,$2,$3,$4,$5,$6,$7,0,0,$8,$9,$10)
       on conflict (shiprocket_order_id) where shiprocket_order_id is not null do update set
         status=excluded.status,payment_status=excluded.payment_status,payment_method=excluded.payment_method,
         subtotal_inr=excluded.subtotal_inr,discount_inr=excluded.discount_inr,shipping_inr=excluded.shipping_inr,total_inr=excluded.total_inr
       returning id,order_number`,
      [userId, addressId, statusForShiprocket(order.status), paymentForShiprocket(order.payment_status), paymentType === 'CASH_ON_DELIVERY' ? 'cod' : 'shiprocket', moneyValue(order.subtotal_price), moneyValue(order.total_discount), moneyValue(order.cod_charges), moneyValue(order.total_amount_payable), String(order.order_id)]
    );
    const savedOrder = orderResult.rows[0];
    await client.query('delete from order_items where order_id=$1', [savedOrder.id]);
    const supplierProducts = supplierCatalogueById();
    const itemIds = (order.cart_data?.items || []).map(item => String(item.variant_id));
    const products = itemIds.length ? await client.query('select id,sku,name,price_inr from products where sku = any($1::text[])', [Array.from(supplierProducts.values()).filter(product => itemIds.includes(String(product.id))).map(product => product.sku)]) : { rows: [] };
    const databaseProducts = new Map(products.rows.map(product => [product.sku, product]));
    for (const item of order.cart_data?.items || []) {
      const supplierProduct = supplierProducts.get(String(item.variant_id));
      if (!supplierProduct) continue;
      const product = databaseProducts.get(supplierProduct.sku);
      await client.query(
        'insert into order_items (order_id,product_id,product_name,sku,unit_price_inr,quantity,coin_reward) values ($1,$2,$3,$4,$5,$6,0)',
        [savedOrder.id, product?.id || null, product?.name || supplierProduct.name, supplierProduct.sku, moneyValue(product?.price_inr || supplierProduct.price_inr), Math.max(1, Number(item.quantity || 1))]
      );
    }
    const pendingCoins = await createPendingOrderCoins(client, savedOrder.id, userId, order.subtotal_price);
    await client.query('commit');
    return { id: savedOrder.id, orderNumber: savedOrder.order_number, pendingCoins };
  } catch (error) {
    await client.query('rollback');
    throw error;
  } finally { client.release(); }
}

// Reserve the one Shiprocket shipment record before calling the remote API.
// This makes checkout webhook retries safe: only the first delivery creates an
// external shipping order for the local order.
async function reserveShiprocketShipment(orderId, pickupLocation) {
  await ensureOrderSchema();
  const result = await database().query(
    `insert into shipments (order_id,provider,pickup_location,tracking_status)
     values ($1,'shiprocket',$2,'creating')
     on conflict (order_id) do nothing returning id`,
    [orderId, pickupLocation || 'Default Shiprocket pickup']
  );
  return { reserved: Boolean(result.rowCount) };
}

async function completeShiprocketShipment(orderId, payload) {
  await ensureOrderSchema();
  const response = payload || {};
  const providerOrderId = response.order_id || response.data?.order_id || null;
  const shipmentId = response.shipment_id || response.data?.shipment_id || null;
  const awb = response.awb_code || response.data?.awb_code || null;
  const tracking = response.status || response.data?.status || (shipmentId ? 'created' : 'processing');
  await database().query(
    `update shipments set provider_order_id=$2,awb=coalesce($3,awb),tracking_status=$4,raw_tracking=$5::jsonb,updated_at=now()
      where order_id=$1 and provider='shiprocket'`,
    [orderId, providerOrderId ? String(providerOrderId) : (shipmentId ? String(shipmentId) : null), awb ? String(awb) : null, String(tracking), JSON.stringify(response)]
  );
}

async function releaseShiprocketShipment(orderId) {
  await ensureOrderSchema();
  await database().query("delete from shipments where order_id=$1 and provider='shiprocket' and tracking_status='creating'", [orderId]);
}

async function listAdminOrders() {
  await ensureOrderSchema();
  const result = await database().query(
    `select o.id,o.order_number,o.status,o.payment_status,o.payment_method,o.total_inr,o.created_at,o.packing_video_url,o.packing_video_note,o.packing_video_uploaded_at,
            u.full_name,u.email,u.phone,coalesce(count(oi.id),0)::integer as item_count
       from orders o join users u on u.id=o.user_id left join order_items oi on oi.order_id=o.id
      group by o.id,u.full_name,u.email,u.phone order by o.created_at desc limit 500`
  );
  return result.rows.map(order => ({ id: order.id, order_number: Number(order.order_number), status: order.status, payment_status: order.payment_status, payment_method: order.payment_method, total_inr: Number(order.total_inr), created_at: order.created_at, customer: order.full_name, email: order.email, phone: order.phone, item_count: order.item_count, packing_video_url: order.packing_video_url || '', packing_video_note: order.packing_video_note || '', packing_video_uploaded_at: order.packing_video_uploaded_at || null }));
}

function packingVideoInput(input) {
  const url = String(input.videoUrl || '').trim();
  const note = String(input.note || '').trim().slice(0, 300);
  const remoteVideo = /^https:\/\/\S+$/i.test(url);
  const uploadedVideo = /^data:video\/(mp4|webm|quicktime);base64,[a-z0-9+/=]+$/i.test(url) && url.length <= 5_600_000;
  if (url && !remoteVideo && !uploadedVideo) throw new Error('Choose a video up to 4 MB, or enter a secure https video link.');
  return { url, note };
}

async function savePackingVideo(orderId, input) {
  await ensureOrderSchema();
  const value = packingVideoInput(input);
  const result = await database().query(
    "update orders set packing_video_url=$2, packing_video_note=$3, packing_video_uploaded_at=case when $2='' then null else now() end where id=$1 returning id,order_number,packing_video_url,packing_video_note,packing_video_uploaded_at",
    [orderId, value.url || '', value.note || null]
  );
  if (!result.rowCount) throw new Error('This order no longer exists.');
  const row = result.rows[0];
  return { orderNumber: Number(row.order_number), videoUrl: row.packing_video_url || '', note: row.packing_video_note || '', uploadedAt: row.packing_video_uploaded_at || null };
}

async function listAdminRefunds() {
  await ensureOrderSchema();
  const result = await database().query(
    `select o.id,o.order_number,o.status,o.total_inr,o.created_at,u.full_name,
            coalesce(sum(w.amount_inr) filter (where w.transaction_type='refund'),0)::integer as refunded_inr,
            max(w.created_at) filter (where w.transaction_type='refund') as last_refund_at
       from orders o join users u on u.id=o.user_id
       left join wallet_transactions w on w.order_id=o.id
      where o.status in ('delivered','returned','return_requested','refunded')
      group by o.id,u.full_name
      order by o.created_at desc limit 500`
  );
  return result.rows.map(row => ({
    id: row.id, orderNumber: Number(row.order_number), status: row.status, customer: row.full_name,
    totalInr: Number(row.total_inr), refundedInr: Number(row.refunded_inr),
    remainingInr: Math.max(0, Number(row.total_inr) - Number(row.refunded_inr)), lastRefundAt: row.last_refund_at
  }));
}

async function refundOrderToWallet(orderId, input) {
  await ensureOrderSchema();
  const amount = Number(input.amount);
  const note = String(input.note || 'Approved return refund').trim().slice(0, 300) || 'Approved return refund';
  if (!Number.isInteger(amount) || amount < 1) throw new Error('Enter a whole refund amount of at least ₹1.');
  const client = await database().connect();
  try {
    await client.query('begin');
    const order = await client.query(
      `select o.id,o.user_id,o.total_inr,o.status,
              coalesce((select sum(w.amount_inr) from wallet_transactions w where w.order_id=o.id and w.transaction_type='refund'),0)::integer as refunded_inr
         from orders o where o.id=$1 for update`, [orderId]
    );
    if (!order.rowCount) throw new Error('This order no longer exists.');
    const saved = order.rows[0];
    if (!['delivered','returned','return_requested','refunded'].includes(saved.status)) throw new Error('Only delivered or returned orders can be refunded.');
    const available = Math.max(0, Number(saved.total_inr) - Number(saved.refunded_inr));
    if (amount > available) throw new Error(`Only ₹${available.toLocaleString('en-IN')} remains available to refund for this order.`);
    const refund = await client.query(
      `insert into wallet_transactions (user_id,order_id,transaction_type,amount_inr,expires_at,note)
       values ($1,$2,'refund',$3,now()+interval '12 months',$4) returning id,expires_at`,
      [saved.user_id, saved.id, amount, note]
    );
    const remaining = available - amount;
    await client.query(`update orders set status=$2,payment_status='refunded' where id=$1`, [saved.id, remaining === 0 ? 'refunded' : saved.status]);
    await client.query(`update return_requests set status='refunded',refund_transaction_id=$2 where order_id=$1 and refund_transaction_id is null`, [saved.id, refund.rows[0].id]);
    await client.query('commit');
    return { amount, expiresAt: refund.rows[0].expires_at, remaining: Math.max(0, remaining) };
  } catch (error) {
    await client.query('rollback');
    throw error;
  } finally { client.release(); }
}

const cleanEmail = value => String(value || '').trim().toLowerCase();
const cleanReferralCode = value => String(value || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
const hashPassword = password => new Promise((resolve, reject) => {
  const salt = crypto.randomBytes(16).toString('base64url');
  crypto.scrypt(password, salt, 64, (error, derived) => error ? reject(error) : resolve(`scrypt$${salt}$${derived.toString('base64url')}`));
});
const passwordsMatch = (password, stored) => new Promise((resolve, reject) => {
  const [kind, salt, expected] = String(stored || '').split('$');
  if (kind !== 'scrypt' || !salt || !expected) return resolve(false);
  crypto.scrypt(password, salt, 64, (error, derived) => {
    if (error) return reject(error);
    const target = Buffer.from(expected, 'base64url');
    resolve(target.length === derived.length && crypto.timingSafeEqual(target, derived));
  });
});

async function ensureRewardsSchema() {
  if (rewardsSchemaReady) return rewardsSchemaReady;
  rewardsSchemaReady = (async () => {
    const client = await database().connect();
    try {
      await client.query('begin');
      await client.query(`create or replace function award_referral_coins() returns trigger language plpgsql as $$
        declare referrer uuid;
        begin
          if new.status = 'delivered' and old.status is distinct from 'delivered' then
            select referred_by into referrer from users where id = new.user_id;
            if referrer is not null and not exists (select 1 from referrals where referee_id = new.user_id and rewarded_at is not null) then
              insert into coin_transactions(user_id,order_id,transaction_type,coins,note) values
                (referrer,new.id,'referral_reward',10,'10 coins for a successful referral'),
                (new.user_id,new.id,'referral_reward',10,'Welcome referral reward');
              update referrals set reward_order_id=new.id,rewarded_at=now() where referee_id=new.user_id and rewarded_at is null;
            end if;
          end if;
          return new;
        end $$`);
      await client.query('drop trigger if exists order_delivery_referral_reward on orders');
      await client.query('create trigger order_delivery_referral_reward after update of status on orders for each row execute function award_referral_coins()');
      await client.query('commit');
    } catch (error) {
      await client.query('rollback');
      rewardsSchemaReady = undefined;
      throw error;
    } finally { client.release(); }
  })();
  return rewardsSchemaReady;
}

// v27 keeps loyalty accounting append-only.  A correction is always a new
// row, never an edit to a customer balance, so retrying provider events cannot
// silently create or remove rewards.
async function ensureCustomerExperienceSchema() {
  if (customerExperienceSchemaReady) return customerExperienceSchemaReady;
  customerExperienceSchemaReady = (async () => {
    const client = await database().connect();
    try {
      await client.query('begin');
      await client.query(`create table if not exists loyalty_settings (
        id boolean primary key default true check (id), earn_divisor_inr numeric(10,2) not null default 10,
        coin_value_inr numeric(10,2) not null default 1, max_redemption_percent numeric(5,2) not null default 10,
        updated_at timestamptz not null default now()
      )`);
      await client.query("insert into loyalty_settings(id) values (true) on conflict (id) do nothing");
      await client.query(`create table if not exists coin_ledger (
        id uuid primary key default gen_random_uuid(), user_id uuid not null references users(id), order_id uuid references orders(id),
        event_key text not null unique, transaction_type text not null, status text not null check (status in ('pending','available','reversed')),
        coins integer not null, reason text not null, created_at timestamptz not null default now()
      )`);
      await client.query('create index if not exists coin_ledger_user_created on coin_ledger(user_id,created_at desc)');
      await client.query(`create table if not exists shiprocket_event_log (
        id uuid primary key default gen_random_uuid(), provider text not null default 'shiprocket', event_key text not null unique,
        order_id uuid references orders(id), event_type text not null, status text, trusted boolean not null default false,
        payload_hash text not null, created_at timestamptz not null default now()
      )`);
      await client.query(`create table if not exists customer_notification_outbox (
        id uuid primary key default gen_random_uuid(), user_id uuid not null references users(id), event_key text not null unique,
        channel text not null, template_key text not null, payload jsonb not null default '{}'::jsonb, consent_required boolean not null default true,
        created_at timestamptz not null default now(), sent_at timestamptz
      )`);
      await client.query(`create table if not exists customer_notification_preferences (
        user_id uuid primary key references users(id), transactional_opt_out boolean not null default false,
        marketing_opt_in boolean not null default false, updated_at timestamptz not null default now()
      )`);
      await client.query(`create table if not exists abandoned_checkout_recovery (
        id uuid primary key default gen_random_uuid(), external_id text not null unique, recovery_token text not null unique,
        user_id uuid references users(id), expires_at timestamptz not null, created_at timestamptz not null default now()
      )`);
      await client.query('commit');
    } catch (error) {
      await client.query('rollback'); customerExperienceSchemaReady = undefined; throw error;
    } finally { client.release(); }
  })();
  return customerExperienceSchemaReady;
}

async function loyaltyRules() {
  await ensureCustomerExperienceSchema();
  const result = await database().query('select earn_divisor_inr,coin_value_inr,max_redemption_percent from loyalty_settings where id=true');
  const row = result.rows[0];
  return { earnDivisorInr:Number(row.earn_divisor_inr), coinValueInr:Number(row.coin_value_inr), maxRedemptionPercent:Number(row.max_redemption_percent) };
}

async function coinSummary(userId) {
  await ensureCustomerExperienceSchema();
  const result = await database().query(`select
    coalesce(sum(coins) filter (where status='pending'),0)::integer as pending,
    coalesce(sum(coins) filter (where status in ('available','reversed')),0)::integer as available,
    coalesce(jsonb_agg(jsonb_build_object('coins',coins,'type',transaction_type,'status',status,'reason',reason,'createdAt',created_at) order by created_at desc),'[]'::jsonb) as history
    from (select * from coin_ledger where user_id=$1 order by created_at desc limit 100) entries`, [userId]);
  const row = result.rows[0];
  return { available:Math.max(0,Number(row.available)), pending:Math.max(0,Number(row.pending)), history:row.history || [] };
}

async function createPendingOrderCoins(client, orderId, userId, subtotal) {
  const settings = await client.query('select earn_divisor_inr from loyalty_settings where id=true');
  const divisor = Math.max(1, Number(settings.rows[0]?.earn_divisor_inr || 10));
  const coins = Math.floor(Math.max(0, Number(subtotal || 0)) / divisor);
  if (!coins) return 0;
  await client.query(`insert into coin_ledger(user_id,order_id,event_key,transaction_type,status,coins,reason)
    values ($1,$2,$3,'order_reward','pending',$4,'Pending until Shiprocket confirms delivery') on conflict (event_key) do nothing`,
    [userId, orderId, `order:${orderId}:pending`, coins]);
  return coins;
}

async function setLoyaltyRules(input, adminReason) {
  await ensureCustomerExperienceSchema();
  const earnDivisorInr=Number(input.earnDivisorInr),coinValueInr=Number(input.coinValueInr),maxRedemptionPercent=Number(input.maxRedemptionPercent);
  if (!Number.isFinite(earnDivisorInr)||earnDivisorInr<=0||!Number.isFinite(coinValueInr)||coinValueInr<=0||!Number.isFinite(maxRedemptionPercent)||maxRedemptionPercent<0||maxRedemptionPercent>100) throw new Error('Enter valid loyalty rules.');
  await database().query('update loyalty_settings set earn_divisor_inr=$1,coin_value_inr=$2,max_redemption_percent=$3,updated_at=now() where id=true',[earnDivisorInr,coinValueInr,maxRedemptionPercent]);
  return { ...(await loyaltyRules()), auditReason:String(adminReason||'Admin loyalty setting update').slice(0,300) };
}

async function adminCoinAdjustment(userId, input) {
  await ensureCustomerExperienceSchema();
  const coins=Math.trunc(Number(input.coins)); const reason=String(input.reason||'').trim().slice(0,300);
  if (!Number.isInteger(coins)||!coins||Math.abs(coins)>100000||reason.length<3) throw new Error('Enter a coin amount and a reason.');
  await database().query(`insert into coin_ledger(user_id,event_key,transaction_type,status,coins,reason)
    values ($1,$2,'admin_adjustment','available',$3,$4)`,[userId,`admin:${crypto.randomUUID()}`,coins,reason]);
  return coinSummary(userId);
}

async function listAdminLoyalty() {
  await ensureCustomerExperienceSchema();
  const rows=await database().query(`select u.id,u.full_name,u.email,coalesce(sum(l.coins) filter(where l.status='pending'),0)::integer pending,
    coalesce(sum(l.coins) filter(where l.status in ('available','reversed')),0)::integer available
    from users u left join coin_ledger l on l.user_id=u.id group by u.id order by u.created_at desc limit 500`);
  return { rules:await loyaltyRules(), customers:rows.rows.map(row=>({id:row.id,name:row.full_name,email:row.email,available:Math.max(0,Number(row.available)),pending:Math.max(0,Number(row.pending))})) };
}

async function recordShiprocketEvent(input) {
  await ensureCustomerExperienceSchema();
  const eventKey=String(input.eventKey||'').slice(0,200), type=String(input.type||'unknown').toLowerCase(), externalOrderId=String(input.externalOrderId||'').slice(0,200);
  if (!eventKey) throw new Error('Webhook event id is missing.');
  const client=await database().connect();
  try {
    await client.query('begin');
    const existing=await client.query('select id from shiprocket_event_log where event_key=$1',[eventKey]);
    if(existing.rowCount){await client.query('commit');return {duplicate:true};}
    const order=externalOrderId?await client.query('select id,user_id,status from orders where shiprocket_order_id=$1',[externalOrderId]):{rows:[]};
    const saved=order.rows[0]||null;
    await client.query(`insert into shiprocket_event_log(event_key,order_id,event_type,status,trusted,payload_hash)
      values ($1,$2,$3,$4,$5,$6)`,[eventKey,saved?.id||null,type,String(input.status||'').slice(0,80)||null,Boolean(input.trusted),String(input.payloadHash||'').slice(0,128)]);
    if (saved && input.trusted) {
      const terminal=/cancel|refund|return|ndr|delivery.failed/.test(type);
      const delivered=/delivered/.test(type);
      const mapped=delivered?'delivered':terminal?(type.includes('return')?'returned':'cancelled'):null;
      if(mapped) await client.query('update orders set status=$2, delivered_at=case when $2=\'delivered\' then coalesce(delivered_at,now()) else delivered_at end where id=$1',[saved.id,mapped]);
      if(delivered){
        const pending=await client.query("select coalesce(sum(coins),0)::integer coins from coin_ledger where order_id=$1 and status='pending'",[saved.id]);
        const coins=Math.max(0,Number(pending.rows[0].coins));
        if(coins){
          await client.query("insert into coin_ledger(user_id,order_id,event_key,transaction_type,status,coins,reason) values ($1,$2,$3,'pending_release','pending',$4,'Released after delivery') on conflict(event_key) do nothing",[saved.user_id,saved.id,`order:${saved.id}:pending-release`, -coins]);
          await client.query("insert into coin_ledger(user_id,order_id,event_key,transaction_type,status,coins,reason) values ($1,$2,$3,'delivery_reward','available',$4,'Available after Shiprocket delivery') on conflict(event_key) do nothing",[saved.user_id,saved.id,`order:${saved.id}:available`,coins]);
        }
      }
      if(terminal){
        const balance=await client.query("select coalesce(sum(coins) filter(where status in ('pending','available','reversed')),0)::integer coins from coin_ledger where order_id=$1",[saved.id]);
        const coins=Math.max(0,Number(balance.rows[0].coins));
        if(coins) await client.query("insert into coin_ledger(user_id,order_id,event_key,transaction_type,status,coins,reason) values ($1,$2,$3,'order_reversal','reversed',$4,'Reversed after order cancellation, return or refund') on conflict(event_key) do nothing",[saved.user_id,saved.id,`order:${saved.id}:reversal`,-coins]);
      }
      if (/packed|shipped|out.for.delivery|delivered|cancel|refund|return|ndr/.test(type)) await client.query(`insert into customer_notification_outbox(user_id,event_key,channel,template_key,payload)
        values ($1,$2,'provider','order_status',$3::jsonb) on conflict(event_key) do nothing`,[saved.user_id,`notification:${eventKey}`,JSON.stringify({event:type})]);
    }
    await client.query('commit'); return {duplicate:false,matchedOrder:Boolean(saved)};
  } catch(error){await client.query('rollback');throw error;} finally{client.release();}
}

async function registerCustomer(input) {
  const fullName = String(input.fullName || '').trim().replace(/\s+/g, ' ');
  const phone = String(input.phone || '').replace(/\D/g, '');
  const email = cleanEmail(input.email);
  const password = String(input.password || '');
  const referralCode = cleanReferralCode(input.referralCode);
  if (fullName.length < 2 || fullName.length > 100) throw new Error('Enter your full name.');
  if (!/^[6-9]\d{9}$/.test(phone)) throw new Error('Enter a valid 10-digit mobile number.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) throw new Error('Enter a valid email address.');
  if (password.length < 8 || password.length > 200) throw new Error('Your password must be at least 8 characters.');
  const client = await database().connect();
  try {
    await client.query('begin');
    const exists = await client.query('select id from users where email=$1 or phone=$2', [email, phone]);
    if (exists.rowCount) throw new Error('An account already exists with this email or mobile number. Please sign in.');
    let referrerId = null;
    if (referralCode) {
      const referrer = await client.query('select id from users where referral_code=$1 and is_active=true', [referralCode]);
      if (!referrer.rowCount) throw new Error('This referral code is not valid.');
      referrerId = referrer.rows[0].id;
    }
    const saved = await client.query(
      'insert into users (full_name,email,phone,password_hash,referral_code,referred_by) values ($1,$2,$3,$4,$5,$6) returning id,full_name,email,referral_code',
      [fullName, email, phone, await hashPassword(password), newReferralCode(), referrerId]
    );
    if (referrerId) await client.query('insert into referrals (referrer_id,referee_id) values ($1,$2)', [referrerId, saved.rows[0].id]);
    await client.query('commit');
    return saved.rows[0];
  } catch (error) {
    await client.query('rollback');
    throw error;
  } finally { client.release(); }
}

async function authenticateCustomer(emailInput, password) {
  const email = cleanEmail(emailInput);
  if (!email || !password) return null;
  const result = await database().query('select id,full_name,email,password_hash,referral_code,is_active from users where email=$1', [email]);
  const customer = result.rows[0];
  if (!customer || !customer.is_active || !customer.password_hash || !(await passwordsMatch(String(password), customer.password_hash))) return null;
  return { id: customer.id, fullName: customer.full_name, email: customer.email, referralCode: customer.referral_code };
}

async function customerAccount(userId) {
  await ensureRewardsSchema();
  await ensureCustomerExperienceSchema();
  const result = await database().query(
    `select u.full_name,u.email,u.phone,u.referral_code,
      coalesce((select sum(case when w.transaction_type in ('refund','credit','adjustment') then w.amount_inr else -w.amount_inr end)
        from wallet_transactions w where w.user_id=u.id and (w.expires_at is null or w.expires_at > now())),0)::integer as wallet_balance,
      coalesce((select sum(case when c.transaction_type in ('purchase_reward','referral_reward','adjustment') then c.coins else -c.coins end)
        from coin_transactions c where c.user_id=u.id and (c.expires_at is null or c.expires_at > now())),0)::integer as coin_balance,
      coalesce((select jsonb_agg(jsonb_build_object('type',w.transaction_type,'amount',w.amount_inr,'note',w.note,'createdAt',w.created_at,'expiresAt',w.expires_at) order by w.created_at desc)
        from (select * from wallet_transactions where user_id=u.id order by created_at desc limit 8) w),'[]'::jsonb) as wallet_activity
    from users u where u.id=$1 and u.is_active=true`, [userId]
  );
  if (!result.rowCount) return null;
  const row = result.rows[0];
  const coins = await coinSummary(userId);
  return { fullName: row.full_name, email: row.email, phone: row.phone || '', referralCode: row.referral_code, walletBalance: Number(row.wallet_balance), coinBalance: coins.available, pendingCoins: coins.pending, coinHistory: coins.history, walletActivity: row.wallet_activity || [] };
}

async function updateCustomerProfile(userId, input) {
  const fullName = String(input.fullName || '').trim().replace(/\s+/g, ' ');
  const phone = String(input.phone || '').replace(/\D/g, '');
  if (fullName.length < 2 || fullName.length > 100) throw new Error('Enter your full name.');
  if (!/^[6-9]\d{9}$/.test(phone)) throw new Error('Enter a valid 10-digit mobile number.');
  const result = await database().query('update users set full_name=$2,phone=$3,updated_at=now() where id=$1 and is_active=true returning full_name,email,phone', [userId, fullName, phone]);
  if (!result.rowCount) throw new Error('Your profile is not available.');
  return { fullName: result.rows[0].full_name, email: result.rows[0].email, phone: result.rows[0].phone };
}

async function customerAddresses(userId) {
  const result = await database().query('select id,label,full_name,phone,line1,line2,city,state,pincode,is_default from addresses where user_id=$1 order by is_default desc,created_at desc', [userId]);
  return result.rows.map(row => ({ id:row.id,label:row.label,fullName:row.full_name,phone:row.phone,line1:row.line1,line2:row.line2||'',city:row.city,state:row.state,pincode:row.pincode,isDefault:row.is_default }));
}

async function saveCustomerAddress(userId, input) {
  const id=String(input.id||''),label=String(input.label||'Home').trim().slice(0,30)||'Home',fullName=String(input.fullName||'').trim().replace(/\s+/g,' '),phone=String(input.phone||'').replace(/\D/g,''),line1=String(input.line1||'').trim(),line2=String(input.line2||'').trim(),city=String(input.city||'').trim(),state=String(input.state||'').trim(),pincode=String(input.pincode||'').replace(/\D/g,'').slice(0,6),isDefault=input.isDefault===true;
  if(fullName.length<2||!line1||!city||!state||!/^[6-9]\d{9}$/.test(phone)||!/^\d{6}$/.test(pincode)) throw new Error('Complete the address with a valid mobile number and 6-digit PIN code.');
  const client=await database().connect();
  try { await client.query('begin'); if(isDefault) await client.query('update addresses set is_default=false where user_id=$1',[userId]); const result=id?await client.query('update addresses set label=$3,full_name=$4,phone=$5,line1=$6,line2=$7,city=$8,state=$9,pincode=$10,is_default=$11 where id=$2 and user_id=$1 returning id',[userId,id,label,fullName,phone,line1,line2||null,city,state,pincode,isDefault]):await client.query('insert into addresses (user_id,label,full_name,phone,line1,line2,city,state,pincode,is_default) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) returning id',[userId,label,fullName,phone,line1,line2||null,city,state,pincode,isDefault]); if(!result.rowCount) throw new Error('This saved address is no longer available.'); await client.query('commit'); return {id:result.rows[0].id}; } catch(error){await client.query('rollback');throw error;} finally{client.release();}
}

async function deleteCustomerAddress(userId,addressId) { const result=await database().query('delete from addresses where id=$1 and user_id=$2 returning id',[addressId,userId]); if(!result.rowCount) throw new Error('This saved address is no longer available.'); }

async function customerReturnItems(userId) {
  const result = await database().query(
    `select oi.id as order_item_id,oi.product_name,oi.quantity,o.order_number,o.delivered_at,
            rr.status as return_status
       from orders o join order_items oi on oi.order_id=o.id
       left join return_requests rr on rr.order_item_id=oi.id
      where o.user_id=$1 and (rr.id is not null or (o.status='delivered' and o.delivered_at >= now()-interval '3 days'))
      order by o.delivered_at desc nulls last,oi.product_name`, [userId]
  );
  return result.rows.map(row => ({ orderItemId: row.order_item_id, productName: row.product_name, quantity: Number(row.quantity), orderNumber: Number(row.order_number), deliveredAt: row.delivered_at, returnStatus: row.return_status || null }));
}

async function customerOrders(userId) {
  const result = await database().query(
    `select o.order_number,o.status,o.payment_status,o.created_at,o.total_inr,o.packing_video_url,o.packing_video_note,
            s.awb,s.tracking_status,s.estimated_delivery_date,
            coalesce(count(oi.id),0)::integer as item_count
       from orders o left join shipments s on s.order_id=o.id left join order_items oi on oi.order_id=o.id
      where o.user_id=$1
      group by o.id,s.awb,s.tracking_status,s.estimated_delivery_date
      order by o.created_at desc limit 100`, [userId]
  );
  return result.rows.map(row => ({
    orderNumber: Number(row.order_number), status: row.status, paymentStatus: row.payment_status,
    createdAt: row.created_at, totalInr: Number(row.total_inr), itemCount: Number(row.item_count),
    awb: row.awb || null, trackingStatus: row.tracking_status || null, estimatedDeliveryDate: row.estimated_delivery_date,
    packingVideoUrl: row.packing_video_url || '', packingVideoNote: row.packing_video_note || ''
  }));
}

async function customerReviewItems(userId) {
  const result = await database().query(
    `select oi.id as order_item_id,oi.product_name,oi.product_id,o.order_number,r.id as review_id,r.is_approved
       from order_items oi join orders o on o.id=oi.order_id
       left join reviews r on r.order_item_id=oi.id and r.user_id=o.user_id
      where o.user_id=$1 and o.status='delivered' and oi.product_id is not null
      order by o.delivered_at desc nulls last,oi.product_name`, [userId]
  );
  return result.rows.map(row => ({ orderItemId: row.order_item_id, productName: row.product_name, orderNumber: Number(row.order_number), reviewed: Boolean(row.review_id), approved: Boolean(row.is_approved) }));
}

const reviewImage = value => /^data:image\/(jpeg|png|webp);base64,[a-z0-9+/=]+$/i.test(String(value || '')) && String(value).length <= 700000;
async function submitCustomerReview(userId, input) {
  const orderItemId = String(input.orderItemId || '');
  const rating = Number(input.rating);
  const body = String(input.body || '').trim();
  const images = Array.isArray(input.images) ? input.images.map(String).filter(Boolean) : [];
  if (!/^[0-9a-f-]{36}$/i.test(orderItemId)) throw new Error('Choose a delivered product.');
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw new Error('Choose a rating from 1 to 5 stars.');
  if (body.length < 5 || body.length > 1500) throw new Error('Your review must be between 5 and 1,500 characters.');
  if (images.length > 3 || images.some(image => !reviewImage(image))) throw new Error('Add up to 3 JPG, PNG or WebP photos under 500 KB each.');
  const client = await database().connect();
  try {
    await client.query('begin');
    const item = await client.query(
      `select oi.product_id from order_items oi join orders o on o.id=oi.order_id
        where oi.id=$1 and o.user_id=$2 and o.status='delivered' for update`, [orderItemId, userId]
    );
    if (!item.rowCount || !item.rows[0].product_id) throw new Error('Only delivered products can be reviewed.');
    const review = await client.query('insert into reviews (user_id,product_id,order_item_id,rating,body) values ($1,$2,$3,$4,$5) returning id', [userId,item.rows[0].product_id,orderItemId,rating,body]);
    for (const image of images) await client.query('insert into review_images (review_id,url) values ($1,$2)', [review.rows[0].id,image]);
    await client.query('commit');
    return { submitted:true };
  } catch (error) {
    await client.query('rollback');
    if (error.code === '23505') throw new Error('You have already reviewed this product.');
    throw error;
  } finally { client.release(); }
}

async function listAdminReviews() {
  const result = await database().query(
    `select r.id,r.rating,r.body,r.is_approved,r.created_at,u.full_name,p.name as product_name,
      coalesce(jsonb_agg(ri.url) filter (where ri.id is not null),'[]'::jsonb) as images
       from reviews r join users u on u.id=r.user_id join products p on p.id=r.product_id
       left join review_images ri on ri.review_id=r.id
      group by r.id,u.full_name,p.name order by r.created_at desc limit 500`
  );
  return result.rows.map(row => ({ id:row.id,rating:Number(row.rating),body:row.body,approved:row.is_approved,createdAt:row.created_at,customer:row.full_name,productName:row.product_name,images:row.images || [] }));
}

async function approveReview(reviewId, approved) {
  const result = await database().query('update reviews set is_approved=$2 where id=$1 returning id', [reviewId, Boolean(approved)]);
  if (!result.rowCount) throw new Error('This review no longer exists.');
}

async function publicReviewsBySku(sku) {
  const result = await database().query(
    `select r.rating,r.body,r.created_at,u.full_name,coalesce(jsonb_agg(ri.url) filter (where ri.id is not null),'[]'::jsonb) as images
       from reviews r join products p on p.id=r.product_id join users u on u.id=r.user_id left join review_images ri on ri.review_id=r.id
      where p.sku=$1 and r.is_approved=true group by r.id,u.full_name order by r.created_at desc limit 30`, [String(sku || '')]
  );
  return result.rows.map(row => ({ rating:Number(row.rating),body:row.body,createdAt:row.created_at,customer:row.full_name,images:row.images || [] }));
}

async function requestCustomerReturn(userId, input) {
  const orderItemId = String(input.orderItemId || '');
  const reason = String(input.reason || '').trim().replace(/\s+/g, ' ');
  const details = String(input.details || '').trim().slice(0, 1000) || null;
  if (!/^[0-9a-f-]{36}$/i.test(orderItemId)) throw new Error('Choose an eligible delivered product.');
  if (reason.length < 3 || reason.length > 160) throw new Error('Tell us the reason for the return.');
  const client = await database().connect();
  try {
    await client.query('begin');
    const item = await client.query(
      `select oi.id,oi.order_id,o.delivered_at,o.status
         from order_items oi join orders o on o.id=oi.order_id
        where oi.id=$1 and o.user_id=$2 for update`, [orderItemId, userId]
    );
    if (!item.rowCount) throw new Error('This delivered product is not available for return.');
    const saved = item.rows[0];
    if (saved.status !== 'delivered' || !saved.delivered_at || new Date(saved.delivered_at).getTime() + 3 * 24 * 60 * 60 * 1000 < Date.now()) throw new Error('Returns can only be requested within 3 days of delivery.');
    const exists = await client.query('select id from return_requests where order_item_id=$1', [orderItemId]);
    if (exists.rowCount) throw new Error('A return request already exists for this product.');
    await client.query('insert into return_requests (order_id,user_id,order_item_id,reason,details) values ($1,$2,$3,$4,$5)', [saved.order_id, userId, orderItemId, reason, details]);
    await client.query("update orders set status='return_requested' where id=$1", [saved.order_id]);
    await client.query('commit');
    return { requested: true };
  } catch (error) {
    await client.query('rollback');
    throw error;
  } finally { client.release(); }
}

// Imports the catalogue extracted from the owner's PDF. This is deliberately an
// admin-only server function: no browser can write product data directly.
async function importPdfCatalogue() {
  const cataloguePath = path.join(__dirname, 'assets', 'catalogue', 'products.json');
  if (!fs.existsSync(cataloguePath)) throw new Error('The PDF catalogue file is not available on this server.');
  const items = JSON.parse(fs.readFileSync(cataloguePath, 'utf8'));
  if (!Array.isArray(items) || !items.length) throw new Error('The PDF catalogue is empty.');

  const client = await database().connect();
  try {
    await client.query('begin');
    // Some supplier prices include paise (for example ₹1.50), so retain the
    // exact PDF price instead of rounding it up.
    await client.query('alter table products alter column price_inr type numeric(10,2) using price_inr::numeric(10,2)');
    await client.query('alter table products alter column compare_at_price_inr type numeric(10,2) using compare_at_price_inr::numeric(10,2)');

    const categories = [...new Set(items.map(item => item.category))];
    for (const category of categories) {
      await client.query(
        'insert into categories (name, slug) values ($1, $2) on conflict (slug) do update set name = excluded.name, is_active = true',
        [category, toSlug(category)]
      );
    }
    const categoryRows = await client.query('select id, slug from categories where slug = any($1::text[])', [categories.map(toSlug)]);
    const categoryIds = new Map(categoryRows.rows.map(row => [row.slug, row.id]));

    const imported = [];
    for (let start = 0; start < items.length; start += 100) {
      const batch = items.slice(start, start + 100);
      const values = [];
      const params = [];
      batch.forEach((item, index) => {
        const at = index * 9;
        values.push(`($${at + 1}::uuid, $${at + 2}::text, $${at + 3}::text, $${at + 4}::text, $${at + 5}::text, $${at + 6}::jsonb, $${at + 7}::numeric, $${at + 8}::integer, $${at + 9}::numeric, 10, 10, 10, true)`);
        params.push(
          categoryIds.get(toSlug(item.category)) || null,
          item.sku,
          item.name,
          `${toSlug(item.name)}-${toSlug(item.sku)}`,
          `Imported from supplier PDF. Source code: ${item.source_code}.`,
          JSON.stringify({ source_code: item.source_code, source_page: item.source_page, weight_grams: item.weight_grams }),
          item.price_inr,
          item.stock_quantity,
          Number(item.weight_grams) / 1000
        );
      });
      const result = await client.query(
        `insert into products (category_id, sku, name, slug, description, specifications, price_inr, stock_quantity, weight_kg, length_cm, breadth_cm, height_cm, is_active)
         values ${values.join(',')}
         on conflict (sku) do update set category_id = excluded.category_id, name = excluded.name, slug = excluded.slug, description = excluded.description, specifications = excluded.specifications, price_inr = excluded.price_inr, stock_quantity = excluded.stock_quantity, weight_kg = excluded.weight_kg, is_active = true, updated_at = now()
         returning id, sku`,
        params
      );
      imported.push(...result.rows);
    }

    const productIds = imported.map(row => row.id);
    await client.query('delete from product_images where product_id = any($1::uuid[])', [productIds]);
    for (let start = 0; start < items.length; start += 200) {
      const batch = items.slice(start, start + 200);
      const values = [];
      const params = [];
      batch.forEach((item, index) => {
        // Each photo row has three parameters. Keeping the placeholder
        // numbering consecutive is required by PostgreSQL for batches.
        const at = index * 3;
        const product = imported.find(row => row.sku === item.sku);
        values.push(`($${at + 1}, $${at + 2}, $${at + 3}, 0)`);
        params.push(product.id, item.image_url, item.name);
      });
      await client.query(`insert into product_images (product_id, url, alt_text, sort_order) values ${values.join(',')}`, params);
    }
    await client.query('commit');
    return { products: items.length, categories: categories.length };
  } catch (error) {
    await client.query('rollback');
    throw error;
  } finally {
    client.release();
  }
}

module.exports = { database, databaseHealth, listActiveProducts, listAdminProducts, listAdminOrders, listAdminRefunds, saveProduct, deactivateProduct, importPdfCatalogue, recordShiprocketOrder, reserveShiprocketShipment, completeShiprocketShipment, releaseShiprocketShipment, refundOrderToWallet, registerCustomer, authenticateCustomer, customerAccount, updateCustomerProfile, customerAddresses, saveCustomerAddress, deleteCustomerAddress, customerOrders, customerReturnItems, requestCustomerReturn, customerReviewItems, submitCustomerReview, listAdminReviews, approveReview, publicReviewsBySku, savePackingVideo, loyaltyRules, setLoyaltyRules, coinSummary, adminCoinAdjustment, listAdminLoyalty, recordShiprocketEvent, ensureCustomerExperienceSchema };
