const fallbackProducts=[
  {name:'NovaPods Pro Wireless Earbuds',category:'Electronics',price_inr:899,stock_quantity:42,sku:'MH-ELE-001',image_url:'https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=140&q=80',weight_grams:500},
  {name:'Stainless Steel Insulated Bottle',category:'Home & Kitchen',price_inr:349,stock_quantity:8,sku:'MH-HOM-021',image_url:'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=140&q=80',weight_grams:500}
];
let orders=[
  {id:'#MH-1048',customer:'Riya Sharma',initials:'RS',items:'2 items',total:'₹1,248',payment:'Prepaid',status:'New'},
  {id:'#MH-1047',customer:'Arjun Mehta',initials:'AM',items:'4 items',total:'₹2,699',payment:'COD',status:'New'},
  {id:'#MH-1046',customer:'Sana Fatima',initials:'SF',items:'1 item',total:'₹899',payment:'Prepaid',status:'Packed'},
  {id:'#MH-1045',customer:'Karan Patel',initials:'KP',items:'3 items',total:'₹1,549',payment:'UPI',status:'Shipped'}
];
let catalogue=[],pdfCatalogue=[];
const $=id=>document.getElementById(id);
const safe=value=>String(value||'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const money=value=>'₹'+Number(value||0).toLocaleString('en-IN',{minimumFractionDigits:Number(value)%1?2:0,maximumFractionDigits:2});
const statusClass=value=>String(value).toLowerCase();
const toast=message=>{const node=$('toast');node.textContent=message;node.classList.add('show');setTimeout(()=>node.classList.remove('show'),3500)};
const packingButton=order=>`<button class="row-button packing-button" data-packing-video="${safe(order.uuid||'')}">${order.packingVideoUrl?'Packing video ✓':'Add packing video'}</button>`;
const orderRow=(order,compact=false)=>compact?`<tr><td><b>${order.id}</b></td><td><div class="customer"><span class="avatar">${order.initials}</span>${order.customer}</div></td><td><b>${order.total}</b></td><td>${order.payment}</td><td><span class="pill ${statusClass(order.status)}">${order.status}</span></td><td>${packingButton(order)}</td></tr>`:`<tr><td><input type="checkbox"></td><td><b>${order.id}</b></td><td><div class="customer"><span class="avatar">${order.initials}</span>${order.customer}</div></td><td>${order.items}</td><td><b>${order.total}</b></td><td>${order.payment}</td><td><span class="pill ${statusClass(order.status)}">${order.status}</span></td><td>${packingButton(order)}</td></tr>`;
function normaliseProduct(product){return {...product,price_inr:Number(product.price_inr??product.price??0),stock_quantity:Number(product.stock_quantity??product.stock??0),weight_grams:Number(product.weight_grams||500),gallery:Array.isArray(product.gallery)?product.gallery:(product.image_url?[product.image_url]:[]),image_url:product.image_url||product.img||''}}
function renderProducts(query=''){
  const text=query.trim().toLowerCase(),filtered=text?catalogue.filter(product=>`${product.name} ${product.category} ${product.sku}`.toLowerCase().includes(text)):catalogue,visible=filtered.slice(0,100);
  $('productsTable').innerHTML=visible.map(product=>`<tr><td><div class="product-cell"><img src="${safe(product.image_url)}" alt=""><span><strong>${safe(product.name)}</strong><small>${safe(product.sku)}</small></span></div></td><td>${safe(product.category)}</td><td><b>${money(product.price_inr)}</b></td><td class="${product.stock_quantity<10?'stock-low':''}">${product.stock_quantity} units${product.stock_quantity<10?' · Low':''}</td><td><span class="pill ${product.is_active===false?'warning':'shipped'}">${product.is_active===false?'Hidden':'Active'}</span></td><td>${product.id?`<button class="row-button" data-edit-product="${product.id}">Edit</button>`:'<button class="row-button" data-toast="Import the PDF catalogue or save a new product to edit it.">Edit</button>'}</td></tr>`).join('')||'<tr><td colspan="6">No matching products.</td></tr>';
  $('catalogueSummary').textContent=`${filtered.length.toLocaleString('en-IN')} product${filtered.length===1?'':'s'} ready. Showing the first ${Math.min(visible.length,100)}.`;
}
async function loadPdfPreview(){if(pdfCatalogue.length)return pdfCatalogue;const response=await fetch('assets/catalogue/products.json',{cache:'no-store'});if(!response.ok)throw new Error('The PDF catalogue file was not found.');pdfCatalogue=await response.json();return pdfCatalogue}
async function loadProducts(){
  try{const response=await fetch('/api/admin/products',{cache:'no-store'});const data=await response.json();if(!response.ok)throw new Error(data.error||'The database is not ready.');catalogue=data.products.map(normaliseProduct);}
  catch(error){try{catalogue=(await loadPdfPreview()).map(normaliseProduct);toast('Showing your PDF preview. Import it to make products editable.')}catch{catalogue=fallbackProducts.map(normaliseProduct);toast(error.message||'Product database is not ready.')}}
  renderProducts($('productSearch')?.value||'');
}
function buildModal(product=null){
  const form=$('productForm'),isEdit=Boolean(product),images=(product?.gallery||[]).join('\n');
  form.innerHTML=`<button type="button" class="modal-close">×</button><p class="mini-label">CATALOGUE</p><h2>${isEdit?'Edit product':'Add a product'}</h2><input type="hidden" name="product_id" value="${safe(product?.id||'')}"><label>Product name<input required name="name" maxlength="180" value="${safe(product?.name||'')}" placeholder="e.g. NovaPods Pro Wireless Earbuds"></label><div class="form-two"><label>Category<input required name="category" maxlength="80" value="${safe(product?.category||'')}" placeholder="e.g. Electronics"></label><label>Price (₹)<input required name="price" type="number" min="0.01" step="0.01" value="${product?.price_inr??''}" placeholder="899"></label></div><div class="form-two"><label>Stock quantity<input required name="stock" type="number" min="0" step="1" value="${product?.stock_quantity??99}" placeholder="99"></label><label>Weight (grams)<input required name="weight_grams" type="number" min="1" step="1" value="${product?.weight_grams??500}"></label></div><label>SKU<input required name="sku" maxlength="80" value="${safe(product?.sku||'')}" placeholder="MH-NEW-001"></label><label>Description<textarea name="description" maxlength="1500" placeholder="Product details customers will see">${safe(product?.description||'')}</textarea></label><label>Photo links <small>One secure image link per line (up to 12)</small><textarea name="images" placeholder="https://example.com/photo-1.jpg&#10;https://example.com/photo-2.jpg">${safe(images)}</textarea></label><label>Product video link <small>Optional secure video link</small><input name="video_url" type="url" value="${safe(product?.video_url||'')}" placeholder="https://example.com/product-video.mp4"></label><div class="modal-actions">${isEdit?'<button type="button" class="danger-text" id="deleteProduct">Remove product</button>':''}<button class="primary">Save product</button></div>`;
  form.onsubmit=saveProduct;
  $('deleteProduct')?.addEventListener('click',()=>removeProduct(product));
}
function showModal(product=null){buildModal(product);$('modalBackdrop').classList.add('show')}
function hideModal(){$('modalBackdrop').classList.remove('show')}
async function saveProduct(event){
  event.preventDefault();const form=new FormData(event.currentTarget),id=String(form.get('product_id')||''),payload={name:form.get('name'),category:form.get('category'),price:Number(form.get('price')),stock:Number(form.get('stock')),weight_grams:Number(form.get('weight_grams')),sku:form.get('sku'),description:form.get('description'),images:String(form.get('images')||'').split(/\r?\n/).map(value=>value.trim()).filter(Boolean),video_url:form.get('video_url')};
  const button=event.currentTarget.querySelector('.primary');button.disabled=true;button.textContent='Saving…';
  try{const response=await fetch(id?`/api/admin/products/${encodeURIComponent(id)}`:'/api/admin/products',{method:id?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),data=await response.json();if(!response.ok)throw new Error(data.error||'Product could not be saved.');const index=catalogue.findIndex(product=>product.id===data.product.id);if(index>=0)catalogue[index]=normaliseProduct(data.product);else catalogue.unshift(normaliseProduct(data.product));renderProducts($('productSearch').value);hideModal();toast(id?'Product updated successfully.':'Product added successfully.');}
  catch(error){toast(error.message||'Product could not be saved.')}finally{button.disabled=false;button.textContent='Save product';}
}
async function removeProduct(product){
  if(!confirm(`Remove “${product.name}” from your storefront?`))return;
  try{const response=await fetch(`/api/admin/products/${encodeURIComponent(product.id)}`,{method:'DELETE'}),data=await response.json();if(!response.ok)throw new Error(data.error||'Product could not be removed.');catalogue=catalogue.filter(item=>item.id!==product.id);renderProducts($('productSearch').value);hideModal();toast('Product removed from the storefront.');}catch(error){toast(error.message||'Product could not be removed.');}
}
function activate(section){document.querySelectorAll('.view').forEach(view=>view.classList.toggle('active',view.id===section));document.querySelectorAll('.nav-link').forEach(button=>button.classList.toggle('active',button.dataset.section===section));const names={dashboard:'Good morning, Mohammed',orders:'Order management',returns:'Returns & wallet refunds',products:'Product catalogue',categories:'Category manager',shipping:'Delhivery shipping',customers:'Customer management',offers:'Offers & coupons',settings:'Store settings'};$('pageTitle').textContent=names[section]||'MARKET HUB';if(section==='products')loadProducts();if(section==='returns')loadRefunds();window.scrollTo({top:0,behavior:'smooth'})}
function renderOrders(){
  $('recentOrders').innerHTML=orders.slice(0,3).map(order=>orderRow(order,true)).join('');
  $('ordersTable').innerHTML=orders.map(order=>orderRow(order)).join('');
}
function showPackingVideo(order){
  const form=$('productForm');
  form.innerHTML=`<button type="button" class="modal-close">×</button><p class="mini-label">ORDER ${safe(order.id)}</p><h2>Packing video</h2><p class="packing-help">Optional: add a short packing or dispatch video for ${safe(order.customer)}. The customer can view it in their order details.</p><label>Choose video <small>MP4, WebM or MOV · maximum 4 MB</small><input name="packing_file" type="file" accept="video/mp4,video/webm,video/quicktime"></label><label>Or paste a secure video link <small>Use this for larger videos</small><input name="packing_link" type="url" placeholder="https://example.com/packing-video.mp4" value="${safe(order.packingVideoUrl?.startsWith('http')?order.packingVideoUrl:'')}"></label><label>Customer note <small>Optional</small><textarea name="packing_note" maxlength="300" placeholder="Your order has been packed and is ready to ship.">${safe(order.packingVideoNote||'')}</textarea></label><div class="modal-actions"><button type="button" class="danger-text" id="removePackingVideo" ${order.packingVideoUrl?'':'hidden'}>Remove video</button><button class="primary">Save packing video</button></div>`;
  form.onsubmit=event=>savePackingVideo(event,order);
  $('removePackingVideo')?.addEventListener('click',()=>savePackingVideo(null,order,true));
  $('modalBackdrop').classList.add('show');
}
function fileAsDataUrl(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(new Error('The selected video could not be read.'));reader.readAsDataURL(file);});}
async function savePackingVideo(event,order,remove=false){
  if(event)event.preventDefault();let videoUrl='',note='';
  try{if(!remove){const form=new FormData(event.currentTarget),file=form.get('packing_file');note=String(form.get('packing_note')||'');if(file?.size){if(file.size>4*1024*1024)throw new Error('Choose a packing video up to 4 MB, or use a video link.');videoUrl=await fileAsDataUrl(file);}else videoUrl=String(form.get('packing_link')||'').trim();if(!videoUrl)throw new Error('Choose a video or paste a secure video link.');}
    const button=event?.currentTarget.querySelector('.primary');if(button){button.disabled=true;button.textContent='Saving…';}
    const response=await fetch(`/api/admin/orders/${encodeURIComponent(order.uuid)}/packing-video`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({videoUrl,note})}),data=await response.json();if(!response.ok)throw new Error(data.error||'The packing video could not be saved.');
    hideModal();toast(remove?'Packing video removed.':'Packing video saved for this customer.');await loadOrders();
  }catch(error){toast(error.message||'The packing video could not be saved.');}
}
async function loadOrders(){
  try{
    const response=await fetch('/api/admin/orders',{cache:'no-store'}),data=await response.json();
    if(!response.ok)throw new Error(data.error||'Orders are not ready yet.');
    if(data.orders.length)orders=data.orders.map(order=>({uuid:order.id,id:`#MH-${order.order_number}`,customer:order.customer,initials:order.customer.split(/\s+/).map(name=>name[0]).join('').slice(0,2).toUpperCase(),items:`${order.item_count} item${order.item_count===1?'':'s'}`,total:money(order.total_inr),payment:order.payment_method==='cod'?'COD':order.payment_status==='paid'?'Prepaid':'Pending',status:order.status==='confirmed'?'New':order.status[0].toUpperCase()+order.status.slice(1),packingVideoUrl:order.packing_video_url||'',packingVideoNote:order.packing_video_note||''}));
    renderOrders();
  }catch(error){renderOrders();}
}
let refunds=[];
function renderRefunds(){
  const body=$('refundsTable');if(!body)return;
  body.innerHTML=refunds.map(refund=>`<tr><td><b>#MH-${refund.orderNumber}</b></td><td>${safe(refund.customer)}</td><td><b>${money(refund.totalInr)}</b></td><td>${money(refund.refundedInr)}</td><td><b>${money(refund.remainingInr)}</b></td><td><span class="pill ${refund.status==='refunded'?'shipped':'warning'}">${safe(refund.status.replace('_',' '))}</span></td><td>${refund.remainingInr>0?`<button class="small-primary" data-refund-order="${refund.id}">Refund to wallet</button>`:'<span class="muted-cell">Complete</span>'}</td></tr>`).join('')||'<tr><td colspan="7">No delivered or returned orders are ready for a refund yet.</td></tr>';
}
async function loadRefunds(){
  try{const response=await fetch('/api/admin/refunds',{cache:'no-store'}),data=await response.json();if(!response.ok)throw new Error(data.error||'Refunds are not ready yet.');refunds=data.refunds;renderRefunds();}catch(error){refunds=[];renderRefunds();toast(error.message||'Refunds are not ready yet.');}
}
async function refundToWallet(refund){
  const amount=prompt(`Approve a wallet refund for order #MH-${refund.orderNumber}.\nAvailable amount: ${money(refund.remainingInr)}`,String(refund.remainingInr));
  if(amount===null)return;const value=Number(amount);if(!Number.isInteger(value)||value<1)return toast('Enter a whole rupee amount.');
  if(!confirm(`Add ${money(value)} to ${refund.customer}'s MARKET HUB Wallet? It will expire after 12 months.`))return;
  try{const response=await fetch(`/api/admin/orders/${encodeURIComponent(refund.id)}/refund`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({amount:value,note:'Approved return refund'})}),data=await response.json();if(!response.ok)throw new Error(data.error||'Wallet refund could not be approved.');toast(`${money(data.amount)} added to the customer wallet. Valid for 12 months.`);await loadRefunds();}catch(error){toast(error.message||'Wallet refund could not be approved.');}
}
let reviews=[];
function installReviewSection(){
  const nav=document.querySelector('.sidebar nav'),productsView=$('products');if(!nav||!productsView||$('reviews'))return;
  const productsNav=nav.querySelector('[data-section="products"]');
  productsNav.insertAdjacentHTML('beforebegin','<button class="nav-link" data-section="reviews">★ <span>Reviews</span></button>');
  productsView.insertAdjacentHTML('beforebegin','<section class="view" id="reviews"><div class="headline"><div><h2>Customer reviews</h2><p>Approve ratings, comments and photos before customers see them.</p></div></div><article class="panel table-panel"><div class="table-wrap"><table><thead><tr><th>Product</th><th>Customer</th><th>Rating</th><th>Review</th><th>Photos</th><th>Status</th><th></th></tr></thead><tbody id="reviewsTable"></tbody></table></div></article></section>');
  nav.querySelector('[data-section="reviews"]').addEventListener('click',()=>{ $('pageTitle').textContent='Customer reviews'; loadReviews(); });
}
function renderReviews(){
  const body=$('reviewsTable');if(!body)return;
  body.innerHTML=reviews.map(review=>`<tr><td><b>${safe(review.productName)}</b></td><td>${safe(review.customer)}</td><td><b style="color:#d99318">${'★'.repeat(review.rating)}${'☆'.repeat(5-review.rating)}</b></td><td>${safe(review.body)}</td><td>${review.images?.length?review.images.map(image=>`<img src="${image}" alt="Review" style="width:38px;height:38px;object-fit:cover;border-radius:5px;margin-right:4px">`).join(''):'—'}</td><td><span class="pill ${review.approved?'shipped':'warning'}">${review.approved?'Visible':'Waiting'}</span></td><td><button class="small-primary" data-review-approval="${review.id}" data-approved="${review.approved?'false':'true'}">${review.approved?'Hide':'Approve'}</button></td></tr>`).join('')||'<tr><td colspan="7">No customer reviews have been submitted yet.</td></tr>';
}
async function loadReviews(){
  try{const response=await fetch('/api/admin/reviews',{cache:'no-store'}),data=await response.json();if(!response.ok)throw new Error(data.error||'Reviews are not ready yet.');reviews=data.reviews;renderReviews();}catch(error){reviews=[];renderReviews();toast(error.message||'Reviews are not ready yet.');}
}
async function setReviewApproval(button){
  button.disabled=true;try{const response=await fetch(`/api/admin/reviews/${encodeURIComponent(button.dataset.reviewApproval)}/approval`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({approved:button.dataset.approved==='true'})}),data=await response.json();if(!response.ok)throw new Error(data.error||'Review could not be updated.');toast(button.dataset.approved==='true'?'Review is now visible to customers.':'Review was hidden.');await loadReviews();}catch(error){toast(error.message||'Review could not be updated.');}finally{button.disabled=false;}
}
installReviewSection();
function installLoyaltySection(){const nav=document.querySelector('.sidebar nav'),target=$('customers');if(!nav||!target||$('loyalty'))return;target.insertAdjacentHTML('afterend','<section class="view" id="loyalty"><div class="headline"><div><h2>MARKET HUB Coins</h2><p>Manage secure, delivery-based loyalty rewards.</p></div></div><article class="panel" id="loyaltyPanel"><p>Loading loyalty settings…</p></article></section>');nav.insertAdjacentHTML('beforeend','<button class="nav-link" data-section="loyalty">✦ <span>MARKET HUB Coins</span></button>');nav.querySelector('[data-section="loyalty"]').addEventListener('click',loadLoyalty);}
async function loadLoyalty(){const panel=$('loyaltyPanel');if(!panel)return;try{const response=await fetch('/api/admin/loyalty',{cache:'no-store'}),data=await response.json();if(!response.ok)throw new Error(data.error);const r=data.rules;panel.innerHTML=`<form id="loyaltyRules"><h3>Loyalty rules</h3><label>₹ spent per coin <input name="earnDivisorInr" type="number" min="1" value="${r.earnDivisorInr}"></label><label>₹ value of one coin <input name="coinValueInr" type="number" min="1" step=".01" value="${r.coinValueInr}"></label><label>Maximum redemption % <input name="maxRedemptionPercent" type="number" min="0" max="100" value="${r.maxRedemptionPercent}"></label><label>Reason for this change <input name="reason" required minlength="3" placeholder="For audit history"></label><button class="primary">Save loyalty rules</button></form><h3>Customer balances</h3><div class="table-wrap"><table><thead><tr><th>Customer</th><th>Available</th><th>Pending</th><th></th></tr></thead><tbody>${data.customers.map(customer=>`<tr><td>${safe(customer.name)}<small>${safe(customer.email||'')}</small></td><td>${customer.available}</td><td>${customer.pending}</td><td><button class="small-primary" data-coin-adjust="${customer.id}">Adjust</button></td></tr>`).join('')||'<tr><td colspan="4">No customer coin balances yet.</td></tr>'}</tbody></table></div>`;panel.querySelector('#loyaltyRules').onsubmit=async event=>{event.preventDefault();const body=Object.fromEntries(new FormData(event.currentTarget));try{const response=await fetch('/api/admin/loyalty/rules',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),data=await response.json();if(!response.ok)throw new Error(data.error);toast('Loyalty rules saved.');loadLoyalty();}catch(error){toast(error.message||'Could not save loyalty rules.');}};}catch(error){panel.innerHTML='<p>Loyalty data is not available yet.</p>';toast(error.message||'Loyalty data is not available yet.');}}
installLoyaltySection();
renderOrders();
buildModal();renderProducts();loadProducts();loadOrders();
$('productSearch').addEventListener('input',event=>renderProducts(event.target.value));
$('importPdfCatalogue').onclick=async()=>{try{await loadPdfPreview();if(!confirm(`Import ${pdfCatalogue.length.toLocaleString('en-IN')} PDF products into your live database? Existing PDF products will be updated.`))return;const button=$('importPdfCatalogue');button.disabled=true;button.textContent='Importing catalogue…';const response=await fetch('/api/admin/catalogue/import',{method:'POST'}),result=await response.json();if(!response.ok||!result.imported)throw new Error(result.error||'Import could not be completed.');toast(`${result.products.toLocaleString('en-IN')} products imported successfully.`);await loadProducts();}catch(error){toast(error.message||'Import could not be completed.')}finally{$('importPdfCatalogue').textContent='Import PDF catalogue';$('importPdfCatalogue').disabled=false;}};
document.addEventListener('click',event=>{const nav=event.target.closest('[data-section]'),jump=event.target.closest('[data-section-jump]'),edit=event.target.closest('[data-edit-product]'),refund=event.target.closest('[data-refund-order]'),packing=event.target.closest('[data-packing-video]');if(nav)activate(nav.dataset.section);if(jump)activate(jump.dataset.sectionJump);if(event.target.closest('[data-open-product]'))showModal();if(edit)showModal(catalogue.find(product=>product.id===edit.dataset.editProduct));if(refund)refundToWallet(refunds.find(item=>item.id===refund.dataset.refundOrder));if(packing){const order=orders.find(item=>item.uuid===packing.dataset.packingVideo);if(order)showPackingVideo(order);}if(event.target.closest('.modal-close')||event.target===$('modalBackdrop'))hideModal();const note=event.target.closest('[data-toast]');if(note)toast(note.dataset.toast);});
document.addEventListener('click',event=>{const button=event.target.closest('[data-review-approval]');if(button)setReviewApproval(button);});
document.addEventListener('click',async event=>{const button=event.target.closest('[data-coin-adjust]');if(!button)return;const coins=prompt('Enter coins to add (+) or remove (-).');const reason=prompt('Reason for this audited adjustment.');if(coins===null||reason===null)return;try{const response=await fetch(`/api/admin/loyalty/customers/${encodeURIComponent(button.dataset.coinAdjust)}/adjustment`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({coins:Number(coins),reason})}),data=await response.json();if(!response.ok)throw new Error(data.error);toast('Coin adjustment saved.');loadLoyalty();}catch(error){toast(error.message||'Coin adjustment could not be saved.');}});
