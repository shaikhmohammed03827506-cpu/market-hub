'use strict';
// Add an adapter only for an official supplier API or a source the store owner
// is contractually authorized to import. No marketplace-specific scraping lives here.
const adapters=new Map();
function registerAuthorizedAdapter(domain,adapter){if(!domain||typeof adapter?.analyze!=='function')throw new Error('Authorized adapter is invalid.');adapters.set(String(domain).toLowerCase(),adapter)}
function adapterFor(hostname){const host=String(hostname).toLowerCase();return [...adapters].find(([domain])=>host===domain||host.endsWith(`.${domain}`))?.[1]||null}
module.exports={registerAuthorizedAdapter,adapterFor};
