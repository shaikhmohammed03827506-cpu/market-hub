const adminProducts = [
  {name:'NovaPods Pro Wireless Earbuds',category:'Electronics',price:899,stock:42,sku:'MH-ELE-001',img:'https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=140&q=80'},
  {name:'Stainless Steel Insulated Bottle',category:'Home & Kitchen',price:349,stock:8,sku:'MH-HOM-021',img:'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=140&q=80'},
  {name:'Urban Classic Cotton T-Shirt',category:'Fashion',price:399,stock:76,sku:'MH-FAS-110',img:'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=140&q=80'},
  {name:'GlowCo Daily Skincare Set',category:'Beauty',price:649,stock:5,sku:'MH-BEA-043',img:'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=140&q=80'}
];
const orders=[
  {id:'#MH-1048',customer:'Riya Sharma',initials:'RS',items:'2 items',total:'₹1,248',payment:'Prepaid',status:'New'},
  {id:'#MH-1047',customer:'Arjun Mehta',initials:'AM',items:'4 items',total:'₹2,699',payment:'COD',status:'New'},
  {id:'#MH-1046',customer:'Sana Fatima',initials:'SF',items:'1 item',total:'₹899',payment:'Prepaid',status:'Packed'},
  {id:'#MH-1045',customer:'Karan Patel',initials:'KP',items:'3 items',total:'₹1,549',payment:'UPI',status:'Shipped'}
];
const saved=JSON.parse(localStorage.getItem('mh-admin-products')||'null');
let catalogue=saved||adminProducts;
let pdfCatalogue=[];
const statusClass=s=>s.toLowerCase();
const money=value=>'₹'+Number(value).toLocaleString('en-IN',{minimumFractionDigits:Number(value)%1?2:0,maximumFractionDigits:2});
const toast=message=>{const t=document.getElementById('toast');t.textContent=message;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),3500)};
const orderRow=(o,compact=false)=>compact?`<tr><td><b>${o.id}</b></td><td><div class="customer"><span class="avatar">${o.initials}</span>${o.customer}</div></td><td><b>${o.total}</b></td><td>${o.payment}</td><td><span class="pill ${statusClass(o.status)}">${o.status}</span></td><td><button class="row-button" data-toast="Order details will open here when connected to the live store.">View</button></td></tr>`:`<tr><td><input type="checkbox"></td><td><b>${o.id}</b></td><td><div class="customer"><span class="avatar">${o.initials}</span>${o.customer}</div></td><td>${o.items}</td><td><b>${o.total}</b></td><td>${o.payment}</td><td><span class="pill ${statusClass(o.status)}">${o.status}</span></td><td><button class="row-button" data-toast="Order details will open here when connected to the live store.">View</button></td></tr>`;
function renderProducts(query=''){
  const q=query.trim().toLowerCase();
  const filtered=q?catalogue.filter(product=>(product.name+product.category+product.sku).toLowerCase().includes(q)):catalogue;
  const visible=filtered.slice(0,100);
  document.getElementById('productsTable').innerHTML=visible.map(p=>`<tr><td><div class="product-cell"><img src="${p.img||p.image_url||''}" alt=""><span><strong>${p.name}</strong><small>${p.sku}</small></span></div></td><td>${p.category}</td><td><b>${money(p.price)}</b></td><td class="${p.stock<10?'stock-low':''}">${p.stock} units${p.stock<10?' · Low':''}</td><td><span class="pill shipped">Active</span></td><td><button class="row-button" data-toast="Product editing will be available after the secure admin backend is connected.">Edit</button></td></tr>`).join('')||'<tr><td colspan="6">No matching products.</td></tr>';
  const summary=document.getElementById('catalogueSummary');
  if(summary) summary.textContent=`${filtered.length.toLocaleString('en-IN')} product${filtered.length===1?'':'s'} ready. Showing the first ${Math.min(visible.length,100)}.`;
}
async function loadPdfPreview(){
  if(pdfCatalogue.length) return pdfCatalogue;
  const response=await fetch('assets/catalogue/products.json',{cache:'no-store'});
  if(!response.ok) throw new Error('The PDF catalogue file was not found.');
  pdfCatalogue=await response.json();
  catalogue=pdfCatalogue.map(product=>({...product,price:product.price_inr,stock:product.stock_quantity,img:product.image_url}));
  renderProducts(document.getElementById('productSearch')?.value||'');
  return pdfCatalogue;
}
document.getElementById('recentOrders').innerHTML=orders.slice(0,3).map(o=>orderRow(o,true)).join('');
document.getElementById('ordersTable').innerHTML=orders.map(o=>orderRow(o)).join('');
renderProducts();
loadPdfPreview().catch(()=>{});
const backdrop=document.getElementById('modalBackdrop');
const showModal=()=>backdrop.classList.add('show');
const hideModal=()=>backdrop.classList.remove('show');
function activate(section){
  document.querySelectorAll('.view').forEach(v=>v.classList.toggle('active',v.id===section));
  document.querySelectorAll('.nav-link').forEach(b=>b.classList.toggle('active',b.dataset.section===section));
  const names={dashboard:'Good morning, Mohammed',orders:'Order management',products:'Product catalogue',categories:'Category manager',shipping:'Delhivery shipping',customers:'Customer management',offers:'Offers & coupons',settings:'Store settings'};
  document.getElementById('pageTitle').textContent=names[section]||'MARKET HUB';
  if(section==='products') loadPdfPreview().catch(()=>toast('PDF catalogue preview is unavailable until the website files are uploaded.'));
  window.scrollTo({top:0,behavior:'smooth'});
}
document.addEventListener('click',e=>{
  const nav=e.target.closest('[data-section]');const jump=e.target.closest('[data-section-jump]');
  if(nav)activate(nav.dataset.section);if(jump)activate(jump.dataset.sectionJump);
  if(e.target.closest('[data-open-product]'))showModal();if(e.target.closest('.modal-close')||e.target===backdrop)hideModal();
  const note=e.target.closest('[data-toast]');if(note)toast(note.dataset.toast);
});
document.getElementById('productSearch').addEventListener('input',event=>renderProducts(event.target.value));
document.getElementById('importPdfCatalogue').onclick=async()=>{
  try{
    await loadPdfPreview();
    if(!confirm(`Import ${pdfCatalogue.length.toLocaleString('en-IN')} PDF products into your live database? Existing PDF products will be updated with the same price, stock 99, category, weight and photo.`)) return;
    const button=document.getElementById('importPdfCatalogue');button.disabled=true;button.textContent='Importing catalogue…';
    const response=await fetch('/api/admin/catalogue/import',{method:'POST'});const result=await response.json();
    if(!response.ok||!result.imported) throw new Error(result.error||'Import could not be completed.');
    toast(`${result.products.toLocaleString('en-IN')} products and ${result.categories} categories imported successfully.`);
    button.textContent='Catalogue imported';
  }catch(error){toast(error.message||'Import could not be completed.');document.getElementById('importPdfCatalogue').textContent='Import PDF catalogue';}
  finally{document.getElementById('importPdfCatalogue').disabled=false;}
};
document.getElementById('productForm').onsubmit=e=>{
  e.preventDefault();const f=new FormData(e.target);
  catalogue.unshift({name:f.get('name'),category:f.get('category'),price:Number(f.get('price')),stock:Number(f.get('stock')),sku:f.get('sku')||'MH-NEW-001',img:'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=140&q=80'});
  localStorage.setItem('mh-admin-products',JSON.stringify(catalogue));renderProducts();e.target.reset();hideModal();toast('Product saved to your local admin catalogue.');
};
