// Server-only PostgreSQL access. DATABASE_URL must exist only in .env or hosting secrets.
const fs = require('fs');
const path = require('path');
let pool;

function database() {
  if (!process.env.DATABASE_URL) throw new Error('Database is not configured. Add DATABASE_URL to the private .env file.');
  if (!pool) {
    const { Pool } = require('pg');
    pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: { rejectUnauthorized: false },
      max: 8,
      idleTimeoutMillis: 20_000
    });
  }
  return pool;
}

async function databaseHealth() {
  const result = await database().query('select now() as connected_at');
  return Boolean(result.rows[0]);
}

async function listActiveProducts() {
  const result = await database().query(
    'select id, sku, name, slug, price_inr, compare_at_price_inr, stock_quantity from products where is_active = true order by created_at desc limit 50'
  );
  return result.rows;
}

const toSlug = value => String(value).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

// Imports the catalogue extracted from the owner's PDF. This is deliberately an
// admin-only server function: no browser can write product data directly.
async function importPdfCatalogue() {
  const cataloguePath = path.join(__dirname, 'assets', 'catalogue', 'products.json');
  if (!fs.existsSync(cataloguePath)) throw new Error('The PDF catalogue file is not available on this server.');
  const items = JSON.parse(fs.readFileSync(cataloguePath, 'utf8'));
  if (!Array.isArray(items) || !items.length) throw new Error('The PDF catalogue is empty.');

  const client = await database().connect();
  try {
    await client.query('begin');
    // Some supplier prices include paise (for example ₹1.50), so retain the
    // exact PDF price instead of rounding it up.
    await client.query('alter table products alter column price_inr type numeric(10,2) using price_inr::numeric(10,2)');
    await client.query('alter table products alter column compare_at_price_inr type numeric(10,2) using compare_at_price_inr::numeric(10,2)');

    const categories = [...new Set(items.map(item => item.category))];
    for (const category of categories) {
      await client.query(
        'insert into categories (name, slug) values ($1, $2) on conflict (slug) do update set name = excluded.name, is_active = true',
        [category, toSlug(category)]
      );
    }
    const categoryRows = await client.query('select id, slug from categories where slug = any($1::text[])', [categories.map(toSlug)]);
    const categoryIds = new Map(categoryRows.rows.map(row => [row.slug, row.id]));

    const imported = [];
    for (let start = 0; start < items.length; start += 100) {
      const batch = items.slice(start, start + 100);
      const values = [];
      const params = [];
      batch.forEach((item, index) => {
        const at = index * 9;
        values.push(`($${at + 1}, $${at + 2}, $${at + 3}, $${at + 4}, $${at + 5}, $${at + 6}::jsonb, $${at + 7}, $${at + 8}, $${at + 9}, 10, 10, 10, true)`);
        params.push(
          categoryIds.get(toSlug(item.category)) || null,
          item.sku,
          item.name,
          `${toSlug(item.name)}-${toSlug(item.sku)}`,
          `Imported from supplier PDF. Source code: ${item.source_code}.`,
          JSON.stringify({ source_code: item.source_code, source_page: item.source_page, weight_grams: item.weight_grams }),
          item.price_inr,
          item.stock_quantity,
          Number(item.weight_grams) / 1000
        );
      });
      const result = await client.query(
        `insert into products (category_id, sku, name, slug, description, specifications, price_inr, stock_quantity, weight_kg, length_cm, breadth_cm, height_cm, is_active)
         values ${values.join(',')}
         on conflict (sku) do update set category_id = excluded.category_id, name = excluded.name, slug = excluded.slug, description = excluded.description, specifications = excluded.specifications, price_inr = excluded.price_inr, stock_quantity = excluded.stock_quantity, weight_kg = excluded.weight_kg, is_active = true, updated_at = now()
         returning id, sku`,
        params
      );
      imported.push(...result.rows);
    }

    const productIds = imported.map(row => row.id);
    await client.query('delete from product_images where product_id = any($1::uuid[])', [productIds]);
    for (let start = 0; start < items.length; start += 200) {
      const batch = items.slice(start, start + 200);
      const values = [];
      const params = [];
      batch.forEach((item, index) => {
        const at = index * 4;
        const product = imported.find(row => row.sku === item.sku);
        values.push(`($${at + 1}, $${at + 2}, $${at + 3}, 0)`);
        params.push(product.id, item.image_url, item.name);
      });
      await client.query(`insert into product_images (product_id, url, alt_text, sort_order) values ${values.join(',')}`, params);
    }
    await client.query('commit');
    return { products: items.length, categories: categories.length };
  } catch (error) {
    await client.query('rollback');
    throw error;
  } finally {
    client.release();
  }
}

module.exports = { database, databaseHealth, listActiveProducts, importPdfCatalogue };
