const $ = id => document.getElementById(id);
const money = value => Number(value || 0).toLocaleString('en-IN');
const message = text => $('authMessage').textContent = text || '';
const api = async (url, options = {}) => {
  const response = await fetch(url, {credentials:'same-origin', headers:{'Content-Type':'application/json', ...(options.headers || {})}, ...options});
  const body = response.status === 204 ? {} : await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || 'Please try again.');
  return body;
};
function safe(value) { const node = document.createElement('span'); node.textContent = value || ''; return node.innerHTML; }
function showDashboard(account) {
  $('accountGate').hidden = true; $('accountDashboard').hidden = false; $('logout').hidden = false;
  $('customerName').textContent = account.fullName.split(' ')[0] || 'there';
  $('walletBalance').textContent = money(account.walletBalance); $('coinBalance').textContent = money(account.coinBalance);
  $('referralCode').textContent = account.referralCode;
  $('copyCode').dataset.code = account.referralCode; $('copyCode2').dataset.code = account.referralCode;
  const activity = Array.isArray(account.walletActivity) ? account.walletActivity : [];
  $('walletEmpty').hidden = activity.length > 0;
  $('walletActivity').innerHTML = activity.map(item => `<div class="activity-row"><span><b>${safe(String(item.type).replace('_',' '))}</b><small>${safe(item.note || 'MARKET HUB wallet')}</small></span><strong>${item.type === 'debit' ? '−' : '+'}₹${money(item.amount)}</strong></div>`).join('');
  loadOrders();
  loadReturns();
  loadReviews();
}
const dateText = value => value ? new Date(value).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'}) : 'Will be confirmed after shipping';
async function loadOrders() {
  const holder = $('customerOrders');
  try {
    const data = await api('/api/customer/orders');
    holder.innerHTML = data.orders.map(order => `<div class="order-item"><span><b>Order #MH-${order.orderNumber}</b><small>${order.itemCount} item${order.itemCount===1?'':'s'} · ₹${money(order.totalInr)} · ${safe(order.status.replace('_',' '))}</small></span><span class="delivery-date"><b>${order.status==='delivered'?'Delivered':`Expected ${dateText(order.estimatedDeliveryDate)}`}</b><small>${order.awb?`Delhivery tracking: ${safe(order.awb)}`:'Tracking will appear after shipping'}</small></span></div>`).join('') || '<p class="muted">You have no orders yet. Start shopping to see delivery details here.</p>';
  } catch { holder.innerHTML = '<p class="muted">Orders will appear here after checkout.</p>'; }
}
async function loadReturns() {
  const holder = $('returnItems');
  try {
    const data = await api('/api/customer/returns');
    holder.innerHTML = data.items.map(item => `<div class="return-item"><span><b>${safe(item.productName)}</b><small>Order #MH-${item.orderNumber} · ${item.quantity} item${item.quantity===1?'':'s'}</small></span>${item.returnStatus?`<em>${safe(item.returnStatus.replace('_',' '))}</em>`:`<button data-return-item="${item.orderItemId}" data-product="${safe(item.productName)}">Request return</button>`}</div>`).join('') || '<p class="muted">You have no delivered products eligible for return right now.</p>';
  } catch { holder.innerHTML = '<p class="muted">Returns will appear here after a delivered order.</p>'; }
}
async function requestReturn(button) {
  const reason = prompt(`Why do you want to return ${button.dataset.product}?`); if (reason === null) return;
  const details = prompt('Add any extra details (optional):') || '';
  button.disabled = true;
  try { await api('/api/customer/returns', {method:'POST',body:JSON.stringify({orderItemId:button.dataset.returnItem,reason,details})}); alert('Your return request has been sent for review.'); await loadReturns(); }
  catch (error) { alert(error.message); } finally { button.disabled = false; }
}
let reviewableItems = [];
async function loadReviews() {
  const holder = $('reviewItems'), form = $('reviewForm'), select = $('reviewOrderItem');
  if (!holder || !form || !select) return;
  try {
    const data = await api('/api/customer/reviews');
    reviewableItems = (data.items || []).filter(item => !item.reviewed);
    if (!reviewableItems.length) {
      form.hidden = true;
      holder.innerHTML = '<p class="muted">You have no delivered products ready for review right now.</p>';
      return;
    }
    holder.innerHTML = `<p class="muted">${reviewableItems.length} delivered product${reviewableItems.length === 1 ? '' : 's'} ready for your review.</p>`;
    select.innerHTML = reviewableItems.map(item => `<option value="${item.orderItemId}">${safe(item.productName)} — Order #MH-${item.orderNumber}</option>`).join('');
    form.hidden = false;
  } catch { form.hidden = true; holder.innerHTML = '<p class="muted">Reviews will appear here after a delivered order.</p>'; }
}
function photoData(file) {
  return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(file); });
}
async function submitReview(event) {
  event.preventDefault();
  const form = event.currentTarget, button = form.querySelector('button'), photos = [...$('reviewPhotos').files];
  $('reviewMessage').textContent = '';
  if (photos.length > 3 || photos.some(photo => photo.size > 500 * 1024 || !['image/jpeg','image/png','image/webp'].includes(photo.type))) { $('reviewMessage').textContent = 'Use up to 3 JPG, PNG or WebP photos under 500 KB each.'; return; }
  button.disabled = true; button.textContent = 'Sending review…';
  try {
    await api('/api/customer/reviews', {method:'POST',body:JSON.stringify({orderItemId:$('reviewOrderItem').value,rating:Number($('reviewRating').value),body:$('reviewBody').value,images:await Promise.all(photos.map(photoData))})});
    form.reset(); $('reviewMessage').textContent = 'Thank you. Your review was sent for approval.'; await loadReviews();
  } catch (error) { $('reviewMessage').textContent = error.message; } finally { button.disabled = false; button.textContent = 'Send review'; }
}
async function loadAccount() {
  try { const data = await api('/api/customer/account'); if (data.authenticated) showDashboard(data.account); }
  catch { $('accountGate').hidden = false; }
}
function prepareAuthForms() {
  document.head.insertAdjacentHTML('beforeend', '<style>.auth-card form[hidden]{display:none!important}</style>');
  const title = document.querySelector('.auth-card-head h2'), subtitle = document.querySelector('.auth-card-head p');
  if (title) title.id = 'authTitle'; if (subtitle) subtitle.id = 'authSubtitle';
  document.querySelector('#loginForm .auth-help')?.remove();
  const registerForm = $('registerForm');
  if (registerForm && !registerForm.querySelector('[name="phone"]')) {
    const emailLabel = registerForm.querySelector('[name="email"]')?.closest('label');
    emailLabel?.insertAdjacentHTML('beforebegin', '<label>Phone number<input name="phone" type="tel" required autocomplete="tel" inputmode="numeric" pattern="[0-9]{10}" placeholder="Enter 10-digit mobile number"></label>');
  }
}
prepareAuthForms();
document.querySelectorAll('[data-mode]').forEach(button => button.addEventListener('click', () => {
  document.querySelectorAll('[data-mode]').forEach(tab => tab.classList.toggle('active', tab === button));
  $('loginForm').hidden = button.dataset.mode !== 'login'; $('registerForm').hidden = button.dataset.mode !== 'register'; message('');
  const signingIn = button.dataset.mode === 'login';
  $('authTitle').textContent = signingIn ? 'Welcome back' : 'Create your account';
  $('authSubtitle').textContent = signingIn ? 'Sign in to continue shopping and see your rewards.' : 'Create an account to track orders, refunds and MARKET HUB Coins.';
}));
async function submitForm(form, endpoint) {
  const button = form.querySelector('button'); button.disabled = true; message('');
  try {
    const fields = Object.fromEntries(new FormData(form));
    await api(endpoint, {method:'POST', body:JSON.stringify(fields)}); await loadAccount();
  } catch (error) { message(error.message); } finally { button.disabled = false; }
}
$('loginForm').addEventListener('submit', event => { event.preventDefault(); submitForm(event.currentTarget, '/api/auth/customer/login'); });
$('registerForm').addEventListener('submit', event => { event.preventDefault(); submitForm(event.currentTarget, '/api/auth/customer/register'); });
async function shareCode(event) {
  const code = event.currentTarget.dataset.code; if (!code) return;
  const text = `Join MARKET HUB with my referral code ${code} and earn 10 coins after your first delivered order!`;
  try { if (navigator.share) await navigator.share({title:'MARKET HUB',text,url:location.origin}); else { await navigator.clipboard.writeText(text); alert('Referral message copied.'); } } catch {}
}
$('copyCode').addEventListener('click', shareCode); $('copyCode2').addEventListener('click', shareCode);
$('logout').addEventListener('click', async () => { await api('/api/auth/customer/logout', {method:'POST'}); location.reload(); });
$('reviewForm')?.addEventListener('submit', submitReview);
document.addEventListener('click', event => { const button = event.target.closest('[data-return-item]'); if (button) requestReturn(button); });
loadAccount();
