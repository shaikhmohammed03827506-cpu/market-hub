/* MARKET HUB local server and secure payment foundation.
   Keep .env private. It must never be uploaded with the public website files. */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = __dirname;
const envPath = path.join(root, '.env');
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
  }
}

const config = {
  port: Number(process.env.PORT || 4173),
  databaseUrl: process.env.DATABASE_URL || '',
  razorpayKeyId: process.env.RAZORPAY_KEY_ID || '',
  razorpayKeySecret: process.env.RAZORPAY_KEY_SECRET || '',
  razorpayWebhookSecret: process.env.RAZORPAY_WEBHOOK_SECRET || '',
  shiprocketCheckoutApiKey: process.env.SHIPROCKET_CHECKOUT_API_KEY || '',
  shiprocketCheckoutSecret: process.env.SHIPROCKET_CHECKOUT_SECRET_KEY || '',
  shiprocketCheckoutBaseUrl: (process.env.SHIPROCKET_CHECKOUT_BASE_URL || 'https://checkout-api.shiprocket.com').replace(/\/$/, ''),
  delhiveryToken: process.env.DELHIVERY_API_TOKEN || '',
  delhiveryPickupLocation: process.env.DELHIVERY_PICKUP_LOCATION || '',
  delhiveryCodEnabled: process.env.DELHIVERY_COD_ENABLED === 'true',
  adminEmail: (process.env.ADMIN_EMAIL || '').trim().toLowerCase(),
  adminPassword: process.env.ADMIN_PASSWORD || '',
  logo: process.env.STORE_LOGO_URL || ''
};

// Small demo-price fallback. The catalogue price is calculated on the server below.
const priceCatalog = new Map([
  [1, 899], [2, 349], [3, 399], [4, 649], [5, 1799], [6, 299], [7, 999], [8, 799]
]);
const contentTypes = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.json':'application/json; charset=utf-8'};
const sendJson = (res, status, body) => { res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}); res.end(JSON.stringify(body)); };
const readBody = req => new Promise((resolve, reject) => { let body=''; req.on('data', chunk => { body += chunk; if (body.length > 1_000_000) { reject(new Error('Request too large')); req.destroy(); } }); req.on('end', () => resolve(body)); req.on('error', reject); });
const secureEqual = (first, second) => { const a=Buffer.from(first||''), b=Buffer.from(second||''); return a.length===b.length && crypto.timingSafeEqual(a,b); };
const adminSessions = new Map();
const customerSessions = new Map();
const parseCookies = request => Object.fromEntries((request.headers.cookie||'').split(';').map(item=>item.trim()).filter(Boolean).map(item=>{const point=item.indexOf('=');return point<0?[item,'']:[item.slice(0,point),decodeURIComponent(item.slice(point+1))]}));
const validAdminSession = request => { const token=parseCookies(request).mh_admin_session; const session=token&&adminSessions.get(token); if(!session||session.expiresAt<Date.now()){if(token)adminSessions.delete(token);return false}return true; };
const makeAdminSession = () => { const token=crypto.randomBytes(32).toString('base64url'); adminSessions.set(token,{expiresAt:Date.now()+8*60*60*1000}); return token; };
const adminCookie = (request,token) => `mh_admin_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800${request.headers['x-forwarded-proto']==='https'||request.socket.encrypted?'; Secure':''}`;
const customerCookie = (request,token) => `mh_customer_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=2592000${request.headers['x-forwarded-proto']==='https'||request.socket.encrypted?'; Secure':''}`;
const validCustomerSession = request => {
  const token = parseCookies(request).mh_customer_session;
  const session = token && customerSessions.get(token);
  if (!session || session.expiresAt < Date.now()) { if (token) customerSessions.delete(token); return null; }
  return session.userId;
};
const makeCustomerSession = userId => {
  const token = crypto.randomBytes(32).toString('base64url');
  customerSessions.set(token, { userId, expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000 });
  return token;
};

async function razorpay(endpoint, body) {
  const authorization = Buffer.from(`${config.razorpayKeyId}:${config.razorpayKeySecret}`).toString('base64');
  const response = await fetch(`https://api.razorpay.com/v1${endpoint}`, {method:'POST',headers:{'Authorization':`Basic ${authorization}`,'Content-Type':'application/json'},body:JSON.stringify(body)});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.description || 'Razorpay could not create the payment order.');
  return data;
}

// Shiprocket Checkout (Fastrr) signs the exact JSON body using the private
// API secret. The secret stays on this server and is never sent to a browser.
async function shiprocketCheckout(endpoint, body) {
  if (!config.shiprocketCheckoutApiKey || !config.shiprocketCheckoutSecret) {
    throw new Error('Shiprocket Checkout is not configured yet.');
  }
  const serialized = JSON.stringify(body);
  const hmac = crypto.createHmac('sha256', config.shiprocketCheckoutSecret).update(serialized).digest('base64');
  const response = await fetch(`${config.shiprocketCheckoutBaseUrl}${endpoint}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Api-Key': config.shiprocketCheckoutApiKey,
      'X-Api-HMAC-SHA256': hmac
    },
    body: serialized
  });
  let data;
  try { data = await response.json(); } catch { data = {}; }
  if (!response.ok || data.ok === false) throw new Error(data.error?.message || data.error || 'Shiprocket Checkout could not start.');
  return data;
}

// Never trust a product price submitted by the customer's browser.
let cataloguePriceBySku;
let catalogueProductBySku;
function catalogueProducts() {
  if (catalogueProductBySku) return catalogueProductBySku;
  const cataloguePath = path.join(root, 'assets', 'catalogue', 'products.json');
  const items = JSON.parse(fs.readFileSync(cataloguePath, 'utf8'));
  catalogueProductBySku = new Map(items.map(item => [String(item.sku), item]));
  return catalogueProductBySku;
}
function cataloguePrices() {
  if (cataloguePriceBySku) return cataloguePriceBySku;
  const cataloguePath = path.join(root, 'assets', 'catalogue', 'products.json');
  const items = JSON.parse(fs.readFileSync(cataloguePath, 'utf8'));
  cataloguePriceBySku = new Map(items.map(item => [String(item.sku), {
    price: Number(item.price_inr), stock: Number(item.stock_quantity)
  }]));
  return cataloguePriceBySku;
}

function publicOrigin(request) {
  const host = String(request.headers.host || '').trim();
  if (!/^[a-z0-9.-]+(?::\d+)?$/i.test(host)) throw new Error('The public website address is not available.');
  const protocol = request.headers['x-forwarded-proto'] === 'http' ? 'http' : 'https';
  return `${protocol}://${host}`;
}

function shiprocketProductPayload(product, origin) {
  const image = product.image_url ? `${origin}${product.image_url.startsWith('/') ? product.image_url : `/${product.image_url}`}` : '';
  const now = new Date().toISOString();
  return {
    id: Number(product.id), title: String(product.name),
    body_html: `<p>${String(product.name).replace(/[<>&]/g, '')}</p>`, vendor: 'MARKET HUB',
    product_type: String(product.category || 'General'), handle: String(product.sku).toLowerCase().replace(/[^a-z0-9]+/g, '-'),
    created_at: now, updated_at: now, tags: String(product.category || ''), status: 'active',
    variants: [{ id: Number(product.id), title: 'Default', price: Number(product.price_inr).toFixed(2), sku: String(product.sku), created_at: now, updated_at: now, taxable: true, grams: Number(product.weight_grams || 500), image: { src: image }, weight: Number(product.weight_grams || 500) / 1000, weight_unit: 'kg' }],
    image: { src: image }
  };
}

async function prepareShiprocketCart(request, cart) {
  if (!Array.isArray(cart) || !cart.length || cart.length > 50) throw new Error('Your cart is invalid.');
  const catalogue = catalogueProducts();
  const seen = new Set();
  const items = [];
  for (const item of cart) {
    const quantity = Number(item.qty);
    const sku = String(item.sku || '').trim();
    const product = catalogue.get(sku);
    if (!product || !Number.isInteger(quantity) || quantity < 1 || quantity > 99) throw new Error('Please refresh your cart and try again.');
    if (quantity > Number(product.stock_quantity)) throw new Error(`${product.name} does not have enough stock.`);
    if (!seen.has(sku)) {
      // Shiprocket Checkout needs each product in its secure catalogue before
      // it can accept its variant id in a checkout token.
      await shiprocketCheckout('/wh/v1/custom/product', shiprocketProductPayload(product, publicOrigin(request)));
      seen.add(sku);
    }
    items.push({ variant_id: String(product.id), quantity });
  }
  return items;
}

function calculateCartTotal(cart) {
  let totalPaise = 0;
  const catalogue = cataloguePrices();
  for (const item of cart) {
    const qty = Number(item.qty);
    if (!Number.isInteger(qty) || qty < 1 || qty > 99) throw new Error('A cart quantity is invalid.');
    const sku = String(item.sku || '').trim();
    const catalogueItem = sku && catalogue.get(sku);
    if (catalogueItem) {
      if (qty > catalogueItem.stock) throw new Error('One of these products no longer has enough stock.');
      totalPaise += Math.round(catalogueItem.price * 100) * qty;
      continue;
    }
    const legacyId = Number(item.id);
    if (!Number.isInteger(legacyId) || !priceCatalog.has(legacyId)) throw new Error('A cart item is no longer available.');
    totalPaise += priceCatalog.get(legacyId) * 100 * qty;
  }
  return totalPaise;
}

async function handleApi(req, res, url) {
  if (req.method==='POST' && url.pathname==='/api/auth/admin/login') {
    const {email='',password=''}=JSON.parse(await readBody(req));
    if(!config.adminEmail||!config.adminPassword) return sendJson(res,503,{authenticated:false,error:'Admin login is not configured.'});
    if(!secureEqual(String(email).trim().toLowerCase(),config.adminEmail)||!secureEqual(String(password),config.adminPassword)) return sendJson(res,401,{authenticated:false,error:'Email or password is incorrect.'});
    res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Set-Cookie':adminCookie(req,makeAdminSession()),'Cache-Control':'no-store'});return res.end(JSON.stringify({authenticated:true}));
  }
  if (req.method==='GET' && url.pathname==='/api/auth/admin/session') return sendJson(res,200,{authenticated:validAdminSession(req)});
  if (req.method==='POST' && url.pathname==='/api/auth/admin/logout') { const token=parseCookies(req).mh_admin_session;if(token)adminSessions.delete(token);res.writeHead(204,{'Set-Cookie':'mh_admin_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});return res.end(); }
  if (req.method === 'POST' && url.pathname === '/api/auth/customer/register') {
    try {
      const { registerCustomer } = require('./db');
      const customer = await registerCustomer(JSON.parse(await readBody(req)));
      res.writeHead(201, {'Content-Type':'application/json; charset=utf-8','Set-Cookie':customerCookie(req, makeCustomerSession(customer.id)),'Cache-Control':'no-store'});
      return res.end(JSON.stringify({authenticated:true, customer:{fullName:customer.full_name,email:customer.email,referralCode:customer.referral_code}}));
    } catch (error) { return sendJson(res,400,{authenticated:false,error:error.message || 'Your account could not be created.'}); }
  }
  if (req.method === 'POST' && url.pathname === '/api/auth/customer/login') {
    try {
      const { email='', password='' } = JSON.parse(await readBody(req));
      const { authenticateCustomer } = require('./db');
      const customer = await authenticateCustomer(email, password);
      if (!customer) return sendJson(res,401,{authenticated:false,error:'Email or password is incorrect.'});
      res.writeHead(200, {'Content-Type':'application/json; charset=utf-8','Set-Cookie':customerCookie(req, makeCustomerSession(customer.id)),'Cache-Control':'no-store'});
      return res.end(JSON.stringify({authenticated:true,customer:{fullName:customer.fullName,email:customer.email,referralCode:customer.referralCode}}));
    } catch { return sendJson(res,503,{authenticated:false,error:'Customer sign-in is not ready yet.'}); }
  }
  if (req.method === 'POST' && url.pathname === '/api/auth/customer/logout') {
    const token = parseCookies(req).mh_customer_session; if (token) customerSessions.delete(token);
    res.writeHead(204, {'Set-Cookie':'mh_customer_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'}); return res.end();
  }
  if (req.method === 'GET' && url.pathname === '/api/customer/account') {
    const userId = validCustomerSession(req); if (!userId) return sendJson(res,401,{authenticated:false});
    try {
      const { customerAccount } = require('./db'); const account = await customerAccount(userId);
      if (!account) return sendJson(res,401,{authenticated:false});
      return sendJson(res,200,{authenticated:true,account});
    } catch (error) { console.error('Customer account query failed:', error.message); return sendJson(res,503,{authenticated:false,error:'Your account is not ready yet.'}); }
  }
  if (req.method === 'GET' && url.pathname === '/api/customer/returns') {
    const userId = validCustomerSession(req); if (!userId) return sendJson(res,401,{authenticated:false});
    try { const { customerReturnItems } = require('./db'); return sendJson(res,200,{items:await customerReturnItems(userId)}); }
    catch (error) { console.error('Customer returns query failed:', error.message); return sendJson(res,503,{error:'Returns are not ready yet.'}); }
  }
  if (req.method === 'GET' && url.pathname === '/api/customer/orders') {
    const userId = validCustomerSession(req); if (!userId) return sendJson(res,401,{authenticated:false});
    try { const { customerOrders } = require('./db'); return sendJson(res,200,{orders:await customerOrders(userId)}); }
    catch (error) { console.error('Customer orders query failed:', error.message); return sendJson(res,503,{error:'Orders are not ready yet.'}); }
  }
  if (req.method === 'POST' && url.pathname === '/api/customer/returns') {
    const userId = validCustomerSession(req); if (!userId) return sendJson(res,401,{authenticated:false});
    try { const { requestCustomerReturn } = require('./db'); return sendJson(res,201,await requestCustomerReturn(userId, JSON.parse(await readBody(req)))); }
    catch (error) { return sendJson(res,400,{requested:false,error:error.message || 'The return request could not be submitted.'}); }
  }
  if (req.method==='POST' && url.pathname==='/api/admin/catalogue/import') {
    if (!validAdminSession(req)) return sendJson(res,401,{imported:false,error:'Please sign in to the admin panel first.'});
    try {
      const { importPdfCatalogue } = require('./db');
      const result = await importPdfCatalogue();
      return sendJson(res,200,{imported:true,...result});
    } catch (error) {
      console.error('Catalogue import failed:', error.message);
      return sendJson(res,503,{imported:false,error:'The catalogue could not be imported. Confirm the live database connection and try again.'});
    }
  }
  if (req.method==='GET' && url.pathname==='/api/admin/products') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { listAdminProducts } = require('./db'); return sendJson(res,200,{products:await listAdminProducts()}); }
    catch (error) { console.error('Admin product query failed:', error.message); return sendJson(res,503,{error:'The product database is not ready yet.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/admin/orders') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { listAdminOrders } = require('./db'); return sendJson(res,200,{orders:await listAdminOrders()}); }
    catch (error) { console.error('Admin order query failed:', error.message); return sendJson(res,503,{error:'Orders are not ready yet.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/admin/refunds') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { listAdminRefunds } = require('./db'); return sendJson(res,200,{refunds:await listAdminRefunds()}); }
    catch (error) { console.error('Admin refunds query failed:', error.message); return sendJson(res,503,{error:'Refunds are not ready yet.'}); }
  }
  const refundRoute = url.pathname.match(/^\/api\/admin\/orders\/([0-9a-f-]{36})\/refund$/i);
  if (refundRoute && req.method==='POST') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { refundOrderToWallet } = require('./db'); return sendJson(res,200,{refunded:true,...await refundOrderToWallet(refundRoute[1], JSON.parse(await readBody(req)))}); }
    catch (error) { console.error('Wallet refund failed:', error.message); return sendJson(res,400,{refunded:false,error:error.message || 'The wallet refund could not be approved.'}); }
  }
  const productRoute = url.pathname.match(/^\/api\/admin\/products\/([0-9a-f-]{36})$/i);
  if (req.method==='POST' && url.pathname==='/api/admin/products') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { saveProduct } = require('./db'); return sendJson(res,201,{product:await saveProduct(JSON.parse(await readBody(req)))}); }
    catch (error) { console.error('Product create failed:', error.message); return sendJson(res,400,{error:error.message||'The product could not be saved.'}); }
  }
  if (productRoute && req.method==='PUT') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { saveProduct } = require('./db'); return sendJson(res,200,{product:await saveProduct(JSON.parse(await readBody(req)),productRoute[1])}); }
    catch (error) { console.error('Product update failed:', error.message); return sendJson(res,400,{error:error.message||'The product could not be updated.'}); }
  }
  if (productRoute && req.method==='DELETE') {
    if (!validAdminSession(req)) return sendJson(res,401,{error:'Please sign in to the admin panel first.'});
    try { const { deactivateProduct } = require('./db'); await deactivateProduct(productRoute[1]); return sendJson(res,200,{removed:true}); }
    catch (error) { console.error('Product removal failed:', error.message); return sendJson(res,400,{error:error.message||'The product could not be removed.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/health/database') {
    try { const { databaseHealth } = require('./db'); return sendJson(res,200,{connected:await databaseHealth()}); }
    catch (error) { console.error('Database connection failed:', error.message); return sendJson(res,503,{connected:false,error:'Database connection is not ready.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/products') {
    try { const { listActiveProducts } = require('./db'); return sendJson(res,200,{products:await listActiveProducts()}); }
    catch (error) { console.error('Product query failed:', error.message); return sendJson(res,503,{error:'Product catalogue database is not ready.'}); }
  }
  if (req.method==='GET' && url.pathname==='/api/config/payment') return sendJson(res, 200, {ready:Boolean(config.razorpayKeyId && config.razorpayKeySecret),keyId:config.razorpayKeyId,logo:config.logo});
  if (req.method==='GET' && url.pathname==='/api/config/shipping') return sendJson(res, 200, {provider:'Delhivery',ready:Boolean(config.delhiveryToken),pickupLocation:config.delhiveryPickupLocation,cashOnDelivery:config.delhiveryCodEnabled});
  if (req.method==='GET' && url.pathname==='/api/config/shiprocket-checkout') return sendJson(res, 200, {ready:Boolean(config.shiprocketCheckoutApiKey && config.shiprocketCheckoutSecret)});
  if (req.method==='POST' && url.pathname==='/api/checkout/shiprocket/access-token') {
    try {
      const { cart=[] } = JSON.parse(await readBody(req));
      const items = await prepareShiprocketCart(req, cart);
      const checkout = await shiprocketCheckout('/api/v1/access-token/checkout', {
        cart_data: { items }, redirect_url: `${publicOrigin(req)}/checkout-success.html`, timestamp: new Date().toISOString()
      });
      const token = checkout.result?.token;
      if (!token) throw new Error('Shiprocket Checkout did not return a checkout token.');
      return sendJson(res,200,{token,expiresAt:checkout.result?.expires_at || null});
    } catch (error) {
      console.error('Shiprocket Checkout start failed:', error.message);
      return sendJson(res,502,{error:error.message || 'Shiprocket Checkout could not start.'});
    }
  }
  if (req.method==='POST' && url.pathname==='/api/webhooks/shiprocket-checkout/order') {
    try {
      const order = JSON.parse(await readBody(req));
      const { recordShiprocketOrder } = require('./db');
      const saved = await recordShiprocketOrder(order);
      console.log('Shiprocket Checkout order saved:', saved.orderNumber, order.status || 'unknown');
      return sendJson(res,200,{received:true,orderNumber:saved.orderNumber});
    } catch { return sendJson(res,400,{error:'Invalid Shiprocket Checkout webhook.'}); }
  }
  if (req.method==='POST' && url.pathname==='/api/payments/razorpay/order') {
    if (!config.razorpayKeyId || !config.razorpayKeySecret) return sendJson(res, 503, {error:'Razorpay keys are not configured on the server.'});
    const {cart=[]} = JSON.parse(await readBody(req));
    if (!Array.isArray(cart) || !cart.length || cart.length>50) return sendJson(res, 400, {error:'Your cart is invalid.'});
    let totalPaise;
    try { totalPaise = calculateCartTotal(cart); }
    catch (error) { return sendJson(res,400,{error:error.message||'A cart item is no longer available.'}); }
    const receipt=`mh_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
    const order=await razorpay('/orders',{amount:totalPaise,currency:'INR',receipt,notes:{store:'MARKET HUB'}});
    return sendJson(res,200,{orderId:order.id,amount:order.amount,receipt});
  }
  if (req.method==='POST' && url.pathname==='/api/payments/razorpay/verify') {
    if (!config.razorpayKeySecret) return sendJson(res,503,{verified:false,error:'Payment verification is not configured.'});
    const {razorpay_order_id,razorpay_payment_id,razorpay_signature}=JSON.parse(await readBody(req));
    if (!razorpay_order_id||!razorpay_payment_id||!razorpay_signature) return sendJson(res,400,{verified:false,error:'Missing payment details.'});
    const expected=crypto.createHmac('sha256',config.razorpayKeySecret).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
    if (!secureEqual(expected,razorpay_signature)) return sendJson(res,400,{verified:false,error:'Payment signature did not match.'});
    // TODO: Persist the verified payment and create the customer order in PostgreSQL.
    return sendJson(res,200,{verified:true});
  }
  if (req.method==='POST' && url.pathname==='/api/webhooks/razorpay') {
    const raw=await readBody(req); const signature=req.headers['x-razorpay-signature'];
    if (!config.razorpayWebhookSecret) return sendJson(res,503,{error:'Webhook secret is not configured.'});
    const expected=crypto.createHmac('sha256',config.razorpayWebhookSecret).update(raw).digest('hex');
    if (!secureEqual(expected,signature)) return sendJson(res,400,{error:'Invalid webhook signature.'});
    // TODO: Store payment/order updates and make this handler idempotent once the database is connected.
    return sendJson(res,200,{received:true});
  }
  return false;
}

http.createServer(async (req,res) => {
  try {
    const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
    if (url.pathname.startsWith('/api/')) { const handled=await handleApi(req,res,url); if (handled!==false) return; return sendJson(res,404,{error:'API route not found.'}); }
    let pathname=decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname);
    if(pathname==='/admin.html'&&!validAdminSession(req)) pathname='/admin-login.html';
    if (pathname.includes('..') || pathname.split('/').some(part=>part.startsWith('.'))) { res.writeHead(403); return res.end('Forbidden'); }
    const file=path.join(root,pathname);
    fs.readFile(file,(error,data)=>{ if(error){res.writeHead(404);return res.end('Not found');}res.writeHead(200,{'Content-Type':contentTypes[path.extname(file)]||'application/octet-stream'});res.end(data); });
  } catch (error) { console.error(error); sendJson(res,500,{error:'Unexpected server error.'}); }
}).listen(config.port,()=>console.log(`MARKET HUB server: http://localhost:${config.port}`));
